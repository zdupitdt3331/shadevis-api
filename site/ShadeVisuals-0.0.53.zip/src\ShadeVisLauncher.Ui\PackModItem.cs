using System;
using System.ComponentModel;
using ShadeVisLauncher.Instance;

namespace ShadeVisLauncher.Ui;

public sealed class PackModItem : INotifyPropertyChanged
{
	private const string ManagedDetail = "Always installed";

	private const string StoredDetail = "In the library";

	private const string DetailSeparator = " · ";

	private const string VectorIconExtension = ".svg";

	private bool included;

	public string File { get; }

	public string Title { get; }

	public string Detail { get; }

	public string? IconUrl { get; }

	public bool IsManaged { get; }

	public bool IsEditable => !IsManaged;

	public bool Included
	{
		get
		{
			return included;
		}
		set
		{
			if (included != value)
			{
				included = value;
				this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Included"));
			}
		}
	}

	public event PropertyChangedEventHandler? PropertyChanged;

	public PackModItem(InstalledMod mod, bool included)
	{
		File = mod.File;
		Title = mod.Title;
		Detail = Describe(mod);
		IconUrl = Displayable(mod.IconUrl);
		IsManaged = mod.Managed;
		this.included = included || mod.Managed;
	}

	private static string Describe(InstalledMod mod)
	{
		if (mod.Managed)
		{
			return "Always installed";
		}
		if (!mod.Active)
		{
			return mod.Detail + " · " + "In the library";
		}
		return mod.Detail;
	}

	private static string? Displayable(string? iconUrl)
	{
		if (!string.IsNullOrWhiteSpace(iconUrl) && !iconUrl.EndsWith(".svg", StringComparison.OrdinalIgnoreCase))
		{
			return iconUrl;
		}
		return null;
	}
}
