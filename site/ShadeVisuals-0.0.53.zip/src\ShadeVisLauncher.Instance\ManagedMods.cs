using System;
using System.Collections.Generic;
namespace ShadeVisLauncher.Instance;

public static class ManagedMods
{
	public const string FabricApi = "fabric-api";

	public const string Iris = "iris";

	public const string Sodium = "sodium";

	private static readonly HashSet<string> Names = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
	{
		"fabric-api",
		"iris",
		"sodium"
	};

	public static bool Contains(string? identifier)
	{
		if (identifier != null)
		{
			return Names.Contains(identifier);
		}
		return false;
	}
}
