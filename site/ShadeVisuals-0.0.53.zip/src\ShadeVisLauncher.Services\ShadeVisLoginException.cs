using System;

namespace ShadeVisLauncher.Services;

public sealed class ShadeVisLoginException : Exception
{
	public ShadeVisLoginException(string message)
		: base(message)
	{
	}
}
