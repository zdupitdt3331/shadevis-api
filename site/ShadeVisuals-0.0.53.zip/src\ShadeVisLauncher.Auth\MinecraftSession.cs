using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Auth;

public sealed record MinecraftSession(string Uuid, string Name, string AccessToken)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("MinecraftSession");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Uuid = ");
		builder.Append((object?)Uuid);
		builder.Append(", Name = ");
		builder.Append((object?)Name);
		builder.Append(", AccessToken = ");
		builder.Append((object?)AccessToken);
		return true;
	}
}
