using System;
using System.Diagnostics;
namespace ShadeVisLauncher.Instance;

/// <summary>The launcher does not persist game stdout or stderr.</summary>
public sealed class GameOutputLog : IDisposable
{
    private GameOutputLog() { }
    public static void Prepare(ProcessStartInfo start)
    {
        start.RedirectStandardOutput = false;
        start.RedirectStandardError = false;
    }
    public static GameOutputLog? Capture(Process process, string minecraftDirectory) => null;
    public void Dispose() { }
}
