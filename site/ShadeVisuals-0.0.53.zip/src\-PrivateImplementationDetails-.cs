using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
internal static class _003CPrivateImplementationDetails_003E
{
    public static ref TElement InlineArrayElementRef<TBuffer,TElement>(ref TBuffer buffer, int index)
        => ref Unsafe.Add(ref Unsafe.As<TBuffer,TElement>(ref buffer), index);
    public static ReadOnlySpan<TElement> InlineArrayAsReadOnlySpan<TBuffer,TElement>(in TBuffer buffer, int length)
        => MemoryMarshal.CreateReadOnlySpan(ref Unsafe.As<TBuffer,TElement>(ref Unsafe.AsRef(in buffer)), length);
}
