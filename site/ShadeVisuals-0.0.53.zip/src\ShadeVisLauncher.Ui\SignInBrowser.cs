using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;

namespace ShadeVisLauncher.Ui;

public sealed class SignInBrowser
{
	[CompilerGenerated]
	private WebView2 _003Cview_003EP;

	private const string BlankPage = "about:blank";

	private bool initialised;

	public SignInBrowser(WebView2 view)
	{
		_003Cview_003EP = view;
		
	}

	public async Task<bool> OpenAsync(string url)
	{
		_ = 1;
		try
		{
			if (!initialised)
			{
				CoreWebView2Environment environment = await WebViewHost.EnvironmentAsync();
				await _003Cview_003EP.EnsureCoreWebView2Async(environment);
				CoreWebView2 coreWebView = _003Cview_003EP.CoreWebView2;
				coreWebView.Settings.AreDevToolsEnabled = false;
				coreWebView.Settings.AreDefaultContextMenusEnabled = false;
				coreWebView.Settings.IsStatusBarEnabled = false;
				coreWebView.Settings.AreBrowserAcceleratorKeysEnabled = false;
				coreWebView.NewWindowRequested += OnNewWindowRequested;
				initialised = true;
			}
			_003Cview_003EP.CoreWebView2.Navigate(url);
			return true;
		}
		catch (Exception ex) when (((Func<bool>)delegate
		{
			// Could not convert BlockContainer to single expression
			bool flag = WebViewHost.IsMissingRuntime(ex);
			if (!flag)
			{
				flag = ((ex is InvalidOperationException || ex is ArgumentException || ex is COMException) ? true : false);
			}
			return flag;
		}).Invoke())
		{
			return false;
		}
	}

	public void Close()
	{
		if (!initialised)
		{
			return;
		}
		try
		{
			_003Cview_003EP.CoreWebView2.Navigate("about:blank");
		}
		catch (InvalidOperationException)
		{
			initialised = false;
		}
	}

	private void OnNewWindowRequested(object? sender, CoreWebView2NewWindowRequestedEventArgs e)
	{
		e.Handled = true;
		_003Cview_003EP.CoreWebView2.Navigate(e.Uri);
	}
}
