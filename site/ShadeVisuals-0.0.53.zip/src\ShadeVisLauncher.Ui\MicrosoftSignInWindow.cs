using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using ShadeVisLauncher.Auth;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;

namespace ShadeVisLauncher.Ui;

public sealed class MicrosoftSignInWindow : Window
{
	private const string WindowTitle = "Sign in with Microsoft";

	private const string WindowBackgroundKey = "Window";

	private const double WindowWidth = 520.0;

	private const double WindowHeight = 700.0;

	private const string MissingRuntimeText = "Microsoft sign-in needs the Microsoft Edge WebView2 runtime";

	private const string CancelledText = "Sign-in was cancelled";

	private readonly MicrosoftSignInRequest request;

	private readonly WebView2 view = new WebView2();

	private readonly TaskCompletionSource<string> result = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);

	private MicrosoftSignInWindow(Window owner, MicrosoftSignInRequest request)
	{
		this.request = request;
		base.Owner = owner;
		base.Title = "Sign in with Microsoft";
		base.Width = 520.0;
		base.Height = 700.0;
		base.ResizeMode = ResizeMode.NoResize;
		base.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		base.ShowInTaskbar = false;
		base.Background = (owner.TryFindResource("Window") as Brush) ?? Brushes.Black;
		base.Content = view;
		base.Loaded += async delegate
		{
			await StartAsync();
		};
		base.Closed += delegate
		{
			result.TrySetException(new MicrosoftAuthException("Sign-in was cancelled"));
			view.Dispose();
		};
	}

	public static Task<string> RequestCodeAsync(Window owner, MicrosoftSignInRequest request)
	{
		MicrosoftSignInWindow microsoftSignInWindow = new MicrosoftSignInWindow(owner, request);
		microsoftSignInWindow.Show();
		return microsoftSignInWindow.result.Task;
	}

	private async Task StartAsync()
	{
		_ = 1;
		try
		{
			CoreWebView2Environment environment = await WebViewHost.EnvironmentAsync();
			await view.EnsureCoreWebView2Async(environment);
			CoreWebView2 coreWebView = view.CoreWebView2;
			coreWebView.Settings.AreDevToolsEnabled = false;
			coreWebView.Settings.AreDefaultContextMenusEnabled = false;
			coreWebView.Settings.IsStatusBarEnabled = false;
			coreWebView.NavigationStarting += OnNavigationStarting;
			coreWebView.NewWindowRequested += OnNewWindowRequested;
			coreWebView.Navigate(request.AuthorizeUri.AbsoluteUri);
		}
		catch (Exception ex) when (((Func<bool>)delegate
		{
			// Could not convert BlockContainer to single expression
			bool flag = WebViewHost.IsMissingRuntime(ex);
			if (!flag)
			{
				flag = ((ex is InvalidOperationException || ex is ArgumentException || ex is COMException) ? true : false);
			}
			return flag;
		}).Invoke())
		{
			Finish(delegate
			{
				result.TrySetException(new MicrosoftAuthException("Microsoft sign-in needs the Microsoft Edge WebView2 runtime"));
			});
		}
	}

	private void OnNavigationStarting(object? sender, CoreWebView2NavigationStartingEventArgs e)
	{
		if (!e.Uri.StartsWith(request.RedirectBase, StringComparison.OrdinalIgnoreCase))
		{
			return;
		}
		e.Cancel = true;
		Exception failure = default(Exception);
		try
		{
			string code = MicrosoftAuth.ReadAuthorizationCode(new Uri(e.Uri), request);
			Finish(delegate
			{
				result.TrySetResult(code);
			});
		}
		catch (Exception ex) when (((Func<bool>)delegate
		{
			// Could not convert BlockContainer to single expression
			failure = ex;
			return ((failure is MicrosoftAuthException || failure is UriFormatException) ? 1 : 0) != 0;
		}).Invoke())
		{
			Finish(delegate
			{
				result.TrySetException(failure);
			});
		}
	}

	private void OnNewWindowRequested(object? sender, CoreWebView2NewWindowRequestedEventArgs e)
	{
		e.Handled = true;
		view.CoreWebView2.Navigate(e.Uri);
	}

	private void Finish(Action complete)
	{
		complete();
		base.Dispatcher.BeginInvoke(new Action(base.Close));
	}
}
