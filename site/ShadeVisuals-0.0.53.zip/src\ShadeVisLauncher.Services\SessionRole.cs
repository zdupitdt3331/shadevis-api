namespace ShadeVisLauncher.Services;

/// <summary>Роль текущей сессии лаунчера (Admin/Media/User).</summary>
public static class SessionRole
{
	public static string Current { get; set; } = RoleCatalog.User;
}
