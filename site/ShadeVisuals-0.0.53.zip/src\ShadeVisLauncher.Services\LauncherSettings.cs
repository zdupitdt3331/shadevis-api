using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
namespace ShadeVisLauncher.Services;

public sealed record LauncherSettings(int HeapGigabytes, string? InstallRoot = null, bool PreferMirror = false, string? MirrorOrigin = null)
{
    public static LauncherSettings Current
    {
        get
        {
            lock (Gate)
            {
                return cached ?? (cached = Load());
            }
        }
    }

    private static string FilePath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ShadeVis", "settings.json");

    public const int AutomaticHeap = 0;

    public const int MinimumHeap = 2;

    public const int MaximumHeap = 16;

    private const string FolderName = "ShadeVis";

    private const string FileName = "settings.json";

    private static readonly object Gate = new object();

    private static LauncherSettings? cached;

    public static void Save(LauncherSettings settings)
    {
        lock (Gate)
        {
            cached = settings;
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
                File.WriteAllText(FilePath, JsonSerializer.Serialize(settings));
            }
            catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
            {
            }
        }
    }

    private static LauncherSettings Load()
    {
        try
        {
            if (File.Exists(FilePath))
            {
                LauncherSettings launcherSettings = JsonSerializer.Deserialize<LauncherSettings>(File.ReadAllText(FilePath));
                if ((object)launcherSettings != null)
                {
                    return launcherSettings.Sanitized();
                }
            }
        }
        catch (Exception ex) when (((ex is IOException || ex is JsonException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
        {
        }
        return new LauncherSettings(0);
    }

    private LauncherSettings Sanitized()
    {
        return this with
        {
            HeapGigabytes = ((HeapGigabytes != 0) ? Math.Clamp(HeapGigabytes, 2, 16) : 0),
            InstallRoot = ((InstallRoot != null && Path.IsPathFullyQualified(InstallRoot)) ? InstallRoot : null)
        };
    }

    [CompilerGenerated]
    public override string ToString()
    {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.Append("LauncherSettings");
        stringBuilder.Append(" { ");
        if (PrintMembers(stringBuilder))
        {
            stringBuilder.Append(' ');
        }
        stringBuilder.Append('}');
        return stringBuilder.ToString();
    }

    [CompilerGenerated]
    private bool PrintMembers(StringBuilder builder)
    {
        RuntimeHelpers.EnsureSufficientExecutionStack();
        builder.Append("HeapGigabytes = ");
        builder.Append(HeapGigabytes.ToString());
        builder.Append(", InstallRoot = ");
        builder.Append((object?)InstallRoot);
        builder.Append(", PreferMirror = ");
        builder.Append(PreferMirror.ToString());
        builder.Append(", MirrorOrigin = ");
        builder.Append((object?)MirrorOrigin);
        return true;
    }

    [CompilerGenerated]
    private LauncherSettings(LauncherSettings original)
    {
        HeapGigabytes = original.HeapGigabytes;
        InstallRoot = original.InstallRoot;
        PreferMirror = original.PreferMirror;
        MirrorOrigin = original.MirrorOrigin;
    }
}