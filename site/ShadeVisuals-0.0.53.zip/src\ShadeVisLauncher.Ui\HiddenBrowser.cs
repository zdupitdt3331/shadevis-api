using System;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Core;

namespace ShadeVisLauncher.Ui;

public sealed class HiddenBrowser : IAsyncDisposable
{
	[CompilerGenerated]
	private nint _003Cowner_003EP;

	private static readonly TimeSpan NavigationTimeout = TimeSpan.FromSeconds(35L);

	private static readonly Rectangle OffscreenBounds = new Rectangle(0, 0, 1, 1);

	private CoreWebView2Controller? controller;

	private TaskCompletionSource<bool>? navigation;

	public HiddenBrowser(nint owner)
	{
		_003Cowner_003EP = owner;
		
	}

	public async Task<string?> EvaluateAsync(string url, string script, CancellationToken cancel)
	{
		CoreWebView2 core = await EnsureAsync();
		if (core == null)
		{
			return null;
		}
		navigation = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
		core.Navigate(url);
		using CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(cancel);
		timeout.CancelAfter(NavigationTimeout);
		if (await Task.WhenAny(navigation.Task, Task.Delay(-1, timeout.Token)) != navigation.Task || !navigation.Task.Result)
		{
			return null;
		}
		return await core.ExecuteScriptAsync(script);
	}

	private async Task<CoreWebView2?> EnsureAsync()
	{
		if (controller != null)
		{
			return controller.CoreWebView2;
		}
		try
		{
			controller = await (await WebViewHost.EnvironmentAsync()).CreateCoreWebView2ControllerAsync(_003Cowner_003EP);
			controller.IsVisible = false;
			controller.Bounds = OffscreenBounds;
			controller.CoreWebView2.Settings.AreDevToolsEnabled = false;
			controller.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
			controller.CoreWebView2.NavigationCompleted += delegate(object? _, CoreWebView2NavigationCompletedEventArgs e)
			{
				navigation?.TrySetResult(e.IsSuccess);
			};
			return controller.CoreWebView2;
		}
		catch (Exception ex) when (WebViewHost.IsMissingRuntime(ex) || ex is InvalidOperationException)
		{
			controller = null;
			return null;
		}
	}

	public ValueTask DisposeAsync()
	{
		controller?.Close();
		controller = null;
		return ValueTask.CompletedTask;
	}
}
