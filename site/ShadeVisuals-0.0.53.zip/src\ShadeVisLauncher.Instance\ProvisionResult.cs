using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public sealed record ProvisionResult(string Classpath, string MainClass, string AssetIndexId)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("ProvisionResult");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Classpath = ");
		builder.Append((object?)Classpath);
		builder.Append(", MainClass = ");
		builder.Append((object?)MainClass);
		builder.Append(", AssetIndexId = ");
		builder.Append((object?)AssetIndexId);
		return true;
	}
}
