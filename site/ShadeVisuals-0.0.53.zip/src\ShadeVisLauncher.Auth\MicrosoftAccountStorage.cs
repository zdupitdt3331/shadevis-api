using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace ShadeVisLauncher.Auth;

public static class MicrosoftAccountStorage
{
	private const string FolderName = "ShadeVis";

	private const string FileName = "microsoft.dat";

	private static string FilePath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ShadeVis", "microsoft.dat");

	public static bool Save(MicrosoftAccount account)
	{
		try
		{
			byte[] bytes = ProtectedData.Protect(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(account)), null, DataProtectionScope.CurrentUser);
			Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
			string text = FilePath + ".tmp";
			File.WriteAllBytes(text, bytes);
			File.Move(text, FilePath, overwrite: true);
			return true;
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException || ex is CryptographicException) ? 1 : 0) != 0)
		{
			return false;
		}
	}

	public static MicrosoftAccount? Load()
	{
		if (!File.Exists(FilePath))
		{
			return null;
		}
		try
		{
			byte[] bytes = ProtectedData.Unprotect(File.ReadAllBytes(FilePath), null, DataProtectionScope.CurrentUser);
			MicrosoftAccount microsoftAccount = JsonSerializer.Deserialize<MicrosoftAccount>(Encoding.UTF8.GetString(bytes));
			object result;
			if ((object)microsoftAccount != null)
			{
				string refreshToken = microsoftAccount.RefreshToken;
				if (refreshToken != null && refreshToken.Length > 0)
				{
					string uuid = microsoftAccount.Uuid;
					if (uuid != null && uuid.Length > 0)
					{
						string name = microsoftAccount.Name;
						if (name != null && name.Length > 0)
						{
							result = microsoftAccount;
							goto IL_00d1;
						}
					}
				}
			}
			result = null;
			goto IL_00d1;
			IL_00d1:
			return (MicrosoftAccount?)result;
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException || ex is CryptographicException || ex is JsonException) ? 1 : 0) != 0)
		{
			return null;
		}
	}

	public static void Clear()
	{
		try
		{
			File.Delete(FilePath);
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
		}
	}
}
