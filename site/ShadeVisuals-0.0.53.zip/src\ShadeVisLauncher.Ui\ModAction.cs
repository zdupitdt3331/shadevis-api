namespace ShadeVisLauncher.Ui;

public enum ModAction
{
	Install,
	Installing,
	Installed,
	Remove,
	Managed
}
