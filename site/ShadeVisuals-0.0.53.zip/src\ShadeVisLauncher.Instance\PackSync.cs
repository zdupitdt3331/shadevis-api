using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public sealed record PackSync(int Activated, int Stored, int Restored, int Missing, int Failed, int Linked, IReadOnlyList<ModConflict> Conflicts)
{
	public bool Changed
	{
		get
		{
			if (Activated <= 0 && Stored <= 0 && Restored <= 0)
			{
				return Linked > 0;
			}
			return true;
		}
	}

	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("PackSync");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Activated = ");
		builder.Append(Activated.ToString());
		builder.Append(", Stored = ");
		builder.Append(Stored.ToString());
		builder.Append(", Restored = ");
		builder.Append(Restored.ToString());
		builder.Append(", Missing = ");
		builder.Append(Missing.ToString());
		builder.Append(", Failed = ");
		builder.Append(Failed.ToString());
		builder.Append(", Linked = ");
		builder.Append(Linked.ToString());
		builder.Append(", Conflicts = ");
		builder.Append(Conflicts);
		builder.Append(", Changed = ");
		builder.Append(Changed.ToString());
		return true;
	}
}
