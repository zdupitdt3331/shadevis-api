using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Services;

public sealed record ShadeVisUser(string? Username, string Token, string? Role, int Uid, string? Avatar)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("ShadeVisUser");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Username = ");
		builder.Append((object?)Username);
		builder.Append(", Token = ");
		builder.Append((object?)Token);
		builder.Append(", Role = ");
		builder.Append((object?)Role);
		builder.Append(", Uid = ");
		builder.Append(Uid.ToString());
		builder.Append(", Avatar = ");
		builder.Append((object?)Avatar);
		return true;
	}
}
