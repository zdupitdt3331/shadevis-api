using System.Runtime.CompilerServices;
using System.Text;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher.Instance;

public sealed record ModDelivery(bool Ready, PayloadAccess Access)
{
	public bool Entitled => Access == PayloadAccess.Granted;

	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("ModDelivery");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Ready = ");
		builder.Append(Ready.ToString());
		builder.Append(", Access = ");
		builder.Append(Access.ToString());
		builder.Append(", Entitled = ");
		builder.Append(Entitled.ToString());
		return true;
	}
}
