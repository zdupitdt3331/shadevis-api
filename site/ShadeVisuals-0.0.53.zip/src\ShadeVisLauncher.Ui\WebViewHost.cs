using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Core;

namespace ShadeVisLauncher.Ui;

public static class WebViewHost
{
	private const string FolderName = "ShadeVis";

	private const string DataFolderName = "webview";

	private const string SoftwareGraphicsArguments = "--enable-unsafe-swiftshader";

	private static Task<CoreWebView2Environment>? shared;

	public static string DataFolder => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ShadeVis", "webview");

	public static Task<CoreWebView2Environment> EnvironmentAsync()
	{
		if (shared == null)
		{
			Directory.CreateDirectory(DataFolder);
			CoreWebView2EnvironmentOptions options = new CoreWebView2EnvironmentOptions
			{
				AdditionalBrowserArguments = "--enable-unsafe-swiftshader"
			};
			shared = CoreWebView2Environment.CreateAsync(null, DataFolder, options);
		}
		return shared;
	}

	public static bool IsMissingRuntime(Exception failure)
	{
		if (failure is WebView2RuntimeNotFoundException || failure is DllNotFoundException || failure is FileNotFoundException)
		{
			return true;
		}
		return false;
	}
}
