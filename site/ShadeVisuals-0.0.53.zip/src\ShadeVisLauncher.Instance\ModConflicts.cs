using System;
using System.Collections.Generic;
namespace ShadeVisLauncher.Instance;

public static class ModConflicts
{
	private static readonly IReadOnlyList<(string Kept, string Disabled)> Pairs = new(string, string)[1] { ("e4mc", "krypton") };

	public static IReadOnlyList<ModConflict> Resolve(IReadOnlyDictionary<string, string?> idsByFile)
	{
		Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
		foreach (var (item, text3) in idsByFile)
		{
			if (text3 != null)
			{
				if (!dictionary.TryGetValue(text3, out var value))
				{
					value = (dictionary[text3] = new List<string>());
				}
				value.Add(item);
			}
		}
		List<ModConflict> list2 = new List<ModConflict>();
		foreach (var (text4, text5) in Pairs)
		{
			if (!dictionary.ContainsKey(text4) || !dictionary.TryGetValue(text5, out var value2))
			{
				continue;
			}
			foreach (string item2 in value2)
			{
				list2.Add(new ModConflict(text4, text5, item2));
			}
		}
		return list2;
	}
}
