using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
namespace ShadeVisLauncher.Services;

public static class OpenGlProbe
{
	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
	private struct WindowClass
	{
		public uint Style;

		public nint WindowProcedure;

		public int ClassExtra;

		public int WindowExtra;

		public nint Instance;

		public nint Icon;

		public nint Cursor;

		public nint Background;

		public nint MenuName;

		public nint ClassName;
	}

	private struct PixelFormatDescriptor
	{
		public ushort Size;

		public ushort VersionNumber;

		public uint Flags;

		public byte PixelType;

		public byte ColorBits;

		public byte RedBits;

		public byte RedShift;

		public byte GreenBits;

		public byte GreenShift;

		public byte BlueBits;

		public byte BlueShift;

		public byte AlphaBits;

		public byte AlphaShift;

		public byte AccumBits;

		public byte AccumRedBits;

		public byte AccumGreenBits;

		public byte AccumBlueBits;

		public byte AccumAlphaBits;

		public byte DepthBits;

		public byte StencilBits;

		public byte AuxBuffers;

		public byte LayerType;

		public byte Reserved;

		public uint LayerMask;

		public uint VisibleMask;

		public uint DamageMask;
	}

	public const int RequiredMajor = 3;

	public const int RequiredMinor = 3;

	private const string WindowClassName = "ShadeVisGlProbe";

	private const string User32 = "user32.dll";

	private const string Gdi32 = "gdi32.dll";

	private const string OpenGl32 = "opengl32.dll";

	private const string Kernel32 = "kernel32.dll";

	private const string DefaultWindowProcedure = "DefWindowProcW";

	private const uint ClassOwnDeviceContext = 32u;

	private const uint StylePopup = 2147483648u;

	private const int ClassAlreadyExists = 1410;

	private const byte PixelTypeRgba = 0;

	private const uint DrawToWindow = 4u;

	private const uint SupportOpenGl = 32u;

	private const uint DoubleBuffer = 1u;

	private const byte ColorBits = 32;

	private const byte DepthBits = 24;

	private const int Vendor = 7936;

	private const int Renderer = 7937;

	private const int Version = 7938;

	public static GlSupport Detect()
	{
		nint moduleHandleW = GetModuleHandleW(null);
		if (!EnsureWindowClass(moduleHandleW))
		{
			return Failed("window class registration");
		}
		nint num = CreateWindowExW(0u, "ShadeVisGlProbe", string.Empty, 2147483648u, 0, 0, 1, 1, IntPtr.Zero, IntPtr.Zero, moduleHandleW, IntPtr.Zero);
		if (num == IntPtr.Zero)
		{
			return Failed("window creation");
		}
		nint num2 = IntPtr.Zero;
		nint num3 = IntPtr.Zero;
		try
		{
			num2 = GetDC(num);
			if (num2 == IntPtr.Zero)
			{
				return Failed("device context");
			}
			PixelFormatDescriptor pixelFormatDescriptor = default(PixelFormatDescriptor);
			pixelFormatDescriptor.Size = (ushort)Marshal.SizeOf<PixelFormatDescriptor>();
			pixelFormatDescriptor.VersionNumber = 1;
			pixelFormatDescriptor.Flags = 37u;
			pixelFormatDescriptor.PixelType = 0;
			pixelFormatDescriptor.ColorBits = 32;
			pixelFormatDescriptor.DepthBits = 24;
			PixelFormatDescriptor descriptor = pixelFormatDescriptor;
			int num4 = ChoosePixelFormat(num2, ref descriptor);
			if (num4 == 0)
			{
				return Failed("pixel format choice");
			}
			if (!SetPixelFormat(num2, num4, ref descriptor))
			{
				return Failed("pixel format assignment");
			}
			num3 = wglCreateContext(num2);
			if (num3 == IntPtr.Zero)
			{
				return Failed("context creation");
			}
			if (!wglMakeCurrent(num2, num3))
			{
				return Failed("context activation");
			}
			var (major, minor) = ParseVersion(ReadString(7938));
			return new GlSupport(major, minor, ReadString(7937), ReadString(7936), string.Empty);
		}
		finally
		{
			if (num3 != IntPtr.Zero)
			{
				wglMakeCurrent(IntPtr.Zero, IntPtr.Zero);
				wglDeleteContext(num3);
			}
			if (num2 != IntPtr.Zero)
			{
				ReleaseDC(num, num2);
			}
			DestroyWindow(num);
		}
	}

	private static GlSupport Failed(string step)
	{
		string empty = string.Empty;
		string empty2 = string.Empty;
		DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(16, 2);
		defaultInterpolatedStringHandler.AppendFormatted(step);
		defaultInterpolatedStringHandler.AppendLiteral(" failed (win32 ");
		defaultInterpolatedStringHandler.AppendFormatted(Marshal.GetLastWin32Error());
		defaultInterpolatedStringHandler.AppendLiteral(")");
		return new GlSupport(0, 0, empty, empty2, defaultInterpolatedStringHandler.ToStringAndClear());
	}

	private static bool EnsureWindowClass(nint module)
	{
		nint moduleHandleW = GetModuleHandleW("user32.dll");
		nint num = ((moduleHandleW == IntPtr.Zero) ? IntPtr.Zero : GetProcAddress(moduleHandleW, "DefWindowProcW"));
		if (num == IntPtr.Zero)
		{
			return false;
		}
		nint num2 = Marshal.StringToHGlobalUni("ShadeVisGlProbe");
		try
		{
			WindowClass windowClass = default(WindowClass);
			windowClass.Style = 32u;
			windowClass.WindowProcedure = num;
			windowClass.Instance = module;
			windowClass.ClassName = num2;
			WindowClass windowClass2 = windowClass;
			return RegisterClassW(ref windowClass2) != 0 || Marshal.GetLastWin32Error() == 1410;
		}
		finally
		{
			Marshal.FreeHGlobal(num2);
		}
	}

	private static string ReadString(int name)
	{
		nint num = glGetString(name);
		string text;
		if (num != IntPtr.Zero)
		{
			text = Marshal.PtrToStringAnsi(num);
			if (text == null)
			{
				return string.Empty;
			}
		}
		else
		{
			text = string.Empty;
		}
		return text;
	}

	private static (int Major, int Minor) ParseVersion(string version)
	{
		int i;
		for (i = 0; i < version.Length && (char.IsAsciiDigit(version[i]) || version[i] == '.'); i++)
		{
		}
		string[] array = version.Substring(0, i).Split('.');
		if (array.Length < 2 || !int.TryParse(array[0], out var result) || !int.TryParse(array[1], out var result2))
		{
			return (Major: 0, Minor: 0);
		}
		return (Major: result, Minor: result2);
	}

	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern nint GetModuleHandleW(string? name);

	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	private static extern nint GetProcAddress(nint module, string name);

	[DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern ushort RegisterClassW(ref WindowClass windowClass);

	[DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern nint CreateWindowExW(uint exStyle, string className, string windowName, uint style, int x, int y, int width, int height, nint parent, nint menu, nint instance, nint param);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool DestroyWindow(nint window);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern nint GetDC(nint window);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern int ReleaseDC(nint window, nint deviceContext);

	[DllImport("gdi32.dll", SetLastError = true)]
	private static extern int ChoosePixelFormat(nint deviceContext, ref PixelFormatDescriptor descriptor);

	[DllImport("gdi32.dll", SetLastError = true)]
	private static extern bool SetPixelFormat(nint deviceContext, int format, ref PixelFormatDescriptor descriptor);

	[DllImport("opengl32.dll", SetLastError = true)]
	private static extern nint wglCreateContext(nint deviceContext);

	[DllImport("opengl32.dll", SetLastError = true)]
	private static extern bool wglMakeCurrent(nint deviceContext, nint context);

	[DllImport("opengl32.dll", SetLastError = true)]
	private static extern bool wglDeleteContext(nint context);

	[DllImport("opengl32.dll", SetLastError = true)]
	private static extern nint glGetString(int name);
}
