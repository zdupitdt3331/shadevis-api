using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
namespace ShadeVisLauncher.Ui;

public static class PlayerModel
{
	private enum Face
	{
		North,
		South,
		West,
		East,
		Up,
		Down
	}

	private sealed record Part(string Name, Point3D Origin, Vector3D Size, Point Uv, Point OverlayUv, double Inflate, bool Arm, bool Mirrored)
	{
		[CompilerGenerated]
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("Part");
			stringBuilder.Append(" { ");
			if (PrintMembers(stringBuilder))
			{
				stringBuilder.Append(' ');
			}
			stringBuilder.Append('}');
			return stringBuilder.ToString();
		}

		[CompilerGenerated]
		private bool PrintMembers(StringBuilder builder)
		{
			RuntimeHelpers.EnsureSufficientExecutionStack();
			builder.Append("Name = ");
			builder.Append((object?)Name);
			builder.Append(", Origin = ");
			builder.Append(Origin.ToString());
			builder.Append(", Size = ");
			builder.Append(Size.ToString());
			builder.Append(", Uv = ");
			builder.Append(Uv.ToString());
			builder.Append(", OverlayUv = ");
			builder.Append(OverlayUv.ToString());
			builder.Append(", Inflate = ");
			builder.Append(Inflate.ToString());
			builder.Append(", Arm = ");
			builder.Append(Arm.ToString());
			builder.Append(", Mirrored = ");
			builder.Append(Mirrored.ToString());
			return true;
		}
	}

	public const double ModelHeight = 32.0;

	private const int SkinUnits = 64;

	private const int LegacyHeight = 32;

	private const double SpinSeconds = 14.0;

	private const double FullTurn = 360.0;

	private const double StartAngle = 180.0;

	private const int SpinFrameRate = 15;

	private const int RenderTierShift = 16;

	private const int Channels = 4;

	private const int AlphaChannel = 3;

	private const double OverlayInflate = 0.25;

	private const double HeadInflate = 0.5;

	private const double SlimArmWidth = 3.0;

	private const int TextureTarget = 512;

	private const int MaxMagnify = 8;

	private static readonly Rect TextureSpace = new Rect(0.0, 0.0, 1.0, 1.0);

	private static AnimationClock? spin;

	private static readonly (int X, int Y)[] ClassicProbe = new(int, int)[4]
	{
		(54, 20),
		(55, 20),
		(54, 31),
		(55, 31)
	};

	private static readonly Part[] Parts = new Part[6]
	{
		new Part("head", new Point3D(-4.0, 24.0, -4.0), new Vector3D(8.0, 8.0, 8.0), new Point(0.0, 0.0), new Point(32.0, 0.0), 0.5, Arm: false, Mirrored: false),
		new Part("body", new Point3D(-4.0, 12.0, -2.0), new Vector3D(8.0, 12.0, 4.0), new Point(16.0, 16.0), new Point(16.0, 32.0), 0.25, Arm: false, Mirrored: false),
		new Part("rightArm", new Point3D(4.0, 12.0, -2.0), new Vector3D(4.0, 12.0, 4.0), new Point(40.0, 16.0), new Point(40.0, 32.0), 0.25, Arm: true, Mirrored: false),
		new Part("leftArm", new Point3D(-8.0, 12.0, -2.0), new Vector3D(4.0, 12.0, 4.0), new Point(32.0, 48.0), new Point(48.0, 48.0), 0.25, Arm: true, Mirrored: true),
		new Part("rightLeg", new Point3D(0.0, 0.0, -2.0), new Vector3D(4.0, 12.0, 4.0), new Point(0.0, 16.0), new Point(0.0, 32.0), 0.25, Arm: false, Mirrored: false),
		new Part("leftLeg", new Point3D(-4.0, 0.0, -2.0), new Vector3D(4.0, 12.0, 4.0), new Point(16.0, 48.0), new Point(0.0, 48.0), 0.25, Arm: false, Mirrored: true)
	};

	private static readonly (Point Base, Point Overlay, int Width, int Height)[] OverlayBlocks = new(Point, Point, int, int)[6]
	{
		(new Point(0.0, 0.0), new Point(32.0, 0.0), 32, 16),
		(new Point(16.0, 16.0), new Point(16.0, 32.0), 24, 16),
		(new Point(40.0, 16.0), new Point(40.0, 32.0), 16, 16),
		(new Point(0.0, 16.0), new Point(0.0, 32.0), 16, 16),
		(new Point(32.0, 48.0), new Point(48.0, 48.0), 16, 16),
		(new Point(16.0, 48.0), new Point(0.0, 48.0), 16, 16)
	};

	public static bool Accelerated => RenderCapability.Tier >> 16 > 0;

	public static PlayerSkin? Prepare(byte[] png, bool? slimHint)
	{
		BitmapSource bitmapSource = Decode(png);
		if (bitmapSource == null)
		{
			return null;
		}
		int scale = Math.Max(1, bitmapSource.PixelWidth / 64);
		bool flag = bitmapSource.PixelHeight < bitmapSource.PixelWidth;
		int stride;
		byte[] array = ReadPixels(bitmapSource, out stride);
		bool slim = slimHint ?? DetectSlim(array, stride, scale);
		if (!flag)
		{
			Flatten(array, stride, scale);
		}
		int num = MagnifyFactor(bitmapSource.PixelWidth);
		int num2 = bitmapSource.PixelWidth * num;
		int pixelHeight = bitmapSource.PixelHeight * num;
		byte[] pixels = ((num == 1) ? array : Magnify(array, bitmapSource.PixelWidth, bitmapSource.PixelHeight, stride, num));
		BitmapSource bitmapSource2 = BitmapSource.Create(num2, pixelHeight, bitmapSource.DpiX, bitmapSource.DpiY, PixelFormats.Bgra32, null, pixels, num2 * 4);
		bitmapSource2.Freeze();
		return new PlayerSkin(bitmapSource2, slim, flag);
	}

	public static bool IsSlim(byte[] png)
	{
		BitmapSource bitmapSource = Decode(png);
		if (bitmapSource == null)
		{
			return false;
		}
		int stride;
		return DetectSlim(ReadPixels(bitmapSource, out stride), stride, Math.Max(1, bitmapSource.PixelWidth / 64));
	}

	public static Model3DGroup Build(PlayerSkin skin)
	{
		bool slim = skin.Slim;
		bool legacy = skin.Legacy;
		ImageBrush obj = new ImageBrush(skin.Texture)
		{
			Stretch = Stretch.Fill,
			ViewportUnits = BrushMappingMode.Absolute,
			Viewport = TextureSpace,
			TileMode = TileMode.None
		};
		RenderOptions.SetBitmapScalingMode(obj, BitmapScalingMode.NearestNeighbor);
		obj.Freeze();
		DiffuseMaterial diffuseMaterial = new DiffuseMaterial(obj);
		diffuseMaterial.Freeze();
		Model3DGroup model3DGroup = new Model3DGroup();
		Part[] parts = Parts;
		foreach (Part part in parts)
		{
			Vector3D vector3D;
			if (!(part.Arm && slim))
			{
				vector3D = part.Size;
			}
			else
			{
				Vector3D size = part.Size;
				size.X = 3.0;
				vector3D = size;
			}
			Vector3D size2 = vector3D;
			Point3D point3D;
			if (!(part.Arm && slim) || !part.Mirrored)
			{
				point3D = part.Origin;
			}
			else
			{
				Point3D origin = part.Origin;
				origin.X = part.Origin.X + 1.0;
				point3D = origin;
			}
			Point3D origin2 = point3D;
			bool flag = legacy && part.Mirrored;
			Point uv = (flag ? MirrorSource(part) : part.Uv);
			model3DGroup.Children.Add(Cube(origin2, size2, 0.0, uv, diffuseMaterial, flag));
		}
		model3DGroup.Transform = Spin();
		return model3DGroup;
	}

	private static Point MirrorSource(Part part)
	{
		if (!(part.Name == "leftArm"))
		{
			return new Point(0.0, 16.0);
		}
		return new Point(40.0, 16.0);
	}

	public static void Suspend()
	{
		spin?.Controller?.Pause();
	}

	public static void Resume()
	{
		spin?.Controller?.Resume();
	}

	public static void SetSpinning(Model3DGroup? model, bool spinning)
	{
		if (model?.Transform is RotateTransform3D { Rotation: AxisAngleRotation3D rotation })
		{
			rotation.ApplyAnimationClock(AxisAngleRotation3D.AngleProperty, spinning ? SharedSpin() : null);
		}
	}

	private static Transform3D Spin()
	{
		AxisAngleRotation3D axisAngleRotation3D = new AxisAngleRotation3D(new Vector3D(0.0, 1.0, 0.0), 180.0);
		if (Accelerated)
		{
			axisAngleRotation3D.ApplyAnimationClock(AxisAngleRotation3D.AngleProperty, SharedSpin());
		}
		return new RotateTransform3D(axisAngleRotation3D, new Point3D(0.0, 16.0, 0.0));
	}

	private static AnimationClock SharedSpin()
	{
		if (spin != null)
		{
			return spin;
		}
		DoubleAnimation obj = new DoubleAnimation(180.0, 540.0, new Duration(TimeSpan.FromSeconds(14.0)))
		{
			RepeatBehavior = RepeatBehavior.Forever
		};
		Timeline.SetDesiredFrameRate(obj, 15);
		spin = obj.CreateClock();
		return spin;
	}

	private static GeometryModel3D Cube(Point3D origin, Vector3D size, double inflate, Point uv, Material material, bool mirror)
	{
		double num = origin.X - inflate;
		double num2 = origin.Y - inflate;
		double num3 = origin.Z - inflate;
		double num4 = size.X + inflate * 2.0;
		double num5 = size.Y + inflate * 2.0;
		double num6 = size.Z + inflate * 2.0;
		double x = 0.0 - (num + num4);
		double x2 = 0.0 - num;
		double y = num2;
		double y2 = num2 + num5;
		double z = num3;
		double z2 = num3 + num6;
		MeshGeometry3D meshGeometry3D = new MeshGeometry3D();
		Face[] values = Enum.GetValues<Face>();
		foreach (Face face in values)
		{
			Rect rect = BoxRect(mirror ? Flip(face) : face, uv, size.X, size.Y, size.Z);
			double u = (mirror ? rect.Right : rect.Left) / 64.0;
			double u2 = (mirror ? rect.Left : rect.Right) / 64.0;
			double v = rect.Top / 64.0;
			double v2 = rect.Bottom / 64.0;
			AddFace(meshGeometry3D, face, x, y, z, x2, y2, z2, u, v, u2, v2);
		}
		meshGeometry3D.Freeze();
		GeometryModel3D geometryModel3D = new GeometryModel3D(meshGeometry3D, material);
		geometryModel3D.BackMaterial = material;
		geometryModel3D.Freeze();
		return geometryModel3D;
	}

	private static Face Flip(Face face)
	{
		return face switch
		{
			Face.West => Face.East, 
			Face.East => Face.West, 
			_ => face, 
		};
	}

	private static Rect BoxRect(Face face, Point uv, double w, double h, double d)
	{
		return face switch
		{
			Face.Up => new Rect(uv.X + d, uv.Y, w, d), 
			Face.Down => new Rect(uv.X + d + w, uv.Y, w, d), 
			Face.West => new Rect(uv.X, uv.Y + d, d, h), 
			Face.North => new Rect(uv.X + d, uv.Y + d, w, h), 
			Face.East => new Rect(uv.X + d + w, uv.Y + d, d, h), 
			_ => new Rect(uv.X + d * 2.0 + w, uv.Y + d, w, h), 
		};
	}

	private static void AddFace(MeshGeometry3D mesh, Face face, double x0, double y0, double z0, double x1, double y1, double z1, double u0, double v0, double u1, double v1)
	{
		Point3D[] array = face switch
		{
			Face.North => new Point3D[4]
			{
				new Point3D(x0, y1, z0),
				new Point3D(x1, y1, z0),
				new Point3D(x1, y0, z0),
				new Point3D(x0, y0, z0)
			}, 
			Face.South => new Point3D[4]
			{
				new Point3D(x1, y1, z1),
				new Point3D(x0, y1, z1),
				new Point3D(x0, y0, z1),
				new Point3D(x1, y0, z1)
			}, 
			Face.West => new Point3D[4]
			{
				new Point3D(x0, y1, z1),
				new Point3D(x0, y1, z0),
				new Point3D(x0, y0, z0),
				new Point3D(x0, y0, z1)
			}, 
			Face.East => new Point3D[4]
			{
				new Point3D(x1, y1, z0),
				new Point3D(x1, y1, z1),
				new Point3D(x1, y0, z1),
				new Point3D(x1, y0, z0)
			}, 
			Face.Up => new Point3D[4]
			{
				new Point3D(x0, y1, z0),
				new Point3D(x1, y1, z0),
				new Point3D(x1, y1, z1),
				new Point3D(x0, y1, z1)
			}, 
			_ => new Point3D[4]
			{
				new Point3D(x0, y0, z1),
				new Point3D(x1, y0, z1),
				new Point3D(x1, y0, z0),
				new Point3D(x0, y0, z0)
			}, 
		};
		Point[] array2 = new Point[4]
		{
			new Point(u0, v0),
			new Point(u1, v0),
			new Point(u1, v1),
			new Point(u0, v1)
		};
		int count = mesh.Positions.Count;
		for (int i = 0; i < array.Length; i++)
		{
			mesh.Positions.Add(array[i]);
			mesh.TextureCoordinates.Add(array2[i]);
		}
		mesh.TriangleIndices.Add(count);
		mesh.TriangleIndices.Add(count + 1);
		mesh.TriangleIndices.Add(count + 2);
		mesh.TriangleIndices.Add(count);
		mesh.TriangleIndices.Add(count + 2);
		mesh.TriangleIndices.Add(count + 3);
	}

	private static BitmapSource? Decode(byte[] png)
	{
		try
		{
			using MemoryStream bitmapStream = new MemoryStream(png);
			FormatConvertedBitmap formatConvertedBitmap = new FormatConvertedBitmap(BitmapFrame.Create(bitmapStream, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad), PixelFormats.Bgra32, null, 0.0);
			formatConvertedBitmap.Freeze();
			return (formatConvertedBitmap.PixelWidth >= 64) ? formatConvertedBitmap : null;
		}
		catch (Exception ex) when (((ex is NotSupportedException || ex is ArgumentException || ex is IOException || ex is FileFormatException) ? 1 : 0) != 0)
		{
			return null;
		}
	}

	private static int MagnifyFactor(int width)
	{
		return Math.Clamp(512 / Math.Max(1, width), 1, 8);
	}

	private static byte[] Magnify(byte[] pixels, int width, int height, int stride, int factor)
	{
		int num = width * factor * 4;
		byte[] array = new byte[num * height * factor];
		for (int i = 0; i < height; i++)
		{
			int num2 = i * factor * num;
			for (int j = 0; j < width; j++)
			{
				int srcOffset = i * stride + j * 4;
				int num3 = num2 + j * factor * 4;
				for (int k = 0; k < factor; k++)
				{
					Buffer.BlockCopy(pixels, srcOffset, array, num3 + k * 4, 4);
				}
			}
			for (int l = 1; l < factor; l++)
			{
				Buffer.BlockCopy(array, num2, array, num2 + l * num, num);
			}
		}
		return array;
	}

	private static byte[] ReadPixels(BitmapSource source, out int stride)
	{
		stride = source.PixelWidth * 4;
		byte[] array = new byte[stride * source.PixelHeight];
		source.CopyPixels(array, stride, 0);
		return array;
	}

	private static bool DetectSlim(byte[] pixels, int stride, int scale)
	{
		(int, int)[] classicProbe = ClassicProbe;
		for (int i = 0; i < classicProbe.Length; i++)
		{
			(int, int) tuple = classicProbe[i];
			int item = tuple.Item1;
			int num = tuple.Item2 * scale * stride + item * scale * 4 + 3;
			if (num < pixels.Length && pixels[num] > 0)
			{
				return false;
			}
		}
		return true;
	}

	private static void Flatten(byte[] pixels, int stride, int scale)
	{
		(Point, Point, int, int)[] overlayBlocks = OverlayBlocks;
		for (int i = 0; i < overlayBlocks.Length; i++)
		{
			(Point, Point, int, int) tuple = overlayBlocks[i];
			Point item = tuple.Item1;
			Point item2 = tuple.Item2;
			int item3 = tuple.Item3;
			int item4 = tuple.Item4;
			for (int j = 0; j < item4 * scale; j++)
			{
				for (int k = 0; k < item3 * scale; k++)
				{
					int num = ((int)(item2.Y * (double)scale) + j) * stride + ((int)(item2.X * (double)scale) + k) * 4;
					int num2 = ((int)(item.Y * (double)scale) + j) * stride + ((int)(item.X * (double)scale) + k) * 4;
					if (num + 3 < pixels.Length && num2 + 3 < pixels.Length)
					{
						Blend(pixels, num, num2);
					}
				}
			}
		}
	}

	private static void Blend(byte[] pixels, int from, int to)
	{
		int num = pixels[from + 3];
		if (num != 0)
		{
			for (int i = 0; i < 3; i++)
			{
				pixels[to + i] = (byte)((pixels[from + i] * num + pixels[to + i] * (255 - num)) / 255);
			}
			pixels[to + 3] = byte.MaxValue;
		}
	}
}
