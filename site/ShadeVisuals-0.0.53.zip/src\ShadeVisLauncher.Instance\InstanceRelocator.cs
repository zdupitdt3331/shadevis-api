using System;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
namespace ShadeVisLauncher.Instance;

public static class InstanceRelocator
{
	private const int CopyBufferBytes = 1048576;

	private const long FreeSpaceReserveBytes = 536870912L;

	private const string ProbeFileName = ".shadevis-write-probe";

	private const string NotAbsoluteText = "Pick a folder on a local drive.";

	private const string SameFolderText = "The client is already installed there.";

	private const string NestedText = "The new folder cannot be inside the current installation (or the other way round).";

	private const string DriveNotReadyText = "That drive is not available.";

	private const string NotEmptyFormat = "{0} already contains files — pick an empty folder.";

	private const string NotWritableText = "The launcher cannot write to that folder. Pick another one.";

	private const string NoSpaceFormat = "Not enough free space: {0} needed, {1} free.";

	private const string MeasuringText = "Measuring the installed files...";

	private const string MovingText = "Moving the client...";

	private const string CopyingFormat = "Copying the client — {0} of {1}";

	private const string CleaningText = "Removing the old copy...";

	private static readonly string[] SizeUnits = new string[5]
	{
		"B",
		"KB",
		"MB",
		"GB",
		"TB"
	};

	private const double SizeStep = 1024.0;

	public static async Task RelocateAsync(string source, string destination, IProgress<string> status, IProgress<double> percent, CancellationToken cancel)
	{
		string from = Normalize(source);
		string to = Normalize(destination);
		Validate(from, to);
		if (!Directory.Exists(from))
		{
			Directory.CreateDirectory(to);
			return;
		}
		if (SameVolume(from, to))
		{
			status.Report("Moving the client...");
			Directory.CreateDirectory(Path.GetDirectoryName(to));
			if (Directory.Exists(to))
			{
				Directory.Delete(to);
			}
			Directory.Move(from, to);
			percent.Report(1.0);
			return;
		}
		status.Report("Measuring the installed files...");
		string[] files = Directory.GetFiles(from, "*", SearchOption.AllDirectories);
		long num = files.Sum((string file) => new FileInfo(file).Length);
		EnsureSpace(to, num);
		try
		{
			await CopyAsync(from, to, files, num, status, percent, cancel);
		}
		catch
		{
			TryDelete(to);
			throw;
		}
		status.Report("Removing the old copy...");
		TryDelete(from);
	}

	public static string Normalize(string path)
	{
		return Path.TrimEndingDirectorySeparator(Path.GetFullPath(path));
	}

	private static void Validate(string from, string to)
	{
		if (!Path.IsPathFullyQualified(to))
		{
			throw new RelocationException("Pick a folder on a local drive.");
		}
		if (string.Equals(from, to, StringComparison.OrdinalIgnoreCase))
		{
			throw new RelocationException("The client is already installed there.");
		}
		if (IsInside(to, from) || IsInside(from, to))
		{
			throw new RelocationException("The new folder cannot be inside the current installation (or the other way round).");
		}
		string pathRoot = Path.GetPathRoot(to);
		if (string.IsNullOrEmpty(pathRoot) || !new DriveInfo(pathRoot).IsReady)
		{
			throw new RelocationException("That drive is not available.");
		}
		if (Directory.Exists(to) && Directory.EnumerateFileSystemEntries(to).Any())
		{
			throw new RelocationException(string.Format("{0} already contains files — pick an empty folder.", to));
		}
		EnsureWritable(Path.GetDirectoryName(to) ?? pathRoot);
	}

	private static void EnsureWritable(string folder)
	{
		string path = Path.Combine(folder, ".shadevis-write-probe");
		try
		{
			Directory.CreateDirectory(folder);
			File.WriteAllBytes(path, default(ReadOnlySpan<byte>));
			File.Delete(path);
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
			throw new RelocationException("The launcher cannot write to that folder. Pick another one.");
		}
	}

	private static void EnsureSpace(string to, long required)
	{
		long availableFreeSpace = new DriveInfo(Path.GetPathRoot(to)).AvailableFreeSpace;
		long num = required + 536870912;
		if (availableFreeSpace < num)
		{
			throw new RelocationException(string.Format("Not enough free space: {0} needed, {1} free.", FormatSize(num), FormatSize(availableFreeSpace)));
		}
	}

	private static async Task CopyAsync(string from, string to, string[] files, long total, IProgress<string> status, IProgress<double> percent, CancellationToken cancel)
	{
		string[] directories = Directory.GetDirectories(from, "*", SearchOption.AllDirectories);
		foreach (string path in directories)
		{
			Directory.CreateDirectory(Path.Combine(to, Path.GetRelativePath(from, path)));
		}
		Directory.CreateDirectory(to);
		string totalText = FormatSize(total);
		byte[] buffer = new byte[1048576];
		long copied = 0L;
		foreach (string file in files)
		{
			cancel.ThrowIfCancellationRequested();
			string target = Path.Combine(to, Path.GetRelativePath(from, file));
			FileStream input = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read, 1048576, FileOptions.Asynchronous | FileOptions.SequentialScan);
			try
			{
				FileStream output = new FileStream(target, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1048576, FileOptions.Asynchronous);
				try
				{
					while (true)
					{
						int num;
						int read = (num = await input.ReadAsync(buffer, cancel));
						if (num <= 0)
						{
							break;
						}
						await output.WriteAsync(buffer.AsMemory(0, read), cancel);
						copied += read;
					}
				}
				finally
				{
					if (output != null)
					{
						await output.DisposeAsync();
					}
				}
			}
			finally
			{
				if (input != null)
				{
					await input.DisposeAsync();
				}
			}
			File.SetLastWriteTimeUtc(target, File.GetLastWriteTimeUtc(file));
			percent.Report((total == 0L) ? 1.0 : ((double)copied / (double)total));
			status.Report(string.Format("Copying the client — {0} of {1}", FormatSize(copied), totalText));
		}
	}

	private static bool SameVolume(string from, string to)
	{
		return string.Equals(Path.GetPathRoot(from), Path.GetPathRoot(to), StringComparison.OrdinalIgnoreCase);
	}

	private static bool IsInside(string candidate, string folder)
	{
		ReadOnlySpan<char> readOnlySpan = folder;
		char reference = Path.DirectorySeparatorChar;
		return candidate.StartsWith(string.Concat(readOnlySpan, new ReadOnlySpan<char>(ref reference)), StringComparison.OrdinalIgnoreCase);
	}

	private static void TryDelete(string folder)
	{
		try
		{
			if (Directory.Exists(folder))
			{
				Directory.Delete(folder, recursive: true);
			}
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
		}
	}

	private static string FormatSize(long bytes)
	{
		double num = bytes;
		int num2 = 0;
		while (num >= 1024.0 && num2 < SizeUnits.Length - 1)
		{
			num /= 1024.0;
			num2++;
		}
		DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 2);
		defaultInterpolatedStringHandler.AppendFormatted(num, "0.#");
		defaultInterpolatedStringHandler.AppendLiteral(" ");
		defaultInterpolatedStringHandler.AppendFormatted(SizeUnits[num2]);
		return defaultInterpolatedStringHandler.ToStringAndClear();
	}
}
