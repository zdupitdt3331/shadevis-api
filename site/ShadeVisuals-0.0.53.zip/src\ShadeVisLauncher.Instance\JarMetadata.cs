using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public readonly record struct JarMetadata(string? Id, string? Name, string? Version)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("JarMetadata");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		builder.Append("Id = ");
		builder.Append((object?)Id);
		builder.Append(", Name = ");
		builder.Append((object?)Name);
		builder.Append(", Version = ");
		builder.Append((object?)Version);
		return true;
	}
}
