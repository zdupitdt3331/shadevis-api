using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Services;

public sealed record CosmeticCategory(string Slot, string Title, IReadOnlyList<CosmeticEntry> Entries)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("CosmeticCategory");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Slot = ");
		builder.Append((object?)Slot);
		builder.Append(", Title = ");
		builder.Append((object?)Title);
		builder.Append(", Entries = ");
		builder.Append(Entries);
		return true;
	}
}
