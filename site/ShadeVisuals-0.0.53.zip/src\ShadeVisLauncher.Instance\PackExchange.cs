using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;
namespace ShadeVisLauncher.Instance;

public static class PackExchange
{
	public const string Extension = ".evopack";

	public const string Filter = "ShadeVis mod pack (*.evopack)|*.evopack";

	private const int Format = 1;

	private const int MaxMods = 150;

	private const string IconPrefix = "https://";

	private const string JarSuffix = ".jar";

	private const string InstallFormat = "Installing {0}...";

	private static readonly JsonSerializerOptions Wire = new JsonSerializerOptions
	{
		PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
		PropertyNameCaseInsensitive = true,
		DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
		WriteIndented = true
	};

	public static PackExport Write(ModPack pack, IReadOnlyList<ModEntry> catalog, string path)
	{
		Dictionary<string, ModEntry> dictionary = new Dictionary<string, ModEntry>(StringComparer.OrdinalIgnoreCase);
		foreach (ModEntry item in catalog)
		{
			dictionary[item.File] = item;
		}
		List<PackManifestMod> list = new List<PackManifestMod>();
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		int num = 0;
		foreach (string file in pack.Files)
		{
			if (!dictionary.TryGetValue(file, out var value) || !ManagedMods.Contains(value.Slug))
			{
				if ((object)value == null || value.ProjectId.Length == 0 || list.Count == 150)
				{
					num++;
				}
				else if (hashSet.Add(value.ProjectId))
				{
					list.Add(new PackManifestMod(value.ProjectId, value.Slug, value.Title, value.File, value.VersionNumber, Icon(value.IconUrl)));
				}
			}
		}
		if (list.Count > 0)
		{
			Directory.CreateDirectory(Path.GetDirectoryName(path));
			File.WriteAllText(path, JsonSerializer.Serialize(new PackManifest(1, pack.Name, list), Wire));
		}
		return new PackExport(path, list.Count, num);
	}

	public static PackManifest? Read(string path)
	{
		try
		{
			PackManifest packManifest = JsonSerializer.Deserialize<PackManifest>(File.ReadAllText(path), Wire);
			return Valid(packManifest) ? packManifest : null;
		}
		catch (Exception ex) when (((ex is IOException || ex is JsonException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
			return null;
		}
	}

	public static async Task<PackImport> ImportAsync(PackManifest manifest, string fallbackName, PackLibrary packs, ModCatalog catalog, IProgress<string> status, CancellationToken cancel)
	{
		List<string> files = new List<string>();
		int missing = 0;
		foreach (PackManifestMod mod in manifest.Mods)
		{
			cancel.ThrowIfCancellationRequested();
			string text = Installed(catalog, mod.ProjectId);
			if (text != null)
			{
				Take(files, text);
				continue;
			}
			status.Report(string.Format(CultureInfo.CurrentCulture, "Installing {0}...", Label(mod)));
			try
			{
				await catalog.InstallAsync(mod.ProjectId, status, cancel);
			}
			catch (Exception ex) when (((ex is HttpRequestException || ex is JsonException || ex is IOException || ex is InvalidOperationException) ? 1 : 0) != 0)
			{
				missing++;
				continue;
			}
			string text2 = Installed(catalog, mod.ProjectId);
			if (text2 == null)
			{
				missing++;
			}
			else
			{
				Take(files, text2);
			}
		}
		string name = ((manifest.Name.Trim().Length > 0) ? manifest.Name.Trim() : fallbackName);
		return new PackImport(packs.Create(name, files).Name, files.Count, missing);
	}

	private static void Take(List<string> files, string file)
	{
		if (!files.Contains<string>(file, StringComparer.OrdinalIgnoreCase))
		{
			files.Add(file);
		}
	}

	private static string? Installed(ModCatalog catalog, string projectId)
	{
		foreach (ModEntry item in catalog.Entries())
		{
			if (string.Equals(item.ProjectId, projectId, StringComparison.OrdinalIgnoreCase) && catalog.Locate(item.File) != null)
			{
				return item.File;
			}
		}
		return null;
	}

	private static string Label(PackManifestMod mod)
	{
		if (mod.Title.Length <= 0)
		{
			if (mod.Slug.Length <= 0)
			{
				return mod.File;
			}
			return mod.Slug;
		}
		return mod.Title;
	}

	private static bool Valid(PackManifest? manifest)
	{
		if ((object)manifest == null || manifest.Format < 1 || manifest.Format > 1 || manifest.Mods == null)
		{
			return false;
		}
		if (manifest.Mods.Count == 0 || manifest.Mods.Count > 150)
		{
			return false;
		}
		foreach (PackManifestMod mod in manifest.Mods)
		{
			if ((object)mod == null || string.IsNullOrWhiteSpace(mod.ProjectId) || string.IsNullOrWhiteSpace(mod.File))
			{
				return false;
			}
			if (!mod.File.EndsWith(".jar", StringComparison.OrdinalIgnoreCase) || mod.File.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
			{
				return false;
			}
		}
		return true;
	}

	private static string? Icon(string? url)
	{
		if (url == null || !url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
		{
			return null;
		}
		return url;
	}
}
