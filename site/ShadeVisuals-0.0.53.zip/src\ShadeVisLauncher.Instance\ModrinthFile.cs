using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public readonly record struct ModrinthFile(string Name, string Url, string Sha1)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("ModrinthFile");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		builder.Append("Name = ");
		builder.Append((object?)Name);
		builder.Append(", Url = ");
		builder.Append((object?)Url);
		builder.Append(", Sha1 = ");
		builder.Append((object?)Sha1);
		return true;
	}
}
