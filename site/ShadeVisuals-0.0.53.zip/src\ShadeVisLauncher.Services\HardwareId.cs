using System;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

namespace ShadeVisLauncher.Services;

public static class HardwareId
{
	private const string CryptographyKey = "SOFTWARE\\Microsoft\\Cryptography";

	private const string MachineGuidValue = "MachineGuid";

	private static readonly string Salt = "shadevis|";

	private static string? _cached;

	public static string? Value => _cached ?? (_cached = Compute());

	private static string? Compute()
	{
		string text = ReadMachineGuid();
		if (string.IsNullOrWhiteSpace(text))
		{
			return null;
		}
		return Sha256Hex(Salt + text.Trim());
	}

	private static string? ReadMachineGuid()
	{
		using RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Cryptography");
		return registryKey?.GetValue("MachineGuid") as string;
	}

	private static string Sha256Hex(string input)
	{
		return Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(input)));
	}
}
