using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Services;

public sealed record CosmeticEntry(string Key, string Name)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("CosmeticEntry");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Key = ");
		builder.Append((object?)Key);
		builder.Append(", Name = ");
		builder.Append((object?)Name);
		return true;
	}
}
