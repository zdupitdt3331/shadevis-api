﻿param([ValidateSet('Debug','Release')][string]$Configuration='Release')
$ErrorActionPreference='Stop'
$projectPath=Split-Path $PSScriptRoot -Parent
$env:DOTNET_CLI_TELEMETRY_OPTOUT='1'
$env:DOTNET_SKIP_FIRST_TIME_EXPERIENCE='1'
$dotnetPath=$env:SHADE_DOTNET_EXE
if (!$dotnetPath) {
  $candidate=Get-Command dotnet -ErrorAction SilentlyContinue
  if ($candidate -and ((& $candidate.Source --list-sdks) -match '^9\.')) { $dotnetPath=$candidate.Source }
}
if (!$dotnetPath) {
  $sdkDirectory=Join-Path $projectPath '.tools/dotnet'
  $dotnetPath=Join-Path $sdkDirectory 'dotnet.exe'
  if (!(Test-Path -LiteralPath $dotnetPath)) {
    $version='9.0.318'
    $expectedHash='d961a84ebcbc316f06c98d16958422f7bb1b3a1f29b5d6011cabf59984390690ff669c3dd9b739554ad00771d6393dbbde6bdb14da81faa7fe499f59501864b6'
    $archive=Join-Path $projectPath '.tools/sdk.zip'
    New-Item -ItemType Directory -Force $sdkDirectory | Out-Null
    Write-Host 'Downloading Microsoft .NET 9 SDK...'
    Invoke-WebRequest "https://builds.dotnet.microsoft.com/dotnet/Sdk/$version/dotnet-sdk-$version-win-x64.zip" -OutFile $archive -UseBasicParsing
    if ((Get-FileHash -LiteralPath $archive -Algorithm SHA512).Hash -ne $expectedHash) { throw 'SDK checksum mismatch' }
    Expand-Archive -LiteralPath $archive -DestinationPath $sdkDirectory -Force
  }
}
$outputPath=Join-Path $projectPath 'dist/win-x64'
& $dotnetPath publish (Join-Path $projectPath 'ShadeVisLauncher.csproj') -c $Configuration -r win-x64 --self-contained true -o $outputPath --nologo
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$builtExe = Join-Path $outputPath 'ShadeVisLauncher.exe'
$namedExe = Join-Path $outputPath 'shade_launcher.exe'
if (Test-Path -LiteralPath $builtExe) { Move-Item -LiteralPath $builtExe -Destination $namedExe -Force }
& $dotnetPath run --project (Join-Path $PSScriptRoot 'ArtifactChecks/ArtifactChecks.csproj') -c Release -- (Join-Path $outputPath 'ShadeVisLauncher.dll') $projectPath
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$config=Get-Content -LiteralPath (Join-Path $outputPath 'ShadeVisLauncher.runtimeconfig.json') -Raw | ConvertFrom-Json
if ($config.runtimeOptions.framework -or $config.runtimeOptions.frameworks) { throw 'Output requires external .NET runtime' }
foreach ($file in @('hostfxr.dll','hostpolicy.dll','coreclr.dll','System.Private.CoreLib.dll','PresentationFramework.dll')) {
  if (!(Test-Path -LiteralPath (Join-Path $outputPath $file))) { throw "Missing runtime: $file" }
}
Write-Host "PASS: self-contained .NET/WPF runtime"
Write-Host "Built: $outputPath/shade_launcher.exe"
