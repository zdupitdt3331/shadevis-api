using System;
using System.IO;
using System.Text;

namespace ShadeVisLauncher.Services;

/// <summary>Привязка лаунчера к железу (HWID) и проверка при старте.</summary>
public static class HwidGuard
{
	private const string FolderName = "ShadeVis";

	private const string BindingFileName = "hwid.txt";

	public static string Path
	{
		get
		{
			string folder = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), FolderName);
			try
			{
				Directory.CreateDirectory(folder);
			}
			catch (Exception ex) when (IsAccessError(ex))
			{
			}
			return System.IO.Path.Combine(folder, BindingFileName);
		}
	}

	private static bool IsAccessError(Exception error)
	{
		return error is IOException || error is UnauthorizedAccessException || error is System.Security.SecurityException;
	}

	public static string? Raw => HardwareId.Value;

	public static string Display => Format(HardwareId.Value);

	public static bool Enforce(out string reason)
	{
		reason = string.Empty;
		string? current = HardwareId.Value;
		string path = Path;
		if (string.IsNullOrEmpty(current))
		{
			reason = "Не удалось определить HWID этого компьютера.";
			return false;
		}
		string bound = string.Empty;
		try
		{
			if (File.Exists(path))
			{
				bound = File.ReadAllText(path).Trim();
			}
		}
		catch (Exception ex) when (IsAccessError(ex))
		{
		}
		if (bound.Length == 0)
		{
			try
			{
				File.WriteAllText(path, current);
			}
			catch (Exception ex) when (IsAccessError(ex))
			{
			}
			return true;
		}
		if (string.Equals(bound, current, StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		reason = "Лаунчер привязан к другому компьютеру.\n\nТекущий HWID: " + Format(current) + "\nПривязанный HWID: " + Format(bound) + "\n\nФайл привязки: " + path;
		return false;
	}

	public static string Format(string? id)
	{
		if (string.IsNullOrEmpty(id))
		{
			return "unknown";
		}
		StringBuilder builder = new StringBuilder(id.Length + id.Length / 4);
		for (int i = 0; i < id.Length; i++)
		{
			if (i > 0 && i % 4 == 0)
			{
				builder.Append('-');
			}
			builder.Append(char.ToUpperInvariant(id[i]));
		}
		return builder.ToString();
	}
}
