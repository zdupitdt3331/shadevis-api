using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
namespace ShadeVisLauncher.Instance;

public sealed class PackLibrary
{
	private readonly record struct MoveTally(int Moved, int Failed)
	{
		[CompilerGenerated]
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("MoveTally");
			stringBuilder.Append(" { ");
			if (PrintMembers(stringBuilder))
			{
				stringBuilder.Append(' ');
			}
			stringBuilder.Append('}');
			return stringBuilder.ToString();
		}

		[CompilerGenerated]
		private bool PrintMembers(StringBuilder builder)
		{
			builder.Append("Moved = ");
			builder.Append(Moved.ToString());
			builder.Append(", Failed = ");
			builder.Append(Failed.ToString());
			return true;
		}
	}

	private sealed record PackManifest(string? Active, List<ModPack>? Packs)
	{
		[CompilerGenerated]
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("PackManifest");
			stringBuilder.Append(" { ");
			if (PrintMembers(stringBuilder))
			{
				stringBuilder.Append(' ');
			}
			stringBuilder.Append('}');
			return stringBuilder.ToString();
		}

		[CompilerGenerated]
		private bool PrintMembers(StringBuilder builder)
		{
			RuntimeHelpers.EnsureSufficientExecutionStack();
			builder.Append("Active = ");
			builder.Append((object?)Active);
			builder.Append(", Packs = ");
			builder.Append(Packs);
			return true;
		}
	}

	[CompilerGenerated]
	private InstancePaths _003Cpaths_003EP;

	public const string DefaultPackName = "Default";

	private const string RestoreFormat = "Restoring {0}...";

	private const int NameLimit = 48;

	private const int MoveAttempts = 6;

	private const int MoveBackoffMilliseconds = 120;

	private static readonly JsonSerializerOptions ManifestFormat = new JsonSerializerOptions
	{
		WriteIndented = true
	};

	private readonly List<ModPack> packs;

	private string? activeId;

	private bool loaded;

	public IReadOnlyList<ModPack> Packs
	{
		get
		{
			Load();
			return packs;
		}
	}

	public ModPack? Active
	{
		get
		{
			Load();
			return packs.Find((ModPack pack) => pack.Id == activeId) ?? packs.FirstOrDefault();
		}
	}

	public PackLibrary(InstancePaths paths)
	{
		_003Cpaths_003EP = paths;
		packs = new List<ModPack>();
		
	}

	public ModPack Seed(IEnumerable<string> files)
	{
		Load();
		ModPack active = Active;
		if (active != null)
		{
			return active;
		}
		ModPack modPack = Add("Default", files);
		activeId = modPack.Id;
		Save();
		return modPack;
	}

	public ModPack Create(string name, IEnumerable<string> files)
	{
		Load();
		ModPack result = Add(name, files);
		Save();
		return result;
	}

	public bool Rename(ModPack pack, string name)
	{
		string text = Clean(name);
		if (text.Length == 0 || text == pack.Name)
		{
			return false;
		}
		pack.Name = text;
		Save();
		return true;
	}

	public bool Delete(ModPack pack)
	{
		Load();
		if (packs.Count <= 1 || !packs.Remove(pack))
		{
			return false;
		}
		if (activeId == pack.Id)
		{
			activeId = packs[0].Id;
		}
		Save();
		return true;
	}

	public bool Activate(ModPack pack)
	{
		Load();
		if (activeId == pack.Id)
		{
			return false;
		}
		activeId = pack.Id;
		Save();
		return true;
	}

	public bool Include(ModPack pack, string file, bool included)
	{
		string file2 = file;
		if (pack.Files.Exists((string name) => Same(name, file2)) == included)
		{
			return false;
		}
		if (included)
		{
			pack.Files.Add(file2);
		}
		else
		{
			pack.Files.RemoveAll((string name) => Same(name, file2));
		}
		Save();
		return true;
	}

	public bool Adopt(ModPack pack, IEnumerable<string> files)
	{
		Load();
		bool flag = false;
		foreach (string file in files)
		{
			if (!packs.Exists((ModPack known) => known.Files.Exists((string name) => Same(name, file))))
			{
				pack.Files.Add(file);
				flag = true;
			}
		}
		if (flag)
		{
			Save();
		}
		return flag;
	}

	public bool Forget(string file)
	{
		string file2 = file;
		Load();
		bool flag = false;
		foreach (ModPack pack in packs)
		{
			flag |= pack.Files.RemoveAll((string name) => Same(name, file2)) > 0;
		}
		if (flag)
		{
			Save();
		}
		return flag;
	}

	public async Task<PackSync> ApplyAsync(ModPack pack, ModCatalog catalog, IProgress<string> status, CancellationToken cancel)
	{
		Directory.CreateDirectory(_003Cpaths_003EP.Mods);
		Directory.CreateDirectory(_003Cpaths_003EP.ModStore);
		Load();
		bool num = AdoptLoose(pack, cancel);
		int linked = LinkDependencies(pack, cancel);
		if (num || linked > 0)
		{
			Save();
		}
		HashSet<string> target = new HashSet<string>(pack.Files, StringComparer.OrdinalIgnoreCase);
		MoveTally moveTally = Store(target, cancel);
		int stored = moveTally.Moved;
		int failed2 = moveTally.Failed;
		int activated = 0;
		int restored = 0;
		int missing = 0;
		bool dirty = false;
		for (int index = 0; index < pack.Files.Count; index++)
		{
			cancel.ThrowIfCancellationRequested();
			string file = pack.Files[index];
			if (File.Exists(Path.Combine(_003Cpaths_003EP.Mods, file)))
			{
				continue;
			}
			string text = Path.Combine(_003Cpaths_003EP.ModStore, file);
			if (File.Exists(text))
			{
				if (Move(text, Path.Combine(_003Cpaths_003EP.Mods, file)))
				{
					activated++;
				}
				else
				{
					failed2++;
				}
				continue;
			}
			status.Report(string.Format(CultureInfo.CurrentCulture, "Restoring {0}...", file));
			string text2 = await catalog.RestoreAsync(file, status, cancel);
			if (text2 == null)
			{
				missing++;
				continue;
			}
			restored++;
			if (!string.Equals(text2, file, StringComparison.OrdinalIgnoreCase))
			{
				pack.Files[index] = text2;
				target.Add(text2);
				dirty = true;
			}
		}
		if (dirty)
		{
			Save();
		}
		IReadOnlyList<ModConflict> readOnlyList = ParkConflicts(cancel);
		failed2 += readOnlyList.Count((ModConflict conflict) => File.Exists(Path.Combine(_003Cpaths_003EP.Mods, conflict.DisabledFile)));
		return new PackSync(activated, stored, restored, missing, failed2, linked, readOnlyList);
	}

	public IReadOnlyList<ModConflict> ParkConflicts(CancellationToken cancel)
	{
		if (!Directory.Exists(_003Cpaths_003EP.Mods))
		{
			return Array.Empty<ModConflict>();
		}
		Directory.CreateDirectory(_003Cpaths_003EP.ModStore);
		Dictionary<string, string> dictionary = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		foreach (string item in Directory.EnumerateFiles(_003Cpaths_003EP.Mods, "*.jar"))
		{
			cancel.ThrowIfCancellationRequested();
			dictionary[Path.GetFileName(item)] = ModJar.IdOf(item);
		}
		IReadOnlyList<ModConflict> readOnlyList = ModConflicts.Resolve(dictionary);
		foreach (ModConflict item2 in readOnlyList)
		{
			Move(Path.Combine(_003Cpaths_003EP.Mods, item2.DisabledFile), Path.Combine(_003Cpaths_003EP.ModStore, item2.DisabledFile));
		}
		return readOnlyList;
	}

	private bool AdoptLoose(ModPack pack, CancellationToken cancel)
	{
		bool result = false;
		foreach (string item in Directory.EnumerateFiles(_003Cpaths_003EP.Mods, "*.jar"))
		{
			cancel.ThrowIfCancellationRequested();
			string name = Path.GetFileName(item);
			if (!packs.Exists((ModPack known) => known.Files.Exists((string file) => Same(file, name))) && !ManagedMods.Contains(ModJar.IdOf(item)))
			{
				pack.Files.Add(name);
				result = true;
			}
		}
		return result;
	}

	private int LinkDependencies(ModPack pack, CancellationToken cancel)
	{
		Dictionary<string, ModManifest> dictionary = Manifests(cancel);
		HashSet<string> hashSet = new HashSet<string>(pack.Files, StringComparer.OrdinalIgnoreCase);
		HashSet<string> hashSet2 = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		Dictionary<string, string> dictionary2 = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		Queue<ModManifest> queue = new Queue<ModManifest>();
		foreach (var (text2, modManifest2) in dictionary)
		{
			if (hashSet.Contains(text2) || ManagedMods.Contains(modManifest2.Id))
			{
				hashSet2.UnionWith(modManifest2.Provides);
				queue.Enqueue(modManifest2);
				continue;
			}
			foreach (string provide in modManifest2.Provides)
			{
				dictionary2.TryAdd(provide, text2);
			}
		}
		int num = 0;
		while (queue.Count > 0)
		{
			foreach (string depend in queue.Dequeue().Depends)
			{
				if (!hashSet2.Contains(depend) && dictionary2.TryGetValue(depend, out var value) && hashSet.Add(value))
				{
					ModManifest modManifest3 = dictionary[value];
					pack.Files.Add(value);
					hashSet2.UnionWith(modManifest3.Provides);
					queue.Enqueue(modManifest3);
					num++;
				}
			}
		}
		return num;
	}

	private Dictionary<string, ModManifest> Manifests(CancellationToken cancel)
	{
		Dictionary<string, ModManifest> dictionary = new Dictionary<string, ModManifest>(StringComparer.OrdinalIgnoreCase);
		string[] array = new string[2] { _003Cpaths_003EP.Mods, _003Cpaths_003EP.ModStore };
		for (int i = 0; i < array.Length; i++)
		{
			foreach (string item in Directory.EnumerateFiles(array[i], "*.jar"))
			{
				cancel.ThrowIfCancellationRequested();
				string fileName = Path.GetFileName(item);
				if (!dictionary.ContainsKey(fileName))
				{
					dictionary[fileName] = ModJar.Manifest(item);
				}
			}
		}
		return dictionary;
	}

	private MoveTally Store(HashSet<string> target, CancellationToken cancel)
	{
		int num = 0;
		int num2 = 0;
		foreach (string item in Directory.EnumerateFiles(_003Cpaths_003EP.Mods, "*.jar"))
		{
			cancel.ThrowIfCancellationRequested();
			string fileName = Path.GetFileName(item);
			if (!target.Contains(fileName) && !ManagedMods.Contains(ModJar.IdOf(item)))
			{
				if (Move(item, Path.Combine(_003Cpaths_003EP.ModStore, fileName)))
				{
					num++;
				}
				else
				{
					num2++;
				}
			}
		}
		return new MoveTally(num, num2);
	}

	private ModPack Add(string name, IEnumerable<string> files)
	{
		string text = Clean(name);
		ModPack modPack = new ModPack
		{
			Id = Guid.NewGuid().ToString("n"),
			Name = ((text.Length > 0) ? text : "Default"),
			Files = files.Distinct<string>(StringComparer.OrdinalIgnoreCase).ToList()
		};
		packs.Add(modPack);
		return modPack;
	}

	private static bool Same(string left, string right)
	{
		return string.Equals(left, right, StringComparison.OrdinalIgnoreCase);
	}

	private static string Clean(string name)
	{
		string text = name.Trim();
		if (text.Length <= 48)
		{
			return text;
		}
		return text.Substring(0, 48);
	}

	private static bool Move(string source, string destination)
	{
		int num = 1;
		while (true)
		{
			try
			{
				File.Move(source, destination, overwrite: true);
				return true;
			}
			catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
			{
				if (num == 6)
				{
					return false;
				}
				Thread.Sleep(120);
			}
			num++;
		}
	}

	private void Load()
	{
		if (loaded)
		{
			return;
		}
		loaded = true;
		try
		{
			if (!File.Exists(_003Cpaths_003EP.PacksManifest))
			{
				return;
			}
			PackManifest packManifest = JsonSerializer.Deserialize<PackManifest>(File.ReadAllText(_003Cpaths_003EP.PacksManifest));
			if ((object)packManifest != null)
			{
				packs.AddRange(packManifest.Packs?.Where((ModPack pack) => pack.Id.Length > 0) ?? Enumerable.Empty<ModPack>());
				activeId = packManifest.Active;
			}
		}
		catch (Exception ex) when (((ex is IOException || ex is JsonException) ? 1 : 0) != 0)
		{
		}
	}

	private void Save()
	{
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(_003Cpaths_003EP.PacksManifest));
			File.WriteAllText(_003Cpaths_003EP.PacksManifest, JsonSerializer.Serialize(new PackManifest(activeId, packs), ManifestFormat));
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
		}
	}
}
