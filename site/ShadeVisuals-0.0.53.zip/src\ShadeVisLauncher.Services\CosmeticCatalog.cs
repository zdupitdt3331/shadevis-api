using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
namespace ShadeVisLauncher.Services;

public static class CosmeticCatalog
{
	public const string CapeSlot = "cape";

	public const string NametagSlot = "nametag";

	public const string MeleeSlot = "melee";

	private const string AssetsFolder = "assets";

	private const string ViewerFolder = "viewer";

	private const string NamesFile = "cosmetics-names.json";

	private const string CapesFile = "capes.json";

	private const string CosmeticsFolder = "cosmetics";

	private const string MeleeIconFolder = "icon";

	private const string IconExtension = ".png";

	private const string CapeGlyph = "\ue7ee";

	private const string WingGlyph = "\ue709";

	private const string BackpackGlyph = "\ue7b8";

	private const string HatGlyph = "\ue7ef";

	private const string NametagGlyph = "\ue8ec";

	private static readonly (string Slot, string Group, string Title)[] Categories = new(string, string, string)[8]
	{
		("cape", "capes", "Capes"),
		("wing", "wings", "Wings"),
		("hat", "hats", "Hats"),
		("backpack", "backpacks", "Backpacks"),
		("companion", "companions", "Companions"),
		("melee", "melee", "Knives"),
		("nametag", "nametags", "Nametags"),
		("model", "models", "Models")
	};

	private static readonly Dictionary<string, string[]> NametagGradients = new Dictionary<string, string[]>(StringComparer.Ordinal)
	{
		["rainbow"] = new string[6]
		{
			"#FF4D4D",
			"#FFD166",
			"#4CE86A",
			"#37E8FF",
			"#7A5CFF",
			"#FF5CD0"
		},
		["sunset"] = new string[3]
		{
			"#FFD166",
			"#FF7A45",
			"#FF3D7A"
		},
		["ocean"] = new string[3]
		{
			"#6EF0FF",
			"#2F86FF",
			"#2A3FE0"
		},
		["toxic"] = new string[3]
		{
			"#E7FF6B",
			"#4CE86A",
			"#0FA36B"
		},
		["ember"] = new string[3]
		{
			"#FFE066",
			"#FF7A1A",
			"#E01F1F"
		},
		["nebula"] = new string[3]
		{
			"#7A5CFF",
			"#B44DFF",
			"#FF5CD0"
		},
		["frost"] = new string[3]
		{
			"#FFFFFF",
			"#A8E7FF",
			"#5AA8FF"
		},
		["sakura"] = new string[3]
		{
			"#FFD1EC",
			"#FF8FC5",
			"#E0489B"
		},
		["midnight"] = new string[3]
		{
			"#9AA8FF",
			"#5B63D3",
			"#2B1B6B"
		},
		["gold"] = new string[4]
		{
			"#FFEFB5",
			"#FFC94D",
			"#FFF6DA",
			"#E0A21F"
		}
	};

	private static Dictionary<string, string>? capeTextures;

	public static string Folder => Path.Combine(AppContext.BaseDirectory, "assets", "viewer");

	public static IReadOnlyList<CosmeticCategory> Load()
	{
		Dictionary<string, Dictionary<string, string>> dictionary = ReadNames();
		List<CosmeticCategory> list = new List<CosmeticCategory>(Categories.Length);
		(string, string, string)[] categories = Categories;
		for (int i = 0; i < categories.Length; i++)
		{
			var (slot, key, title) = categories[i];
			if (!dictionary.TryGetValue(key, out var value) || value.Count == 0)
			{
				continue;
			}
			List<CosmeticEntry> list2 = new List<CosmeticEntry>(value.Count);
			foreach (KeyValuePair<string, string> item in value)
			{
				list2.Add(new CosmeticEntry(item.Key, item.Value));
			}
			list.Add(new CosmeticCategory(slot, title, list2));
		}
		return list;
	}

	public static string[]? Gradient(string key)
	{
		if (!NametagGradients.TryGetValue(key, out string[] value))
		{
			return null;
		}
		return value;
	}

	public static byte[]? CapeTexture(string key)
	{
		if (capeTextures == null)
		{
			capeTextures = ReadCapes();
		}
		if (!capeTextures.TryGetValue(key, out string value))
		{
			return null;
		}
		try
		{
			return Convert.FromBase64String(value);
		}
		catch (FormatException)
		{
			return null;
		}
	}

	public static byte[]? MeleeIcon(string key)
	{
		if (key.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
		{
			return null;
		}
		try
		{
			_003C_003Ey__InlineArray5<string> buffer = default(_003C_003Ey__InlineArray5<string>);
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray5<string>, string>(ref buffer, 0) = Folder;
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray5<string>, string>(ref buffer, 1) = "cosmetics";
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray5<string>, string>(ref buffer, 2) = "melee";
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray5<string>, string>(ref buffer, 3) = "icon";
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray5<string>, string>(ref buffer, 4) = key + ".png";
			string path = Path.Combine(global::_003CPrivateImplementationDetails_003E.InlineArrayAsReadOnlySpan<_003C_003Ey__InlineArray5<string>, string>(in buffer, 5));
			return File.Exists(path) ? File.ReadAllBytes(path) : null;
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
			return null;
		}
	}

	private static Dictionary<string, Dictionary<string, string>> ReadNames()
	{
		try
		{
			string path = Path.Combine(Folder, "cosmetics-names.json");
			return File.Exists(path) ? (JsonSerializer.Deserialize<Dictionary<string, Dictionary<string, string>>>(File.ReadAllText(path)) ?? new Dictionary<string, Dictionary<string, string>>()) : new Dictionary<string, Dictionary<string, string>>();
		}
		catch (Exception ex) when (((ex is IOException || ex is JsonException) ? 1 : 0) != 0)
		{
			return new Dictionary<string, Dictionary<string, string>>();
		}
	}

	private static Dictionary<string, string> ReadCapes()
	{
		try
		{
			string path = Path.Combine(Folder, "capes.json");
			return File.Exists(path) ? (JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(path)) ?? new Dictionary<string, string>()) : new Dictionary<string, string>();
		}
		catch (Exception ex) when (((ex is IOException || ex is JsonException) ? 1 : 0) != 0)
		{
			return new Dictionary<string, string>();
		}
	}
}
