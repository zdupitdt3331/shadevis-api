using System;
using System.Net;
using System.Net.Http;

namespace ShadeVisLauncher.Services;

public static class LauncherHttp
{
	public static HttpClient Create(TimeSpan timeout)
	{
		SocketsHttpHandler handler = new SocketsHttpHandler
		{
			AutomaticDecompression = DecompressionMethods.All,
			ConnectTimeout = TimeSpan.FromSeconds(20),
			PooledConnectionLifetime = TimeSpan.FromMinutes(5),
			AllowAutoRedirect = true
		};
		HttpClient client = new HttpClient(handler)
		{
			Timeout = timeout
		};
		client.DefaultRequestHeaders.UserAgent.ParseAdd("ShadeVisLauncher/1.1 (contact: local build)");
		client.DefaultRequestHeaders.Accept.ParseAdd("application/json");
		return client;
	}
}
