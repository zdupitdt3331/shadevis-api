using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using ShadeVisLauncher.Ui;

namespace ShadeVisLauncher.Services;

public sealed class NameMcClient
{
	[CompilerGenerated]
	private HiddenBrowser _003Cbrowser_003EP;

	[CompilerGenerated]
	private HttpDownloader _003Cdownloader_003EP;

	public const string TrendingDaily = "trending/daily";

	public const string TrendingWeekly = "trending/weekly";

	public const string Newest = "new";

	public const string Random = "random";

	private const string TagFormat = "tag/{0}";

	private const string ListUrl = "https://namemc.com/minecraft-skins/{0}?page={1}";

	private const string TextureUrl = "https://s.namemc.com/i/{0}.png";

	private const string ThumbnailUrl = "https://s.namemc.com/3d/skin/body.png?id={0}&theta=-25&scale=8";

	private const string SkinPrefix = "/skin/";

	private const int MaxNameLength = 24;

	private const string ExtractScript = "JSON.stringify([...document.querySelectorAll('a[href^=\"/skin/\"]')].map((card) => {\n  const header = card.querySelector('.card-header span');\n  return {\n    id: (card.getAttribute('href') || '').split('/').pop(),\n    name: header ? header.textContent.trim() : ''\n  };\n}).filter((entry) => /^[0-9a-f]{8,32}$/.test(entry.id)))";

	public NameMcClient(HiddenBrowser browser, HttpDownloader downloader)
	{
		_003Cbrowser_003EP = browser;
		_003Cdownloader_003EP = downloader;
		
	}

	public static string Tag(string query)
	{
		return string.Format("tag/{0}", Uri.EscapeDataString(query.Trim()));
	}

	public static string Thumbnail(string id)
	{
		return string.Format("https://s.namemc.com/3d/skin/body.png?id={0}&theta=-25&scale=8", id);
	}

	public async Task<IReadOnlyList<NameMcSkin>> ListAsync(string category, int page, CancellationToken cancel)
	{
		string url = string.Format(CultureInfo.InvariantCulture, "https://namemc.com/minecraft-skins/{0}?page={1}", category, page);
		string text = await _003Cbrowser_003EP.EvaluateAsync(url, "JSON.stringify([...document.querySelectorAll('a[href^=\"/skin/\"]')].map((card) => {\n  const header = card.querySelector('.card-header span');\n  return {\n    id: (card.getAttribute('href') || '').split('/').pop(),\n    name: header ? header.textContent.trim() : ''\n  };\n}).filter((entry) => /^[0-9a-f]{8,32}$/.test(entry.id)))", cancel);
		if (text == null)
		{
			return Array.Empty<NameMcSkin>();
		}
		string text2 = JsonSerializer.Deserialize<string>(text);
		if (text2 == null)
		{
			return Array.Empty<NameMcSkin>();
		}
		List<NameMcSkin> list = new List<NameMcSkin>();
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		using JsonDocument jsonDocument = JsonDocument.Parse(text2);
		foreach (JsonElement item in jsonDocument.RootElement.EnumerateArray())
		{
			string text3 = Text(item, "id");
			if (text3.Length != 0 && hashSet.Add(text3))
			{
				string text4 = Text(item, "name");
				list.Add(new NameMcSkin(text3, Shorten((text4.Length == 0) ? text3 : text4)));
			}
		}
		return list;
	}

	public Task<byte[]> TextureAsync(string id, CancellationToken cancel)
	{
		return _003Cdownloader_003EP.GetBytesAsync(string.Format("https://s.namemc.com/i/{0}.png", id), cancel);
	}

	public static string SkinIdFromLink(string link)
	{
		int num = link.IndexOf("/skin/", StringComparison.OrdinalIgnoreCase);
		string text;
		if (num >= 0)
		{
			int num2 = num + "/skin/".Length;
			text = link.Substring(num2, link.Length - num2);
		}
		else
		{
			text = link;
		}
		string text2 = text;
		int num3 = text2.IndexOfAny(new char[3] { '/', '?', '#' });
		return ((num3 < 0) ? text2 : text2.Substring(0, num3)).Trim();
	}

	private static string Shorten(string name)
	{
		if (name.Length > 24)
		{
			return name.Substring(0, 24);
		}
		return name;
	}

	private static string Text(JsonElement element, string property)
	{
		if (!element.TryGetProperty(property, out var value) || value.ValueKind != JsonValueKind.String)
		{
			return string.Empty;
		}
		return value.GetString() ?? string.Empty;
	}
}
