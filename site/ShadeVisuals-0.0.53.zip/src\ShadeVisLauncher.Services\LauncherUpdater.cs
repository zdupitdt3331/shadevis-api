using System;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
namespace ShadeVisLauncher.Services;
/// <summary>Manual updates preserve this distribution's privacy settings.</summary>
public sealed class LauncherUpdater
{
    public static Version Current => Assembly.GetExecutingAssembly().GetName().Version ?? new Version(0, 0);
    public LauncherUpdater(HttpDownloader downloader) { }
    public static void CleanupRetired() { }
    public Task EnsureLatestAsync(string? token, string? hwid, IProgress<string> status,
        IProgress<double> percent, CancellationToken cancel) => Task.CompletedTask;
}
