using System;
using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Auth;

public sealed record MicrosoftAccount(string Uuid, string Name, string RefreshToken, string AccessToken, DateTime AccessExpiresUtc)
{
	public MinecraftSession ToSession()
	{
		return new MinecraftSession(Uuid, Name, AccessToken);
	}

	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("MicrosoftAccount");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Uuid = ");
		builder.Append((object?)Uuid);
		builder.Append(", Name = ");
		builder.Append((object?)Name);
		builder.Append(", RefreshToken = ");
		builder.Append((object?)RefreshToken);
		builder.Append(", AccessToken = ");
		builder.Append((object?)AccessToken);
		builder.Append(", AccessExpiresUtc = ");
		builder.Append(AccessExpiresUtc.ToString());
		return true;
	}
}
