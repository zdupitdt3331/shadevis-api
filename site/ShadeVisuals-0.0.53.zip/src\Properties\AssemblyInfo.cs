using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Windows.Resources;

[assembly: AssemblyAssociatedContentFile("webview2loader.dll")]
[assembly: AssemblyCompany("ShadeVis")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.1.34.0")]
[assembly: AssemblyInformationalVersion("1.1.34.0")]
[assembly: AssemblyProduct("ShadeVis")]
[assembly: AssemblyTitle("ShadeVis")]
[assembly: TargetPlatform("Windows7.0")]
[assembly: SupportedOSPlatform("Windows7.0")]
[assembly: AssemblyVersion("1.1.34.0")]


[assembly: AssemblyDescription("ShadeVis")]
