using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public sealed record ModManifest(string? Id, IReadOnlySet<string> Provides, IReadOnlySet<string> Depends)
{
	public static readonly ModManifest Empty = new ModManifest(null, new HashSet<string>(), new HashSet<string>());

	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("ModManifest");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Id = ");
		builder.Append((object?)Id);
		builder.Append(", Provides = ");
		builder.Append(Provides);
		builder.Append(", Depends = ");
		builder.Append(Depends);
		return true;
	}

	[CompilerGenerated]
	private ModManifest(ModManifest original)
	{
		Id = original.Id;
		Provides = original.Provides;
		Depends = original.Depends;
	}
}
