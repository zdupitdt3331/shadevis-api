using System;
using System.IO;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher.Instance;

public sealed class InstancePaths
{
	public const string RootFolderName = "ShadeVisuals";

	public const string GameFolderName = "game";

	public const string LauncherFolderName = "launcher";

	private static readonly string[] GameFolders = new string[22]
	{
		".fabric", ".replay_cache", "assets", "config", "crash-reports", "data", "debug", "downloads", "java", "libraries",
		"logs", "mods", "mods_1.21.11", "natives", "replay_recordings", "resourcepacks", "saves", "screenshots", "shade_cache", "shade_mod",
		"shaderpacks", "usermods"
	};

	public static string DefaultRoot => Path.Combine(Path.GetPathRoot(Environment.SystemDirectory) ?? "C:\\", RootFolderName);

	public string Root { get; }

	public string Launcher { get; }

	public string Runtime { get; }

	public string Minecraft { get; }

	public string Fabric { get; }

	public string Natives { get; }

	public string Payload { get; }

	public string Agent { get; }

	public string Mods { get; }

	public string ShadeMod { get; }

	public string Graphics { get; }

	public string ModStore { get; }

	public string JavaExecutable => Path.Combine(Runtime, "bin", "javaw.exe");

	public string PayloadEnvelope => Path.Combine(Payload, "shadevis.payload");

	public string ModsManifest => Path.Combine(Launcher, "mods.json");

	public string PacksManifest => Path.Combine(Launcher, "packs.json");

	public static string RootInside(string parent)
	{
		return Path.Combine(parent, RootFolderName);
	}

	public InstancePaths()
	{
		Root = LauncherSettings.Current.InstallRoot ?? DefaultRoot;
		Launcher = Path.Combine(Root, LauncherFolderName);
		Minecraft = Path.Combine(Root, GameFolderName);
		Runtime = Path.Combine(Minecraft, "java");
		Fabric = Path.Combine(Minecraft, ".fabric");
		Natives = Path.Combine(Minecraft, "natives");
		Payload = Path.Combine(Launcher, "payload");
		Agent = Path.Combine(Launcher, "agent", "evo-agent.jar");
		Mods = Path.Combine(Minecraft, "mods");
		ShadeMod = Path.Combine(Minecraft, "shade_mod");
		Graphics = Path.Combine(Launcher, "graphics");
		ModStore = Path.Combine(Launcher, "packs", "store");
	}

	public void EnsureCreated()
	{
		string[] array = new string[9]
		{
			Root,
			Launcher,
			Minecraft,
			Runtime,
			Fabric,
			Payload,
			Mods,
			Graphics,
			Path.GetDirectoryName(Agent)
		};
		for (int i = 0; i < array.Length; i++)
		{
			try
			{
				Directory.CreateDirectory(array[i]);
			}
			catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
			{
			}
		}
		foreach (string folder in GameFolders)
		{
			try
			{
				Directory.CreateDirectory(Path.Combine(Minecraft, folder));
			}
			catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
			{
			}
		}
	}
}
