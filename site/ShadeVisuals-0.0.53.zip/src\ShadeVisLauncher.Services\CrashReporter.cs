using System;
using System.Windows;
namespace ShadeVisLauncher.Services;

/// <summary>Crash collection and upload are disabled in this distribution.</summary>
public static class CrashReporter
{
    public const string LauncherKind = "launcher";
    public const string GameKind = "game";
    public static void Install(Application application) { }
    public static void ReportGameExit(string minecraftDirectory, int exitCode,
        DateTime startedUtc, string? modVersion) { }
}
