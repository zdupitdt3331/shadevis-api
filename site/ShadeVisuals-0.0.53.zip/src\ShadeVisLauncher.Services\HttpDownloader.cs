using System;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;

namespace ShadeVisLauncher.Services;

/// <summary>Загрузка файлов и JSON с Modrinth/Minecraft CDN.</summary>
public sealed class HttpDownloader
{
	private const int BufferSize = 81920;

	private const string TempSuffix = ".part";

	private readonly HttpClient client = LauncherHttp.Create(TimeSpan.FromMinutes(10));

	public async Task<string> GetStringAsync(string url, CancellationToken cancel)
	{
		using HttpResponseMessage response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, cancel).ConfigureAwait(false);
		NetworkRetry.ThrowIfTransient(response);
		response.EnsureSuccessStatusCode();
		return await response.Content.ReadAsStringAsync(cancel).ConfigureAwait(false);
	}

	public async Task<byte[]> GetBytesAsync(string url, CancellationToken cancel)
	{
		using HttpResponseMessage response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, cancel).ConfigureAwait(false);
		NetworkRetry.ThrowIfTransient(response);
		response.EnsureSuccessStatusCode();
		return await response.Content.ReadAsByteArrayAsync(cancel).ConfigureAwait(false);
	}

	public Task DownloadAsync(string url, string destination, string? sha1, CancellationToken cancel)
	{
		return DownloadCoreAsync(url, destination, null, sha1, cancel);
	}

	public Task DownloadWithProgressAsync(string url, string destination, IProgress<double>? progress, CancellationToken cancel)
	{
		return DownloadCoreAsync(url, destination, progress, null, cancel);
	}

	private async Task DownloadCoreAsync(string url, string destination, IProgress<double>? progress, string? sha1, CancellationToken cancel)
	{
		string temp = destination + TempSuffix;
		string? folder = Path.GetDirectoryName(destination);
		if (!string.IsNullOrEmpty(folder))
		{
			Directory.CreateDirectory(folder);
		}
		try
		{
			using HttpResponseMessage response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, cancel).ConfigureAwait(false);
			NetworkRetry.ThrowIfTransient(response);
			response.EnsureSuccessStatusCode();
			long? total = response.Content.Headers.ContentLength;
			long written = 0L;
			byte[] buffer = new byte[BufferSize];
			using (IncrementalHash hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA1))
			{
				using (Stream input = await response.Content.ReadAsStreamAsync(cancel).ConfigureAwait(false))
				{
					using FileStream output = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None, BufferSize, useAsync: true);
					while (true)
					{
						int read = await input.ReadAsync(buffer.AsMemory(0, buffer.Length), cancel).ConfigureAwait(false);
						if (read <= 0)
						{
							break;
						}
						await output.WriteAsync(buffer.AsMemory(0, read), cancel).ConfigureAwait(false);
						hash.AppendData(buffer, 0, read);
						written += read;
						if (progress != null && total.HasValue && total.Value > 0L)
						{
							progress.Report((double)written / (double)total.Value);
						}
					}
				}
				if (!string.IsNullOrEmpty(sha1))
				{
					string actual = Convert.ToHexStringLower(hash.GetHashAndReset());
					if (!string.Equals(actual, sha1.Trim(), StringComparison.OrdinalIgnoreCase))
					{
						throw new IOException("checksum mismatch for " + Path.GetFileName(destination));
					}
				}
			}
			if (File.Exists(destination))
			{
				File.Delete(destination);
			}
			File.Move(temp, destination);
			progress?.Report(1.0);
		}
		finally
		{
			try
			{
				if (File.Exists(temp))
				{
					File.Delete(temp);
				}
			}
			catch (IOException)
			{
			}
			catch (UnauthorizedAccessException)
			{
			}
		}
	}
}
