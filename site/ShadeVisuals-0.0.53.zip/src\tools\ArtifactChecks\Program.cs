using System;
using System.IO;
using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Resources;
using System.Collections;
class Program {
 static void Main(string[] args) {
  var buffer = default(_003C_003Ey__InlineArray3<string>);
  _003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray3<string>,string>(ref buffer,0)="first";
  _003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray3<string>,string>(ref buffer,2)="last";
  var span = _003CPrivateImplementationDetails_003E.InlineArrayAsReadOnlySpan<_003C_003Ey__InlineArray3<string>,string>(in buffer,3);
  if(span.Length!=3 || span[0]!="first" || span[1]!=null || span[2]!="last") throw new Exception("Inline storage failed");
  using var stream=File.OpenRead(args[0]); using var pe=new PEReader(stream);
  var md=pe.GetMetadataReader(); bool found=false; int count=0;
  if(pe.PEHeaders.CorHeader.EntryPointTokenOrRelativeVirtualAddress==0) throw new Exception("Missing entry point");
  foreach(var handle in md.ManifestResources) {
   var resource=md.GetManifestResource(handle);
   if(md.GetString(resource.Name)!="ShadeVisLauncher.g.resources") continue;
   var data=pe.GetSectionData(pe.PEHeaders.CorHeader.ResourcesDirectory.RelativeVirtualAddress).GetContent();
   var bytes=data.AsSpan(); int offset=checked((int)resource.Offset); int length=BitConverter.ToInt32(bytes.Slice(offset,4));
   using var reader=new ResourceReader(new MemoryStream(bytes.Slice(offset+4,length).ToArray()));
   foreach(DictionaryEntry item in reader) {
    var name=(string)item.Key; var expected=File.ReadAllBytes(Path.Combine(args[1],name.Replace('/',Path.DirectorySeparatorChar)));
    using var output=new MemoryStream(); ((Stream)item.Value).CopyTo(output);
    if(!expected.AsSpan().SequenceEqual(output.ToArray())) throw new Exception("Resource mismatch: "+name);
    count++;
   }
   found=true;
  }
  if(!found || count<8) throw new Exception("Missing WPF resources, count="+count);
  foreach(var file in new[]{"Microsoft.Web.WebView2.Core.dll","Microsoft.Web.WebView2.Wpf.dll","SharpCompress.dll","WebView2Loader.dll"}) if(!File.Exists(Path.Combine(Path.GetDirectoryName(args[0]),file))) throw new Exception("Missing dependency: "+file);
  Console.WriteLine("PASS: entry point, 8 original WPF resources, native/managed dependencies, inline storage. Launcher not executed.");
 }
}
