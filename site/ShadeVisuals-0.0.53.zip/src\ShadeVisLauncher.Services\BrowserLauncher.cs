namespace ShadeVisLauncher.Services;
public static class BrowserLauncher
{
    public static bool TryOpen(string url) => false;
}
