using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;

namespace ShadeVisLauncher.Ui;

public sealed class CharacterViewer
{
	[CompilerGenerated]
	private WebView2 _003Cview_003EP;

	private const string VirtualHost = "evo.viewer";

	private const string PageUrl = "https://evo.viewer/index.html";

	private const string AssetsFolder = "assets";

	private const string ViewerFolder = "viewer";

	private const string ApplyScript = "evoSetCharacter({0})";

	private const string PreviewScript = "evoPreview({0},{1})";

	private const string NullLiteral = "null";

	private TaskCompletionSource<bool>? navigation;

	public bool Ready { get; private set; }

	public CharacterViewer(WebView2 view)
	{
		_003Cview_003EP = view;
		
	}

	public async Task<bool> InitialiseAsync()
	{
		string folder = Path.Combine(AppContext.BaseDirectory, "assets", "viewer");
		if (!Directory.Exists(folder))
		{
			return false;
		}
		try
		{
			CoreWebView2Environment environment = await WebViewHost.EnvironmentAsync();
			await _003Cview_003EP.EnsureCoreWebView2Async(environment);
			CoreWebView2 coreWebView = _003Cview_003EP.CoreWebView2;
			coreWebView.SetVirtualHostNameToFolderMapping("evo.viewer", folder, CoreWebView2HostResourceAccessKind.Allow);
			coreWebView.Settings.AreDefaultContextMenusEnabled = false;
			coreWebView.Settings.AreDevToolsEnabled = false;
			coreWebView.Settings.IsStatusBarEnabled = false;
			coreWebView.Settings.IsZoomControlEnabled = false;
			coreWebView.Settings.AreBrowserAcceleratorKeysEnabled = false;
			_003Cview_003EP.DefaultBackgroundColor = Color.Transparent;
			navigation = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
			coreWebView.NavigationCompleted += OnNavigationCompleted;
			coreWebView.Navigate("https://evo.viewer/index.html");
			Ready = await navigation.Task;
			return Ready;
		}
		catch (Exception ex) when (WebViewHost.IsMissingRuntime(ex) || ex is InvalidOperationException)
		{
			return false;
		}
	}

	public async Task ApplyAsync(string? skinUrl, bool slim, IReadOnlyDictionary<string, string> cosmetics)
	{
		if (Ready)
		{
			string arg = JsonSerializer.Serialize(new
			{
				skin = skinUrl,
				slim = slim,
				cosmetics = cosmetics
			});
			await RunAsync(string.Format("evoSetCharacter({0})", arg));
		}
	}

	public async Task PreviewAsync(string? slot, string? key)
	{
		if (Ready)
		{
			await RunAsync(string.Format("evoPreview({0},{1})", Literal(slot), Literal(key)));
		}
	}

	private async Task RunAsync(string script)
	{
		try
		{
			await _003Cview_003EP.CoreWebView2.ExecuteScriptAsync(script);
		}
		catch (InvalidOperationException)
		{
			Ready = false;
		}
	}

	private static string Literal(string? value)
	{
		if (value != null)
		{
			return JsonSerializer.Serialize(value);
		}
		return "null";
	}

	private void OnNavigationCompleted(object? sender, CoreWebView2NavigationCompletedEventArgs e)
	{
		_003Cview_003EP.CoreWebView2.NavigationCompleted -= OnNavigationCompleted;
		navigation?.TrySetResult(e.IsSuccess);
	}
}
