using System.Collections.Generic;
using System.ComponentModel;

namespace ShadeVisLauncher.Instance;

public static class RuntimeBlock
{
	private const int ErrorVirusInfected = 225;

	private const int ErrorAccessDisabledByPolicy = 1260;

	private const int ErrorSystemIntegrityPolicy = 4551;

	private const uint StatusCodeIntegrityBlocked = 3236495362u;

	private const uint StatusInvalidImageHash = 3221226536u;

	private const uint StatusInvalidImageFormat = 3221225595u;

	private const uint StatusDllNotFound = 3221225781u;

	private static readonly HashSet<int> BlockedStartErrors = new HashSet<int> { 225, 1260, 4551 };

	private static readonly HashSet<int> LoaderFailureExitCodes = new HashSet<int> { -1058471934, -1073740760, -1073741701, -1073741515 };

	public static bool IsBlockedStart(Win32Exception failure)
	{
		return BlockedStartErrors.Contains(failure.NativeErrorCode);
	}

	public static bool IsLoaderFailure(int exitCode)
	{
		return LoaderFailureExitCodes.Contains(exitCode);
	}
}
