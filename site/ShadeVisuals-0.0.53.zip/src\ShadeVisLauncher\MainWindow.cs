using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using ShadeVisLauncher.Auth;
using ShadeVisLauncher.Instance;
using ShadeVisLauncher.Services;
using ShadeVisLauncher.Ui;
using Microsoft.Web.WebView2.Wpf;
using Microsoft.Win32;

namespace ShadeVisLauncher;

public class MainWindow : Window, IComponentConnector, IStyleConnector
{
	private sealed record RendererDecision(GlSupport Support, bool Software)
	{
		[CompilerGenerated]
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("RendererDecision");
			stringBuilder.Append(" { ");
			if (PrintMembers(stringBuilder))
			{
				stringBuilder.Append(' ');
			}
			stringBuilder.Append('}');
			return stringBuilder.ToString();
		}

		[CompilerGenerated]
		private bool PrintMembers(StringBuilder builder)
		{
			RuntimeHelpers.EnsureSufficientExecutionStack();
			builder.Append("Support = ");
			builder.Append(Support);
			builder.Append(", Software = ");
			builder.Append(Software.ToString());
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class _003CPages_003Ed__203 : IEnumerable<FrameworkElement>, IEnumerable, IEnumerator<FrameworkElement>, IEnumerator, IDisposable
	{
		private int _003C_003E1__state;

		private FrameworkElement _003C_003E2__current;

		private int _003C_003El__initialThreadId;

		public MainWindow _003C_003E4__this;

		FrameworkElement IEnumerator<FrameworkElement>.Current
		{
			[DebuggerHidden]
			get
			{
				return _003C_003E2__current;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _003C_003E2__current;
			}
		}

		[DebuggerHidden]
		public _003CPages_003Ed__203(int _003C_003E1__state)
		{
			this._003C_003E1__state = _003C_003E1__state;
			_003C_003El__initialThreadId = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		void IDisposable.Dispose()
		{
			_003C_003E1__state = -2;
		}

		private bool MoveNext()
		{
			int num = _003C_003E1__state;
			MainWindow mainWindow = _003C_003E4__this;
			switch (num)
			{
			default:
				return false;
			case 0:
				_003C_003E1__state = -1;
				_003C_003E2__current = mainWindow.HomePage;
				_003C_003E1__state = 1;
				return true;
			case 1:
				_003C_003E1__state = -1;
				_003C_003E2__current = mainWindow.CosmeticsPage;
				_003C_003E1__state = 2;
				return true;
			case 2:
				_003C_003E1__state = -1;
				_003C_003E2__current = mainWindow.SkinsPage;
				_003C_003E1__state = 3;
				return true;
			case 3:
				_003C_003E1__state = -1;
				_003C_003E2__current = mainWindow.ModsPage;
				_003C_003E1__state = 4;
				return true;
			case 4:
				_003C_003E1__state = -1;
				_003C_003E2__current = mainWindow.PacksPage;
				_003C_003E1__state = 5;
				return true;
			case 5:
				_003C_003E1__state = -1;
				_003C_003E2__current = mainWindow.SettingsPage;
				_003C_003E1__state = 6;
				return true;
			case 6:
				_003C_003E1__state = -1;
				return false;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		[DebuggerHidden]
		void IEnumerator.Reset()
		{
			throw new NotSupportedException();
		}

		[DebuggerHidden]
		IEnumerator<FrameworkElement> IEnumerable<FrameworkElement>.GetEnumerator()
		{
			_003CPages_003Ed__203 result;
			if (_003C_003E1__state == -2 && _003C_003El__initialThreadId == Environment.CurrentManagedThreadId)
			{
				_003C_003E1__state = 0;
				result = this;
			}
			else
			{
				result = new _003CPages_003Ed__203(0)
				{
					_003C_003E4__this = _003C_003E4__this
				};
			}
			return result;
		}

		[DebuggerHidden]
		IEnumerator IEnumerable.GetEnumerator()
		{
			return ((IEnumerable<FrameworkElement>)this).GetEnumerator();
		}
	}

	private const string StageInstance = "instance";

	private const string StageJava = "java";

	private const string StageGraphics = "graphics";

	private const string StageMods = "mods";

	private const string StagePack = "pack";

	private const string StageLauncher = "launcher";

	private const string StageStart = "start";

	private const string StageAccount = "account";

	private const string MinecraftOfflineFormat = "Not linked — you play offline as {0}. Servers with premium login (e.g. AstrumMC) reject licensed nicknames without a Microsoft sign-in.";

	private const string MinecraftLinkedFormat = "Signed in as {0} — servers see your licensed Minecraft account.";

	private const string MinecraftSigningInText = "Waiting for Microsoft sign-in...";

	private const string MinecraftLinkText = "Sign in with Microsoft";

	private const string MinecraftUnlinkText = "Sign out of Microsoft";

	private const string MinecraftSignInFailedFormat = "Microsoft sign-in failed: {0}";

	private const string MinecraftSaveFailedText = "Signed in, but the Microsoft session could not be saved on this PC.";

	private static readonly TimeSpan MinecraftTokenReserve = TimeSpan.FromHours(1);

	private const string GameClosedText = "Minecraft closed.";

	private const string GameCrashedFormat = "Minecraft closed unexpectedly (exit code {0}). No crash report is sent.";

	private const string DefaultPlayerName = "Player";

	private const string CustomRuntimeMissingText = "The ShadeVis runtime could not be installed. Check your internet connection, VPN or bypass list and press Play again.";

	private const string GameRunningText = "Minecraft is already running — close it before launching again.";

	private const string RuntimeBlockedTitle = "Java was blocked";

	private const string GameReleasedFormat = "Closed {0} stuck Minecraft process(es) from the last session.";

	private const string UnknownRuntime = "unknown";

	private const string ClockFormat = "HH:mm:ss";

	private const string GreetingFormat = "Welcome back, {0}!";

	private const string MemoryFormat = "{0} GB";

	private const string AutomaticMemoryFormat = "{0} GB · automatic";

	private const string VersionFormat = "v{0}";

	private const string ModsSubtitleFormat = "Modrinth · Fabric · Minecraft {0}";

	private const string SearchResultFormat = "{0} mods available for Minecraft {1}";

	private const string InstalledCountFormat = "{0} mods in the instance";

	private const string SidebarModsFormat = "{0} mods installed";

	private const string InstanceModsNoteFormat = "{0} installed · auto-updated on every launch";

	private const string SidebarBuildFormat = "ShadeVis {0}";

	private const string ShadersReadyText = "Iris + Sodium";

	private const string ShadersMissingText = "on first launch";

	private const string RuntimeMissingText = "on first launch";

	private const string RuntimeDetailMarker = "(N/A)";

	private const string SessionActiveText = "Session active";

	private const string SessionExpiredText = "Session expired";

	private const string SessionOfflineText = "Session saved, server unreachable";

	private const string MirrorActiveText = "Direct connection is blocked, downloading through the ShadeVis mirror.";

	private const string InstallFailureFormat = "Could not install {0}: {1}";

	private const string InstallSingleFormat = "Installed {0}.";

	private const string InstallWithDependenciesFormat = "Installed {0} and {1} required dependencies.";

	private const string RemovedFormat = "Removed {0}.";

	private const string SearchingText = "Searching Modrinth...";

	private const string ReadingModsText = "Reading the mods folder...";

	private const string UnreachableFormat = "Modrinth is unreachable: {0}";

	private const string NoResultsText = "No mods match this search.";

	private const string NoInstalledText = "No mods installed yet — install some from Browse.";

	private const string UpToDateText = "The launcher is up to date.";

	private const string UpdateFailedFormat = "Update check failed: {0}";

	private const string SignedOutText = "Signed out.";

	private const string PackSummaryFormat = "{0} of {1} library mods · applied on launch";

	private const string PackEmptySummary = "No mods selected · applied on launch";

	private const string PackCreatedFormat = "Created {0}.";

	private const string PackDeletedFormat = "Deleted {0}.";

	private const string PackRenamedFormat = "Renamed to {0}.";

	private const string PackActivatedFormat = "{0} is live.";

	private const string PackLastText = "The last pack cannot be deleted.";

	private const string PackIncludedFormat = "{0} added to {1}.";

	private const string PackExcludedFormat = "{0} removed from {1}.";

	private const string ApplyingPackFormat = "Applying pack {0}...";

	private const string PackMissingFormat = "{0} pack mods could not be restored and were skipped.";

	private const string PackLockedFormat = "{0} pack mods are in use and were left where they are.";

	private const string PackConflictFormat = "{0} was turned off for this launch: it crashes the game together with {1}.";

	private const string PackLinkedFormat = "Added {0} missing dependencies to the pack.";

	private const string PackCopySuffix = " copy";

	private const string PackExportTitle = "Export pack";

	private const string PackImportTitle = "Import pack";

	private const string PackExportedFormat = "Exported {0} mods to {1}.";

	private const string PackExportSkippedFormat = " {0} mods without a Modrinth source were left out.";

	private const string PackExportEmptyText = "Nothing to export — this pack has no mods installed from Modrinth.";

	private const string PackExportFailedText = "Could not write the .evopack file.";

	private const string PackImportBadText = "That file is not a valid .evopack export.";

	private const string PackImportedFormat = "{0} imported with {1} mods.";

	private const string PackImportMissingFormat = " {0} mods could not be downloaded.";

	private const string PackImportFailedFormat = "Import failed: {0}";

	private const string NewPackFallbackFormat = "Pack {0}";

	private const string SidebarPackFormat = "Pack: {0}";

	private const string CosmeticsCountFormat = "{0} models · {1} equipped";

	private const string EquippedFormat = "{0} equipped";

	private const string ClearedFormat = "{0} cleared";

	private const string WornCountFormat = "{0} equipped";

	private const string CosmeticFailureFormat = "Could not save: {0}";

	private const string CosmeticsLoadingText = "Loading your character...";

	private const string CosmeticLockedFormat = "{0} is locked — unlock it on evoproject.xyz (opened in your browser).";

	private const string CosmeticShopUrl = "https://www.evoproject.xyz/account#cosmetics";

	private const string NotOwnedError = "not_owned";

	private const string SkinsLoadingText = "Loading skins from NameMC...";

	private const string SkinsCountFormat = "{0} skins · in game: {1}";

	private const string SkinsLibraryFormat = "{0} of {1} slots used in your library";

	private const string SkinsBrowserMissingText = "Browsing NameMC needs the Microsoft Edge WebView2 runtime. Install it and reopen this tab.";

	private const string SkinsEmptyText = "NameMC returned nothing for this selection. Try another category.";

	private const string SkinAppliedFormat = "{0} applied — the client picks it up on the next cosmetics sync.";

	private const string SkinRemovedFormat = "{0} removed from your library.";

	private const string SkinFailureFormat = "Could not apply the skin: {0}";

	private const string SkinLibraryFullText = "Your skin library is full (12). Remove one under MY SKINS first.";

	private const string DataUrlPrefix = "data:image/png;base64,";

	private const string NoneKey = "no skin";

	private const string CustomSkinText = "custom skin";

	private const string SkinsLibraryEmptyText = "Your library is empty — apply a skin from NameMC to fill it.";

	private const int SkinLibraryLimit = 12;

	private const string AssetsFolder = "assets";

	private const string VideoFileName = "background.mp4";

	private const string ExplorerExecutable = "explorer.exe";

	private const string ManualSignInCopiedFormat = "Could not open a browser. The sign-in link is copied — paste it into any browser: {0}";

	private const string EmbeddedSignInText = "Your browser could not be opened — sign in right here.";

	private const string ChooseInstallFolderTitle = "Choose where to install the ShadeVis client";

	private const string MoveWhileBusyText = "Wait for the current launch or pack import to finish first.";

	private const string MoveWhileRunningText = "Close Minecraft before moving the client.";

	private const string MoveRestartingText = "Moved. Restarting the launcher...";

	private const string MoveFailedFormat = "Could not move the client: {0}";

	private const string SignInCancelledText = "Sign-in cancelled.";

	private const string LauncherDataFolder = "ShadeVis";

	private const string LegacyTunnelFolder = "warp";

	private const string CredentialsMissingText = "Enter your login and password.";

	private const string DeviceUnknownText = "Could not identify this device.";

	private const string SigningInText = "Signing in...";

	private const string SignInUnreachableFormat = "Could not reach the ShadeVis server: {0}";

	private const string ManualSignInFormat = "Could not open a browser. Open this link in any browser: {0}";

	private const int PageSize = 20;

	private const int ModelConcurrency = 4;

	private static readonly TimeSpan SpinResumeDelay = TimeSpan.FromMilliseconds(500L, 0L);

	private const double HeroCornerRadius = 18.0;

	private const int RoundedCornerAttribute = 33;

	private const int RoundedCornerPreference = 2;

	private static readonly TimeSpan ClockInterval = TimeSpan.FromSeconds(1L);

	private static readonly TimeSpan SearchDelay = TimeSpan.FromMilliseconds(350L, 0L);

	private static readonly TimeSpan SettingsDelay = TimeSpan.FromMilliseconds(400L, 0L);

	private static readonly Duration PageReveal = new Duration(TimeSpan.FromMilliseconds(280L, 0L));

	private const double PageSlide = 18.0;

	private readonly ShadeVisAuth _evoAuth = new ShadeVisAuth();

	private SignInBrowser? _signInBrowser;

	private CancellationTokenSource? _signInCancel = null;

	private readonly InstancePaths _paths = new InstancePaths();

	private readonly HttpDownloader _downloader = new HttpDownloader();

	private readonly ModrinthClient _modrinth;

	private readonly ModCatalog _catalog;

	private readonly ObservableCollection<ModListItem> _browse = new ObservableCollection<ModListItem>();

	private readonly ObservableCollection<ModListItem> _installed = new ObservableCollection<ModListItem>();

	private readonly ObservableCollection<ModListItem> _managed = new ObservableCollection<ModListItem>();

	private readonly ObservableCollection<CosmeticItem> _cosmetics = new ObservableCollection<CosmeticItem>();

	private readonly ObservableCollection<CosmeticTab> _cosmeticTabs = new ObservableCollection<CosmeticTab>();

	private readonly ObservableCollection<EquippedSlot> _equippedSlots = new ObservableCollection<EquippedSlot>();

	private readonly ObservableCollection<SkinItem> _skins = new ObservableCollection<SkinItem>();

	private readonly ObservableCollection<PackItem> _packItems = new ObservableCollection<PackItem>();

	private readonly ObservableCollection<PackModItem> _packMods = new ObservableCollection<PackModItem>();

	private readonly PackLibrary _packs;

	private readonly CharacterClient _character = new CharacterClient();

	private readonly IProgress<string> _loginStatus;

	private readonly IProgress<string> _moveStatus;

	private readonly IProgress<double> _movePercent;

	private readonly IProgress<string> _homeStatus;

	private readonly IProgress<string> _modsStatus;

	private readonly IProgress<string> _updateStatus;

	private readonly IProgress<string> _packsStatus;

	private readonly IProgress<double> _percent;

	private readonly DispatcherTimer _clock = new DispatcherTimer
	{
		Interval = ClockInterval
	};

	private readonly DispatcherTimer _searchDebounce = new DispatcherTimer
	{
		Interval = SearchDelay
	};

	private readonly DispatcherTimer _settingsDebounce = new DispatcherTimer
	{
		Interval = SettingsDelay
	};

	private ShadeVisUser? _evoUser;

	private MicrosoftAccount? _microsoft;

	private bool _microsoftBusy;

	private CancellationTokenSource? _searchCancel;

	private string _sort = "downloads";

	private int _browseTotal;

	private bool _ready;

	private bool _applyingSettings;

	private bool _videoReady;

	private bool _browseLoaded;

	private CharacterViewer? _viewer;

	private CosmeticThumbnails? _thumbnails;

	private CancellationTokenSource? _thumbnailsCancel;

	private HiddenBrowser? _browser;

	private NameMcClient? _nameMc;

	private CharacterProfile? _profile;

	private IReadOnlySet<string>? _owned;

	private string _cosmeticSlot = "cape";

	private string _skinSource = "trending/daily";

	private int _skinPage = 1;

	private bool _cosmeticsLoaded;

	private bool _skinsLoaded;

	private CancellationTokenSource? _skinsCancel;

	private IReadOnlyList<InstalledMod> _library = Array.Empty<InstalledMod>();

	private string? _selectedPackId;

	private bool _renamingPack;

	private bool _importingPack;

	private bool _launching;

	private bool _launchBusy;

	private Process? _game;

	internal TextBlock Greeting;

	internal TextBlock Clock;

	internal Grid LoginRoot;

	internal TextBlock HwidText;

	internal TextBox LoginField;

	internal PasswordBox PasswordField;

	internal Button PasswordSignInButton;

	internal Button EvoButton;

	internal TextBlock LoginStatus;

	internal Border SignInPanel;

	internal TextBlock SignInPanelStatus;

	internal WebView2 SignInView;

	internal Grid ShellRoot;

	internal RadioButton NavHome;

	internal RadioButton NavCosmetics;

	internal RadioButton NavSkins;

	internal RadioButton NavMods;

	internal RadioButton NavPacks;

	internal RadioButton NavSettings;

	internal Button SidePlayButton;

	internal Ellipse SessionDot;

	internal TextBlock SessionState;

	internal TextBlock SidebarBuild;

	internal TextBlock SidebarMods;

	internal TextBlock SidebarPack;

	internal TextBlock AvatarInitial;

	internal Ellipse AvatarEllipse;

	internal ImageBrush AvatarBrush;

	internal TextBlock UserName;

	internal TextBlock UserRole;

	internal Grid HomePage;

	internal Grid HeroClip;

	internal MediaElement BgVideo;

	internal Button LaunchButton;

	internal TextBlock McVersion;

	internal TextBlock ModVersion;

	internal TextBlock HomeStatus;

	internal ProgressBar LaunchProgress;

	internal TextBlock PlayerName;

	internal TextBlock HeroPack;

	internal TextBlock StatMods;

	internal TextBlock StatMemory;

	internal TextBlock StatJava;

	internal TextBlock StatShaders;

	internal TextBlock InstanceModsNote;

	internal ItemsControl ManagedList;

	internal TextBlock ManagedEmpty;

	internal Button ModsButton;

	internal TextBlock AccountName;

	internal TextBlock AccountRole;

	internal TextBlock AccountDevice;

	internal Grid CosmeticsPage;

	internal TextBlock CharacterName;

	internal TextBlock CharacterWornCount;

	internal WebView2 CharacterView;

	internal TextBlock ViewerFallback;

	internal ItemsControl EquippedList;

	internal TextBlock EquippedEmpty;

	internal Button ResetCosmeticsButton;

	internal TextBlock CosmeticsStatus;

	internal TextBlock CosmeticsSearchHint;

	internal TextBox CosmeticsSearch;

	internal ItemsControl CosmeticTabs;

	internal ItemsControl CosmeticsList;

	internal TextBlock CosmeticsEmpty;

	internal Grid SkinsPage;

	internal TextBlock SkinSearchHint;

	internal TextBox SkinSearch;

	internal RadioButton SkinsTrending;

	internal RadioButton SkinsWeekly;

	internal RadioButton SkinsNew;

	internal RadioButton SkinsRandom;

	internal RadioButton SkinsLibrary;

	internal TextBlock SkinsStatus;

	internal ItemsControl SkinsList;

	internal TextBlock SkinsEmpty;

	internal Button SkinsMoreButton;

	internal Grid ModsPage;

	internal TextBlock ModsSubtitle;

	internal TextBlock SearchPlaceholder;

	internal TextBox SearchBox;

	internal RadioButton TabBrowse;

	internal RadioButton TabInstalled;

	internal StackPanel SortRow;

	internal RadioButton SortPopular;

	internal RadioButton SortRelevant;

	internal RadioButton SortUpdated;

	internal TextBlock ModsStatus;

	internal ScrollViewer ModsScroll;

	internal ItemsControl ModsList;

	internal TextBlock ModsEmpty;

	internal Button LoadMoreButton;

	internal Grid PacksPage;

	internal TextBlock PacksSubtitle;

	internal TextBlock PacksStatus;

	internal ItemsControl PacksList;

	internal TextBlock NewPackHint;

	internal TextBox NewPackName;

	internal Button CreatePackButton;

	internal Button ImportPackButton;

	internal TextBox PackNameBox;

	internal TextBlock PackSummary;

	internal Button PlayPackButton;

	internal Button ExportPackButton;

	internal Button DuplicatePackButton;

	internal Button DeletePackButton;

	internal ItemsControl PackModsList;

	internal TextBlock PackModsEmpty;

	internal Grid SettingsPage;

	internal TextBlock MemoryValue;

	internal Slider MemorySlider;

	internal TextBlock InstanceFolder;

	internal Button MoveInstanceButton;

	internal Button DefaultInstanceButton;

	internal ProgressBar MoveInstanceProgress;

	internal TextBlock MoveInstanceStatus;

	internal TextBlock LauncherVersion;

	internal TextBlock UpdateStatus;

	internal Button UpdateButton;

	internal TextBlock MinecraftAccountStatus;

	internal Button MinecraftAccountButton;

	internal TextBlock SettingsDevice;

	private bool _contentLoaded;

	public MainWindow()
	{
		InitializeComponent();
		Title = "ShadeVis";
		_modrinth = new ModrinthClient(_downloader);
		_catalog = new ModCatalog(_paths, _modrinth, _downloader);
		_packs = new PackLibrary(_paths);
		_loginStatus = new Progress<string>(delegate(string message)
		{
			LoginStatus.Text = message;
		});
		_moveStatus = new Progress<string>(delegate(string message)
		{
			MoveInstanceStatus.Text = message;
		});
		_movePercent = new Progress<double>(delegate(double value)
		{
			MoveInstanceProgress.Value = value;
		});
		_homeStatus = new Progress<string>(delegate(string message)
		{
			HomeStatus.Text = message;
		});
		_modsStatus = new Progress<string>(delegate(string message)
		{
			ModsStatus.Text = message;
		});
		_updateStatus = new Progress<string>(delegate(string message)
		{
			UpdateStatus.Text = message;
		});
		_packsStatus = new Progress<string>(delegate(string message)
		{
			PacksStatus.Text = message;
		});
		_percent = new Progress<double>(delegate(double value)
		{
			LaunchProgress.Value = value;
		});
		_clock.Tick += delegate
		{
			_paths.EnsureCreated();
		ShadeModSync.Ensure(_paths);
		NativesProvisioner.Ensure(_paths);
		ApplyHeroBackground();
		AvatarInitial.MouseLeftButtonUp += OnAvatarClick;
		AvatarEllipse.MouseLeftButtonUp += OnAvatarClick;
		UserName.MouseLeftButtonUp += OnAvatarClick;
		AccountName.MouseLeftButtonUp += OnAvatarClick;
		Clock.Text = DateTime.Now.ToString("HH:mm:ss", CultureInfo.CurrentCulture);
		};
		_searchDebounce.Tick += OnSearchDebounced;
		_settingsDebounce.Tick += OnSettingsDebounced;
		ModsList.ItemsSource = _browse;
		ManagedList.ItemsSource = _managed;
		CosmeticsList.ItemsSource = _cosmetics;
		CosmeticTabs.ItemsSource = _cosmeticTabs;
		EquippedList.ItemsSource = _equippedSlots;
		SkinsList.ItemsSource = _skins;
		PacksList.ItemsSource = _packItems;
		PackModsList.ItemsSource = _packMods;
		foreach (FrameworkElement item in Pages())
		{
			item.RenderTransform = new TranslateTransform();
		}
		ModsSubtitle.Text = string.Format("Modrinth · Fabric · Minecraft {0}", "1.21.11");
		base.Loaded += OnLoaded;
		base.Closed += OnClosed;
		DeliveryMirror.StateChanged += OnMirrorStateChanged;
		_ready = true;
	}

	protected override void OnSourceInitialized(EventArgs e)
	{
		base.OnSourceInitialized(e);
		FitToWorkArea();
		try
		{
			int value = 2;
			DwmSetWindowAttribute(new WindowInteropHelper(this).Handle, 33, ref value, 4);
		}
		catch (DllNotFoundException)
		{
		}
		catch (EntryPointNotFoundException)
		{
		}
	}

	private void FitToWorkArea()
	{
		Rect workArea = SystemParameters.WorkArea;
		base.Width = Math.Min(base.Width, workArea.Width);
		base.Height = Math.Min(base.Height, workArea.Height);
		base.Left = workArea.Left + (workArea.Width - base.Width) / 2.0;
		base.Top = workArea.Top + (workArea.Height - base.Height) / 2.0;
	}

	private void OnLoaded(object sender, RoutedEventArgs e)
	{
		LauncherUpdater.CleanupRetired();
		ApplyAccountLabels(LoginRoot);
        _loginStatus.Report("Sign in or create an account.");
		Clock.Text = DateTime.Now.ToString("HH:mm:ss", CultureInfo.CurrentCulture);
		_clock.Start();
        NavCosmetics.Visibility = Visibility.Collapsed;
        NavSkins.Visibility = Visibility.Collapsed;
        EvoButton.Content = "Sign in";
        PasswordSignInButton.Content = "Create account";
        string text = HwidGuard.Display;
		HwidText.Text = text;
		AccountDevice.Text = text;
		SettingsDevice.Text = text;
		InstanceFolder.Text = "user";
		DefaultInstanceButton.IsEnabled = LauncherSettings.Current.InstallRoot != null;
		LauncherVersion.Text = string.Format("v{0}", LauncherUpdater.Current);
		ApplyMemorySetting();
		_microsoft = MicrosoftAccountStorage.Load();
		ApplyMinecraftAccount(null);
		string? lastNick = AccountStore.LastNick;
		if (!string.IsNullOrEmpty(lastNick))
		{
			LoginField.Text = lastNick;
			PasswordField.Focus();
		}
		else
		{
			LoginField.Focus();
		}

	}

	private async void OnClosed(object? sender, EventArgs e)
	{
		if (_browser != null)
		{
			await _browser.DisposeAsync();
		}
		_thumbnailsCancel?.Cancel();
		if (_thumbnails != null)
		{
			await _thumbnails.DisposeAsync();
		}
		_clock.Stop();
		_searchDebounce.Stop();
		_settingsDebounce.Stop();
		_searchCancel?.Cancel();
		DeliveryMirror.StateChanged -= OnMirrorStateChanged;
	}

    private static void ApplyAccountLabels(DependencyObject root)
    {
        if (root is TextBlock label)
        {
            if (label.Text == "Login or email") label.Text = "Nickname";
            else if (label.Text == "Sign in to your ShadeVis account to continue.")
                label.Text = "Sign in or create a local account to continue.";
        }
        for (int index = 0; index < VisualTreeHelper.GetChildrenCount(root); index++)
            ApplyAccountLabels(VisualTreeHelper.GetChild(root, index));
    }

	private void OnMirrorStateChanged(bool active)
	{
		if (active)
		{
			base.Dispatcher.BeginInvoke((Action)delegate
			{
				_homeStatus.Report("Direct connection is blocked, downloading through the ShadeVis mirror.");
			});
		}
	}

	private void OnMinimize(object sender, RoutedEventArgs e)
	{
		base.WindowState = WindowState.Minimized;
	}

	private void OnClose(object sender, RoutedEventArgs e)
	{
		Close();
	}

	private void OnHeroResized(object sender, SizeChangedEventArgs e)
	{
		HeroClip.Clip = new RectangleGeometry(new Rect(0.0, 0.0, e.NewSize.Width, e.NewSize.Height), 18.0, 18.0);
	}

	[IteratorStateMachine(typeof(_003CPages_003Ed__203))]
	private IEnumerable<FrameworkElement> Pages()
	{
		//yield-return decompiler failed: Unexpected instruction in Iterator.Dispose()
		return new _003CPages_003Ed__203(-2)
		{
			_003C_003E4__this = this
		};
	}

	private static void Reveal(FrameworkElement page)
	{
		if (page.RenderTransform is TranslateTransform translateTransform)
		{
			page.BeginAnimation(UIElement.OpacityProperty, null);
			translateTransform.BeginAnimation(TranslateTransform.YProperty, null);
			CubicEase easingFunction = new CubicEase
			{
				EasingMode = EasingMode.EaseOut
			};
			page.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0.0, 1.0, PageReveal));
			translateTransform.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(18.0, 0.0, PageReveal)
			{
				EasingFunction = easingFunction
			});
		}
	}

	private async void OnNavigate(object sender, RoutedEventArgs e)
	{
		if (!_ready)
		{
			return;
		}
		bool valueOrDefault = NavHome.IsChecked.GetValueOrDefault();
		bool valueOrDefault2 = NavMods.IsChecked.GetValueOrDefault();
		bool valueOrDefault3 = NavCosmetics.IsChecked.GetValueOrDefault();
		bool valueOrDefault4 = NavSkins.IsChecked.GetValueOrDefault();
		bool valueOrDefault5 = NavPacks.IsChecked.GetValueOrDefault();
		HomePage.Visibility = ((!valueOrDefault) ? Visibility.Collapsed : Visibility.Visible);
		ModsPage.Visibility = ((!valueOrDefault2) ? Visibility.Collapsed : Visibility.Visible);
		CosmeticsPage.Visibility = ((!valueOrDefault3) ? Visibility.Collapsed : Visibility.Visible);
		SkinsPage.Visibility = ((!valueOrDefault4) ? Visibility.Collapsed : Visibility.Visible);
		PacksPage.Visibility = ((!valueOrDefault5) ? Visibility.Collapsed : Visibility.Visible);
		SettingsPage.Visibility = ((!NavSettings.IsChecked.GetValueOrDefault()) ? Visibility.Collapsed : Visibility.Visible);
		foreach (FrameworkElement item in Pages())
		{
			if (item.Visibility == Visibility.Visible)
			{
				Reveal(item);
			}
		}
		if (_videoReady)
		{
			if (valueOrDefault)
			{
				BgVideo.Play();
			}
			else
			{
				BgVideo.Pause();
			}
		}
		PlayerModel.Suspend();
		if (valueOrDefault4)
		{
			_ = ResumeSpinAsync();
		}
		if (valueOrDefault)
		{
			await RefreshInstalledAsync(showOnModsPage: false);
		}
		else if (valueOrDefault2 && !_browseLoaded)
		{
			_browseLoaded = true;
			UpdateModsView();
            _modsStatus.Report("Search Modrinth and install mods right from the launcher.");
		}
		else if (valueOrDefault3)
		{
			await OpenCosmeticsAsync();
		}
		else if (valueOrDefault5)
		{
			await OpenPacksAsync();
		}
		else if (valueOrDefault4)
		{
			await OpenSkinsAsync();
		}
	}

	private Task RefreshSessionAsync(string token)
    {
        SessionState.Text = "Signed in";
        return Task.CompletedTask;
    }

	private void OnCredentialsKeyDown(object sender, KeyEventArgs e)
	{
		if (e.Key == Key.Return)
		{
			e.Handled = true;
			if (sender == LoginField && false)
			{
				PasswordField.Focus();
			}
			else
			{
				OnPasswordSignIn(sender, e);
			}
		}
	}

	private async void OnPasswordSignIn(object sender, RoutedEventArgs e)
	{
		await SignInAsync(register: false);
	}

	private async void OnRegister(object sender, RoutedEventArgs e)
	{
		await SignInAsync(register: true);
	}

	private async Task SignInAsync(bool register)
	{
		if (_launchBusy)
		{
			return;
		}
		string nick = (LoginField.Text ?? string.Empty).Trim();
		string password = PasswordField.Password ?? string.Empty;
		if (!AccountStore.Validate(nick, password, out string validationError))
		{
			_loginStatus.Report(validationError);
			return;
		}
		SetLoginBusy(true);
		try
		{
			ShadeVisUser? user;
			string error;
			bool ok = register ? AccountStore.Register(nick, password, out user, out error) : AccountStore.Login(nick, password, out user, out error);
			if (!ok || user == null)
			{
				_loginStatus.Report(error);
				return;
			}
			_evoUser = user;
			SessionRole.Current = user.Role ?? RoleCatalog.User;
			PasswordField.Clear();
			LoginField.Clear();
			await ShowHomeAsync(user);
		}
		finally
		{
			SetLoginBusy(false);
		}
	}
	private void SetLoginBusy(bool busy)
	{
		PasswordSignInButton.IsEnabled = !busy;
		EvoButton.IsEnabled = !busy;
		LoginField.IsEnabled = !busy;
		PasswordField.IsEnabled = !busy;
	}

	private void OnEvoSignIn(object sender, RoutedEventArgs e)
	{
		OnPasswordSignIn(sender, e);
	}

	private async Task<IProgress<string>> EmbeddedSignInStatusAsync(string hwid)
	{
		if (_signInBrowser == null)
		{
			_signInBrowser = new SignInBrowser(SignInView);
		}
		SignInPanel.Visibility = Visibility.Visible;
		if (await _signInBrowser.OpenAsync(_evoAuth.SignInUrl(hwid)))
		{
			SignInPanelStatus.Text = "Your browser could not be opened — sign in right here.";
			return new Progress<string>(delegate
			{
			});
		}
		SignInPanel.Visibility = Visibility.Collapsed;
		return ManualSignInStatus(hwid);
	}

	private void HideEmbeddedSignIn()
	{
		if (SignInPanel.Visibility == Visibility.Visible)
		{
			SignInPanel.Visibility = Visibility.Collapsed;
			_signInBrowser?.Close();
		}
	}

	private void OnSignInCancel(object sender, RoutedEventArgs e)
	{
		_signInCancel?.Cancel();
	}

	private IProgress<string> ManualSignInStatus(string hwid)
	{
		string text = _evoAuth.SignInUrl(hwid);
		bool flag = TryCopyToClipboard(text);
		string hint = string.Format(flag ? "Could not open a browser. The sign-in link is copied — paste it into any browser: {0}" : "Could not open a browser. Open this link in any browser: {0}", text);
		return new Progress<string>(delegate(string message)
		{
			LoginStatus.Text = hint + "\n" + message;
		});
	}

	private static bool TryCopyToClipboard(string text)
	{
		try
		{
			Clipboard.SetText(text);
			return true;
		}
		catch (ExternalException)
		{
			return false;
		}
	}

	private void OnSignOut(object sender, RoutedEventArgs e)
	{
		SignOut("Signed out.");
	}

	private void SignOut(string message)
	{
		LoginField.Clear();
		_evoUser = null;
		if (_videoReady)
		{
			BgVideo.Stop();
		}
		ShowLogin(message);
	}

	private void ShowLogin(string message)
	{
		ShellRoot.Visibility = Visibility.Collapsed;
		LoginRoot.Visibility = Visibility.Visible;
		Greeting.Text = string.Empty;
		SetLoginBusy(busy: false);
		PasswordField.Clear();
		_loginStatus.Report(message);
	}

	private void ApplyIdentity(ShadeVisUser user)
    {
        string name = string.IsNullOrWhiteSpace(user.Username) ? "player" : user.Username!;
        string role = string.IsNullOrWhiteSpace(user.Role) ? "USER" : user.Role!.ToUpperInvariant();
        UserName.Text = name;
        UserRole.Text = role;
        AccountName.Text = name;
        AccountRole.Text = role;
        Greeting.Text = "Welcome back, " + name + "!";
        AvatarInitial.Text = name.Substring(0, 1).ToUpperInvariant();
        ApplyAvatar(name);
        ApplyMinecraftAccount(null);
    }

	private void ApplyAvatar(string? name)
	{
		byte[]? data = AvatarStore.Load(name);
		if (data == null)
		{
			AvatarBrush.ImageSource = null;
			AvatarInitial.Visibility = Visibility.Visible;
			return;
		}
		try
		{
			BitmapImage image = new BitmapImage();
			image.BeginInit();
			image.CacheOption = BitmapCacheOption.OnLoad;
			image.DecodePixelWidth = 256;
			image.StreamSource = new MemoryStream(data);
			image.EndInit();
			image.Freeze();
			AvatarBrush.ImageSource = image;
			AvatarInitial.Visibility = Visibility.Collapsed;
		}
		catch (Exception)
		{
			AvatarBrush.ImageSource = null;
			AvatarInitial.Visibility = Visibility.Visible;
		}
	}

	private void OnAvatarClick(object sender, MouseButtonEventArgs e)
	{
		if (_evoUser == null || string.IsNullOrWhiteSpace(_evoUser.Username))
		{
			return;
		}
		e.Handled = true;
		string name = _evoUser.Username!;
		if ((Keyboard.Modifiers & ModifierKeys.Shift) == ModifierKeys.Shift)
		{
			AvatarStore.Clear(name);
			ApplyAvatar(name);
			_homeStatus.Report("Avatar reset to the first letter.");
			return;
		}
		OpenFileDialog dialog = new OpenFileDialog
		{
			Title = "Choose an avatar",
			Filter = "Images (*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.gif)|*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.gif|All files (*.*)|*.*",
			CheckFileExists = true,
			Multiselect = false
		};
		if (dialog.ShowDialog(this) != true)
		{
			return;
		}
		try
		{
			byte[] bytes = File.ReadAllBytes(dialog.FileName);
			if (bytes.Length > 8388608)
			{
				_homeStatus.Report("Avatar is too large: 8 MB maximum.");
				return;
			}
			if (!AvatarStore.Save(name, bytes))
			{
				_homeStatus.Report("Could not save the avatar.");
				return;
			}
			ApplyAvatar(name);
			_homeStatus.Report("Avatar updated. Shift+click the avatar to reset it.");
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
		{
			_homeStatus.Report("Could not read the image: " + ex.Message);
		}
	}

	private async Task ShowHomeAsync(ShadeVisUser user)
    {
        ApplyIdentity(user);
        McVersion.Text = "1.21.11";
        ModVersion.Text = "";
        SidebarBuild.Text = "ShadeVis";
        LoginRoot.Visibility = Visibility.Collapsed;
        ShellRoot.Visibility = Visibility.Visible;
        SessionState.Text = "Signed in";
        LaunchProgress.Visibility = Visibility.Collapsed;
        StartBackgroundVideo();
        _homeStatus.Report("Signed in as " + (user.Username ?? "player") + ". Modrinth downloads are enabled.");
        await RefreshInstalledAsync(false);
        await RefreshRuntimeAsync();
    }

	private void ApplyHeroBackground()
	{
		try
		{
			string path = System.IO.Path.Combine(AppContext.BaseDirectory, "assets", "hero.png");
			if (!File.Exists(path))
			{
				return;
			}
			BitmapImage image = new BitmapImage();
			image.BeginInit();
			image.CacheOption = BitmapCacheOption.OnLoad;
			image.UriSource = new Uri(path);
			image.EndInit();
			image.Freeze();
			HeroClip.Background = new ImageBrush(image)
			{
				Stretch = Stretch.UniformToFill,
				AlignmentX = AlignmentX.Center,
				AlignmentY = AlignmentY.Center
			};
		}
		catch (Exception)
		{
		}
	}

	private void StartBackgroundVideo()
	{
		if (_videoReady)
		{
			BgVideo.Play();
			return;
		}
		string text = System.IO.Path.Combine(AppContext.BaseDirectory, "assets", "background.mp4");
		if (File.Exists(text))
		{
			BgVideo.Source = new Uri(text);
			BgVideo.Volume = 0.0;
			BgVideo.Play();
			_videoReady = true;
		}
	}

	private void OnVideoEnded(object sender, RoutedEventArgs e)
	{
		BgVideo.Position = TimeSpan.Zero;
		BgVideo.Play();
	}


	private void OnBrowseMods(object sender, RoutedEventArgs e)
	{
		NavMods.IsChecked = true;
	}

	private void OnOpenMods(object sender, RoutedEventArgs e)
	{
		_paths.EnsureCreated();
		OpenFolder(_paths.Mods);
	}

	private void OnOpenInstance(object sender, RoutedEventArgs e)
	{
		_paths.EnsureCreated();
		OpenFolder(_paths.Root);
	}

	private void OnChangeInstallLocation(object sender, RoutedEventArgs e)
	{
		OpenFolderDialog openFolderDialog = new OpenFolderDialog
		{
			Title = "Choose where to install the ShadeVis client",
			Multiselect = false
		};
		if (openFolderDialog.ShowDialog(this).GetValueOrDefault() && !string.IsNullOrWhiteSpace(openFolderDialog.FolderName))
		{
			_ = RelocateInstanceAsync(InstancePaths.RootInside(openFolderDialog.FolderName));
		}
	}

	private void OnDefaultInstallLocation(object sender, RoutedEventArgs e)
	{
		_ = RelocateInstanceAsync(InstancePaths.DefaultRoot);
	}

	private async Task RelocateInstanceAsync(string destination)
	{
		if (_launchBusy || _launching || _importingPack)
		{
			_moveStatus.Report("Wait for the current launch or pack import to finish first.");
			return;
		}
		SetRelocating(relocating: true);
		try
		{
			if ((await Task.Run(() => RunningGame.Reconcile(_paths))).Blocked)
			{
				throw new RelocationException("Close Minecraft before moving the client.");
			}
			string target = InstanceRelocator.Normalize(destination);
			await Task.Run(() => InstanceRelocator.RelocateAsync(_paths.Root, target, _moveStatus, _movePercent, CancellationToken.None));
			bool flag = string.Equals(target, InstanceRelocator.Normalize(InstancePaths.DefaultRoot), StringComparison.OrdinalIgnoreCase);
			LauncherSettings.Save(LauncherSettings.Current with
			{
				InstallRoot = (flag ? null : target)
			});
			_moveStatus.Report("Moved. Restarting the launcher...");
			RestartLauncher();
		}
		catch (Exception ex) when (((ex is RelocationException || ex is IOException || ex is UnauthorizedAccessException || ex is ArgumentException) ? 1 : 0) != 0)
		{
			_moveStatus.Report(string.Format("Could not move the client: {0}", ex.Message));
			SetRelocating(relocating: false);
		}
	}

	private void SetRelocating(bool relocating)
	{
		SetLaunchBusy(relocating);
		MoveInstanceButton.IsEnabled = !relocating;
		DefaultInstanceButton.IsEnabled = !relocating && LauncherSettings.Current.InstallRoot != null;
		MoveInstanceProgress.Value = 0.0;
		MoveInstanceProgress.Visibility = ((!relocating) ? Visibility.Collapsed : Visibility.Visible);
	}

	private static void RestartLauncher()
	{
		string processPath = Environment.ProcessPath;
		if (processPath != null)
		{
			Process.Start(new ProcessStartInfo(processPath)
			{
				UseShellExecute = false
			});
		}
		Application.Current.Shutdown();
	}

	private static void OpenFolder(string path)
	{
		Process.Start(new ProcessStartInfo("explorer.exe", "\"" + path + "\"")
		{
			UseShellExecute = true
		});
	}

	private void OnCopyDevice(object sender, RoutedEventArgs e)
	{
		try
		{
			Clipboard.SetText(HwidGuard.Display);
		}
		catch (COMException)
		{
		}
	}

	private async void OnCheckUpdates(object sender, RoutedEventArgs e)
	{
		if ((object)_evoUser != null)
		{
			UpdateButton.IsEnabled = false;
			try
			{
				await new LauncherUpdater(_downloader).EnsureLatestAsync(_evoUser.Token, HardwareId.Value, _updateStatus, _percent, CancellationToken.None);
				_updateStatus.Report("The launcher is up to date.");
			}
			catch (Exception ex)
			{
				_updateStatus.Report(string.Format("Update check failed: {0}", ex.Message));
			}
			UpdateButton.IsEnabled = true;
		}
	}

	private void ApplyMemorySetting()
	{
		bool flag = LauncherSettings.Current.HeapGigabytes == 0;
		int num = GameLauncher.ConfiguredHeapGigabytes();
		_applyingSettings = true;
		MemorySlider.Minimum = 2.0;
		MemorySlider.Maximum = GameLauncher.AllowedHeapGigabytes();
		MemorySlider.Value = num;
		_applyingSettings = false;
		MemoryValue.Text = string.Format(flag ? "{0} GB · automatic" : "{0} GB", num);
		StatMemory.Text = string.Format("{0} GB", num);
	}

	private void OnMemoryChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
	{
		if (_ready && !_applyingSettings)
		{
			int num = (int)e.NewValue;
			MemoryValue.Text = string.Format("{0} GB", num);
			StatMemory.Text = string.Format("{0} GB", num);
			_settingsDebounce.Stop();
			_settingsDebounce.Start();
		}
	}

	private void OnSettingsDebounced(object? sender, EventArgs e)
	{
		_settingsDebounce.Stop();
		LauncherSettings.Save(LauncherSettings.Current with
		{
			HeapGigabytes = (int)MemorySlider.Value
		});
	}

	private void OnSearchChanged(object sender, TextChangedEventArgs e)
	{
		if (_ready)
		{
			SearchPlaceholder.Visibility = ((SearchBox.Text.Length != 0) ? Visibility.Collapsed : Visibility.Visible);
			if (TabBrowse.IsChecked.GetValueOrDefault())
			{
				_searchDebounce.Stop();
				_searchDebounce.Start();
			}
		}
	}

	private async void OnSearchDebounced(object? sender, EventArgs e)
	{
		_searchDebounce.Stop();
		await LoadBrowseAsync(append: false);
	}

	private async void OnSortChanged(object sender, RoutedEventArgs e)
	{
		if (_ready)
		{
			_sort = (SortRelevant.IsChecked.GetValueOrDefault() ? "relevance" : (SortUpdated.IsChecked.GetValueOrDefault() ? "updated" : "downloads"));
			if (TabBrowse.IsChecked.GetValueOrDefault())
			{
				await LoadBrowseAsync(append: false);
			}
		}
	}

	private async void OnModsTabChanged(object sender, RoutedEventArgs e)
	{
		if (_ready)
		{
			bool valueOrDefault = TabBrowse.IsChecked.GetValueOrDefault();
			SortRow.Visibility = ((!valueOrDefault) ? Visibility.Collapsed : Visibility.Visible);
			ModsList.ItemsSource = (valueOrDefault ? _browse : _installed);
			if (valueOrDefault)
			{
				_browseLoaded = true;
				await LoadBrowseAsync(append: false);
			}
			else
			{
				await RefreshInstalledAsync(showOnModsPage: true);
			}
		}
	}

	private async void OnLoadMore(object sender, RoutedEventArgs e)
	{
		await LoadBrowseAsync(append: true);
	}

	private async Task LoadBrowseAsync(bool append)
	{
		_searchCancel?.Cancel();
		CancellationTokenSource request = (_searchCancel = new CancellationTokenSource());
		LoadMoreButton.IsEnabled = false;
		_modsStatus.Report("Searching Modrinth...");
		try
		{
			IReadOnlySet<string> installed = await Task.Run((Func<IReadOnlySet<string>>)_catalog.InstalledProjects, request.Token);
			ModrinthPage modrinthPage = await _modrinth.SearchAsync(SearchBox.Text.Trim(), _sort, append ? _browse.Count : 0, 20, request.Token);
			if (request.IsCancellationRequested)
			{
				return;
			}
			if (!append)
			{
				_browse.Clear();
			}
			foreach (ModrinthHit hit in modrinthPage.Hits)
			{
				_browse.Add(ModListItem.FromHit(hit, installed));
			}
			_browseTotal = modrinthPage.TotalHits;
			_modsStatus.Report(string.Format("{0} mods available for Minecraft {1}", modrinthPage.TotalHits, "1.21.11"));
		}
		catch (OperationCanceledException)
		{
		}
		catch (Exception ex2)
		{
			_modsStatus.Report(string.Format("Modrinth is unreachable: {0}", ex2.Message));
		}
		finally
		{
			if (_searchCancel == request)
			{
				LoadMoreButton.IsEnabled = true;
				UpdateModsView();
			}
		}
	}

	private async Task RefreshInstalledAsync(bool showOnModsPage)
	{
		if (_launching || _importingPack)
		{
			return;
		}
		try
		{
			IReadOnlyList<InstalledMod> readOnlyList = await _catalog.ListAsync(CancellationToken.None);
			if (_launching)
			{
				return;
			}
			_library = readOnlyList;
			AdoptIntoActivePack(readOnlyList);
			_installed.Clear();
			_managed.Clear();
			foreach (InstalledMod item2 in readOnlyList)
			{
				ModListItem item = ModListItem.FromInstalled(item2);
				_installed.Add(item);
				if (item2.Active)
				{
					_managed.Add(item);
				}
			}
			ApplyInstanceSummary(readOnlyList);
			if (showOnModsPage)
			{
				_modsStatus.Report(string.Format("{0} mods in the instance", readOnlyList.Count));
			}
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
			if (showOnModsPage)
			{
				_modsStatus.Report("Reading the mods folder...");
			}
		}
		UpdateModsView();
	}

	private void AdoptIntoActivePack(IReadOnlyList<InstalledMod> mods)
	{
		List<string> files = (from mod in mods
			where mod.Active && !mod.Managed
			select mod.File).ToList();
		ModPack pack = _packs.Seed(files);
		_packs.Adopt(pack, files);
		ApplyPackIdentity(pack);
	}

	private void ApplyPackIdentity(ModPack pack)
	{
		SidebarPack.Text = string.Format("Pack: {0}", pack.Name);
		HeroPack.Text = pack.Name;
	}

	private void ApplyInstanceSummary(IReadOnlyList<InstalledMod> mods)
	{
		int num = mods.Count((InstalledMod mod) => mod.Active);
		StatMods.Text = num.ToString(CultureInfo.CurrentCulture);
		SidebarMods.Text = string.Format("{0} mods installed", num);
		bool flag = Holds(mods, "iris") && Holds(mods, "sodium");
		StatShaders.Text = (flag ? "Iris + Sodium" : "on first launch");
		InstanceModsNote.Text = string.Format("{0} installed · local files only", num);
		ManagedEmpty.Visibility = ((_managed.Count != 0) ? Visibility.Collapsed : Visibility.Visible);
	}

	private static bool Holds(IReadOnlyList<InstalledMod> mods, string modId)
	{
		foreach (InstalledMod mod in mods)
		{
			if (string.Equals(mod.Id, modId, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
		}
		return false;
	}

	private async Task RefreshRuntimeAsync()
	{
		string runtime = await Task.Run(delegate
		{
			try
			{
				return File.Exists(_paths.JavaExecutable) ? new JavaProvisioner(_paths, _downloader).DescribeRuntime(_paths.JavaExecutable) : "on first launch";
			}
			catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
			{
				return "on first launch";
			}
		});
		StatJava.Text = Shorten(runtime);
	}

	private static string Shorten(string runtime)
	{
		int num = runtime.IndexOf("(N/A)", StringComparison.Ordinal);
		if (num >= 0)
		{
			string text = runtime.Substring(0, num);
			int num2 = num + "(N/A)".Length;
			return (text + runtime.Substring(num2, runtime.Length - num2)).Trim();
		}
		return runtime;
	}

	private void UpdateModsView()
	{
		bool valueOrDefault = TabBrowse.IsChecked.GetValueOrDefault();
		int num = (valueOrDefault ? _browse.Count : _installed.Count);
		ModsEmpty.Text = (valueOrDefault ? "No mods match this search." : "No mods installed yet — install some from Browse.");
		ModsEmpty.Visibility = ((num != 0) ? Visibility.Collapsed : Visibility.Visible);
		LoadMoreButton.Visibility = ((!valueOrDefault || _browse.Count <= 0 || _browse.Count >= _browseTotal) ? Visibility.Collapsed : Visibility.Visible);
	}

	private async void OnModAction(object sender, RoutedEventArgs e)
	{
		if (!(sender is FrameworkElement { DataContext: var dataContext }) || !(dataContext is ModListItem item))
		{
			return;
		}
		if (item.Action == ModAction.Remove)
		{
			RemoveMod(item);
		}
		else if (item.Action == ModAction.Install && item.ProjectId != null)
		{
			item.Action = ModAction.Installing;
			try
			{
				int num = await _catalog.InstallAsync(item.ProjectId, _modsStatus, CancellationToken.None);
				item.Action = ModAction.Installed;
				_modsStatus.Report((num > 1) ? string.Format("Installed {0} and {1} required dependencies.", item.Title, num - 1) : string.Format("Installed {0}.", item.Title));
				await RefreshInstalledAsync(showOnModsPage: false);
			}
			catch (Exception ex)
			{
				item.Action = ModAction.Install;
				_modsStatus.Report(string.Format("Could not install {0}: {1}", item.Title, ex.Message));
			}
		}
	}

	private void RemoveMod(ModListItem item)
	{
		if ((object)item.Installed == null)
		{
			return;
		}
		_catalog.Remove(item.Installed);
		_packs.Forget(item.Installed.File);
		_installed.Remove(item);
		_managed.Remove(item);
		StatMods.Text = _managed.Count.ToString(CultureInfo.CurrentCulture);
		SidebarMods.Text = string.Format("{0} mods installed", _managed.Count);
		foreach (ModListItem item2 in _browse)
		{
			if (item2.ProjectId != null && item2.ProjectId == item.ProjectId)
			{
				item2.Action = ModAction.Install;
			}
		}
		_modsStatus.Report(string.Format("Removed {0}.", item.Title));
		UpdateModsView();
	}

	private async Task OpenCosmeticsAsync()
	{
		if ((object)_evoUser == null)
		{
			return;
		}
		if (!_cosmeticsLoaded)
		{
			_cosmeticsLoaded = true;
			foreach (CosmeticCategory item in CosmeticCatalog.Load())
			{
				_cosmeticTabs.Add(new CosmeticTab(item, item.Slot == _cosmeticSlot));
			}
			_viewer = new CharacterViewer(CharacterView);
			_thumbnails = new CosmeticThumbnails(new WindowInteropHelper(this).Handle);
			bool flag = await _viewer.InitialiseAsync();
			CharacterView.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
			ViewerFallback.Visibility = (flag ? Visibility.Collapsed : Visibility.Visible);
			ShowCosmetics();
		}
		await RefreshCharacterAsync();
	}

	private async Task RefreshCharacterAsync()
	{
		if ((object)_evoUser != null)
		{
			CosmeticsStatus.Text = "Loading your character...";
			Task<IReadOnlySet<string>?> owned = _character.OwnedAsync(_evoUser.Token, CancellationToken.None);
			try
			{
				_profile = await _character.LoadAsync(_evoUser.Token, CancellationToken.None);
			}
			catch (Exception ex) when (((ex is CharacterFailure || ex is HttpRequestException) ? 1 : 0) != 0)
			{
				CosmeticsStatus.Text = string.Format("Could not save: {0}", ex.Message);
				return;
			}
			_owned = await owned;
			CharacterName.Text = OfflineName();
			ApplyEquippedState();
			await PushCharacterAsync();
		}
	}

	private void ApplyEquippedState()
	{
		IReadOnlyDictionary<string, string> cosmetics = _profile?.Cosmetics ?? new Dictionary<string, string>();
		SessionCosmetics.Current = SessionCosmetics.Build(cosmetics);
		foreach (CosmeticItem cosmetic in _cosmetics)
		{
			cosmetic.Equipped = object.Equals(cosmetic.Key, Slot(cosmetics, cosmetic.Slot));
			cosmetic.Locked = IsLocked(cosmetic);
		}
		_equippedSlots.Clear();
		foreach (CosmeticTab cosmeticTab in _cosmeticTabs)
		{
			string text = Slot(cosmetics, cosmeticTab.Slot);
			if (text != null)
			{
				_equippedSlots.Add(new EquippedSlot(cosmeticTab.Slot, cosmeticTab.Title, DisplayName(cosmeticTab, text)));
			}
		}
		int count = _equippedSlots.Count;
		EquippedEmpty.Visibility = ((count != 0) ? Visibility.Collapsed : Visibility.Visible);
		ResetCosmeticsButton.IsEnabled = count > 0;
		CharacterWornCount.Text = string.Format("{0} equipped", count);
		CosmeticsStatus.Text = string.Format("{0} models · {1} equipped", _cosmetics.Count - 1, count);
	}

	private bool IsLocked(CosmeticItem item)
	{
		if (_owned != null && item.Key != null)
		{
			return !_owned.Contains(CharacterClient.ItemId(item.Slot, item.Key));
		}
		return false;
	}

	private void ShowCosmeticLocked(CosmeticItem item)
	{
		BrowserLauncher.TryOpen("https://www.evoproject.xyz/account#cosmetics");
		CosmeticsStatus.Text = string.Format("{0} is locked — unlock it on evoproject.xyz (opened in your browser).", item.Name);
	}

	private static string? Slot(IReadOnlyDictionary<string, string> cosmetics, string slot)
	{
		if (!cosmetics.TryGetValue(slot, out string value) || value.Length <= 0)
		{
			return null;
		}
		return value;
	}

	private static string DisplayName(CosmeticTab tab, string key)
	{
		foreach (CosmeticEntry entry in tab.Category.Entries)
		{
			if (entry.Key == key)
			{
				return entry.Name;
			}
		}
		return Pretty(key);
	}

	private static string Pretty(string key)
	{
		return string.Join(' ', key.Split('_', StringSplitOptions.RemoveEmptyEntries));
	}

	private async Task PushCharacterAsync()
	{
		if (_viewer == null || (object)_profile == null)
		{
			return;
		}
		string playerSkin = Slot(_profile.Cosmetics, "playerskin");
		string url = _profile.SkinUrl;
		bool slim = _profile.Slim;
		if (playerSkin != null)
		{
			string text = await _character.SkinPngAsync(playerSkin, CancellationToken.None);
			if (text != null)
			{
				url = "data:image/png;base64," + text;
				slim = playerSkin.EndsWith("_slim", StringComparison.Ordinal);
			}
		}
		await _viewer.ApplyAsync(url, slim, _profile.Cosmetics);
	}

	private void ShowCosmetics()
	{
		CosmeticTab cosmeticTab = null;
		foreach (CosmeticTab cosmeticTab2 in _cosmeticTabs)
		{
			if (cosmeticTab2.Slot == _cosmeticSlot)
			{
				cosmeticTab = cosmeticTab2;
			}
		}
		_cosmetics.Clear();
		if (cosmeticTab == null)
		{
			return;
		}
		string text = CosmeticsSearch.Text.Trim();
		_cosmetics.Add(CosmeticItem.None(cosmeticTab.Slot));
		foreach (CosmeticEntry entry in cosmeticTab.Category.Entries)
		{
			if (text.Length <= 0 || entry.Name.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0 || entry.Key.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_cosmetics.Add(CosmeticItem.Create(cosmeticTab.Slot, entry));
			}
		}
		CosmeticsEmpty.Visibility = ((_cosmetics.Count > 1 || text.Length <= 0) ? Visibility.Collapsed : Visibility.Visible);
		ApplyEquippedState();
		_thumbnailsCancel?.Cancel();
		_thumbnailsCancel = new CancellationTokenSource();
		_ = LoadThumbnailsAsync(_cosmetics.ToArray(), _thumbnailsCancel.Token);
	}

	private async Task LoadThumbnailsAsync(IReadOnlyList<CosmeticItem> items, CancellationToken cancel)
	{
		if (_thumbnails == null)
		{
			return;
		}
		foreach (CosmeticItem item in items)
		{
			if (cancel.IsCancellationRequested)
			{
				return;
			}
			if (item.Key != null && !item.HasPreview)
			{
				BitmapSource bitmapSource = await _thumbnails.LoadAsync(item.Slot, item.Key, cancel);
				if (cancel.IsCancellationRequested)
				{
					return;
				}
				if (bitmapSource != null)
				{
					item.ApplyThumbnail(bitmapSource);
				}
			}
		}
	}

	private void OnCosmeticTabChanged(object sender, RoutedEventArgs e)
	{
		if (_ready && _cosmeticsLoaded && sender is FrameworkElement { DataContext: CosmeticTab dataContext })
		{
			_cosmeticSlot = dataContext.Slot;
			ShowCosmetics();
		}
	}

	private void OnCosmeticsSearchChanged(object sender, TextChangedEventArgs e)
	{
		if (_ready)
		{
			CosmeticsSearchHint.Visibility = ((CosmeticsSearch.Text.Length != 0) ? Visibility.Collapsed : Visibility.Visible);
			if (_cosmeticsLoaded)
			{
				ShowCosmetics();
			}
		}
	}

	private async void OnCosmeticClick(object sender, RoutedEventArgs e)
	{
		if ((object)_evoUser == null || !(sender is FrameworkElement { DataContext: var dataContext }) || !(dataContext is CosmeticItem item))
		{
			return;
		}
		if (item.Locked)
		{
			ShowCosmeticLocked(item);
			return;
		}
		try
		{
			await EquipSlotAsync(item.Slot, item.Key);
			CosmeticsStatus.Text = ((item.Key == null) ? string.Format("{0} cleared", item.Slot) : string.Format("{0} equipped", item.Name));
		}
		catch (CharacterFailure characterFailure) when (characterFailure.Message == "not_owned")
		{
			_owned = (await _character.OwnedAsync(_evoUser.Token, CancellationToken.None)) ?? _owned;
			ApplyEquippedState();
			ShowCosmeticLocked(item);
		}
		catch (Exception ex) when (((ex is CharacterFailure || ex is HttpRequestException) ? 1 : 0) != 0)
		{
			CosmeticsStatus.Text = string.Format("Could not save: {0}", ex.Message);
		}
	}

	private async Task EquipSlotAsync(string slot, string? key)
	{
		CharacterProfile characterProfile = await _character.EquipAsync(_evoUser.Token, slot, key, CancellationToken.None);
		_profile = (((object)_profile == null) ? characterProfile : _profile with
		{
			Cosmetics = characterProfile.Cosmetics,
			Skins = characterProfile.Skins
		});
		if (_viewer != null)
		{
			await _viewer.PreviewAsync(null, null);
		}
		ApplyEquippedState();
		await PushCharacterAsync();
	}

	private async void OnUnequipSlot(object sender, RoutedEventArgs e)
	{
		if ((object)_evoUser == null || !(sender is FrameworkElement { DataContext: var dataContext }) || !(dataContext is EquippedSlot slot))
		{
			return;
		}
		try
		{
			await EquipSlotAsync(slot.Slot, null);
			CosmeticsStatus.Text = string.Format("{0} cleared", slot.Name);
		}
		catch (Exception ex) when (((ex is CharacterFailure || ex is HttpRequestException) ? 1 : 0) != 0)
		{
			CosmeticsStatus.Text = string.Format("Could not save: {0}", ex.Message);
		}
	}

	private async void OnCosmeticHover(object sender, MouseEventArgs e)
	{
		if (_viewer != null && sender is FrameworkElement { DataContext: CosmeticItem dataContext })
		{
			await _viewer.PreviewAsync(dataContext.Slot, dataContext.Key);
		}
	}

	private async void OnCosmeticUnhover(object sender, MouseEventArgs e)
	{
		if (_viewer != null)
		{
			await _viewer.PreviewAsync(null, null);
		}
	}

	private async void OnResetCosmetics(object sender, RoutedEventArgs e)
	{
		if ((object)_evoUser == null)
		{
			return;
		}
		Dictionary<string, string> dictionary = new Dictionary<string, string> { ["playerskin"] = null };
		foreach (CosmeticTab cosmeticTab in _cosmeticTabs)
		{
			dictionary[cosmeticTab.Slot] = null;
		}
		try
		{
			CharacterProfile characterProfile = await _character.SetAsync(_evoUser.Token, dictionary, CancellationToken.None);
			_profile = (((object)_profile == null) ? characterProfile : _profile with
			{
				Cosmetics = characterProfile.Cosmetics,
				Skins = characterProfile.Skins
			});
			ApplyEquippedState();
			await PushCharacterAsync();
			MarkAppliedSkin(null);
		}
		catch (Exception ex) when (((ex is CharacterFailure || ex is HttpRequestException) ? 1 : 0) != 0)
		{
			CosmeticsStatus.Text = string.Format("Could not save: {0}", ex.Message);
		}
	}

	private async Task ResumeSpinAsync()
	{
		SkinsPage.UpdateLayout();
		await base.Dispatcher.InvokeAsync(delegate
		{
		}, DispatcherPriority.ApplicationIdle);
		await Task.Delay(SpinResumeDelay);
		await base.Dispatcher.InvokeAsync(delegate
		{
		}, DispatcherPriority.ApplicationIdle);
		if (NavSkins.IsChecked.GetValueOrDefault())
		{
			PlayerModel.Resume();
		}
	}

	private async Task OpenSkinsAsync()
	{
		if ((object)_evoUser != null && !_skinsLoaded)
		{
			_skinsLoaded = true;
			_browser = new HiddenBrowser(new WindowInteropHelper(this).Handle);
			_nameMc = new NameMcClient(_browser, _downloader);
			if ((object)_profile == null)
			{
				await RefreshCharacterAsync();
			}
			await LoadSkinsAsync(append: false);
		}
	}

	private async Task LoadSkinsAsync(bool append)
	{
		if (_nameMc == null || (object)_evoUser == null)
		{
			return;
		}
		_skinsCancel?.Cancel();
		CancellationTokenSource request = (_skinsCancel = new CancellationTokenSource());
		SkinsMoreButton.IsEnabled = false;
		if (!SkinsLibrary.IsChecked.GetValueOrDefault())
		{
			SkinsStatus.Text = "Loading skins from NameMC...";
			try
			{
				IReadOnlyList<NameMcSkin> readOnlyList = await _nameMc.ListAsync(_skinSource, (!append) ? 1 : _skinPage, request.Token);
				if (request.IsCancellationRequested)
				{
					return;
				}
				if (!append)
				{
					_skins.Clear();
					_skinPage = 1;
				}
				List<SkinItem> list = new List<SkinItem>(readOnlyList.Count);
				foreach (NameMcSkin item2 in readOnlyList)
				{
					SkinItem item = SkinItem.FromNameMc(item2, applied: false);
					list.Add(item);
					_skins.Add(item);
				}
				_ = LoadModelsAsync(list, request.Token);
				SkinsStatus.Text = ((readOnlyList.Count == 0 && _skins.Count == 0) ? string.Empty : string.Format("{0} skins · in game: {1}", _skins.Count, AppliedSkinLabel()));
				SkinsEmpty.Text = ((_browser == null || readOnlyList.Count > 0) ? "NameMC returned nothing for this selection. Try another category." : "Browsing NameMC needs the Microsoft Edge WebView2 runtime. Install it and reopen this tab.");
				SkinsEmpty.Visibility = ((_skins.Count != 0) ? Visibility.Collapsed : Visibility.Visible);
				SkinsMoreButton.Visibility = ((readOnlyList.Count <= 0 || !(_skinSource != "random")) ? Visibility.Collapsed : Visibility.Visible);
				_skinPage++;
				return;
			}
			catch (Exception ex) when (((ex is HttpRequestException || ex is JsonException || ex is InvalidOperationException) ? 1 : 0) != 0)
			{
				SkinsStatus.Text = string.Format("Could not apply the skin: {0}", ex.Message);
				return;
			}
			finally
			{
				SkinsMoreButton.IsEnabled = true;
			}
		}
		await ShowLibraryAsync(request.Token);
		SkinsMoreButton.Visibility = Visibility.Collapsed;
		SkinsMoreButton.IsEnabled = true;
	}

	private async Task ShowLibraryAsync(CancellationToken cancel)
	{
		_skins.Clear();
		if ((object)_profile == null)
		{
			return;
		}
		string text = Slot(_profile.Cosmetics, "playerskin");
		foreach (SkinEntry skin in _profile.Skins)
		{
			_skins.Add(SkinItem.FromLibraryEntry(skin, skin.Key == text));
		}
		SkinsStatus.Text = string.Format("{0} of {1} slots used in your library", _skins.Count, 12);
		SkinsEmpty.Text = "Your library is empty — apply a skin from NameMC to fill it.";
		SkinsEmpty.Visibility = ((_skins.Count != 0) ? Visibility.Collapsed : Visibility.Visible);
		await LoadModelsAsync(_skins.ToArray(), cancel);
	}

	private async Task LoadModelsAsync(IReadOnlyList<SkinItem> items, CancellationToken cancel)
	{
		using SemaphoreSlim gate = new SemaphoreSlim(4);
		List<Task> list = new List<Task>(items.Count);
		foreach (SkinItem item in items)
		{
			list.Add(LoadModelAsync(item, gate, cancel));
		}
		await Task.WhenAll(list);
	}

	private async Task LoadModelAsync(SkinItem item, SemaphoreSlim gate, CancellationToken cancel)
	{
		SkinItem item2 = item;
		try
		{
			await gate.WaitAsync(cancel);
		}
		catch (OperationCanceledException)
		{
			return;
		}
		try
		{
			byte[] png = await SkinBytesAsync(item2, cancel);
			if (png != null && !cancel.IsCancellationRequested)
			{
				PlayerSkin playerSkin = await Task.Run(() => PlayerModel.Prepare(png, item2.FromLibrary ? new bool?(item2.Slim) : null), cancel);
				if ((object)playerSkin != null && !cancel.IsCancellationRequested)
				{
					item2.Model = PlayerModel.Build(playerSkin);
				}
			}
		}
		catch (Exception ex2) when (((ex2 is HttpRequestException || ex2 is OperationCanceledException || ex2 is InvalidOperationException) ? 1 : 0) != 0)
		{
		}
		finally
		{
			gate.Release();
		}
	}

	private async Task<byte[]?> SkinBytesAsync(SkinItem item, CancellationToken cancel)
	{
		if (item.LibraryKey != null)
		{
			string text = await _character.SkinPngAsync(item.LibraryKey, cancel);
			return (text == null) ? null : Convert.FromBase64String(text);
		}
		return (_nameMc != null) ? (await _nameMc.TextureAsync(item.Id, cancel)) : null;
	}

	private void OnSkinSourceChanged(object sender, RoutedEventArgs e)
	{
		if (_ready && _skinsLoaded)
		{
			_skinSource = (SkinsWeekly.IsChecked.GetValueOrDefault() ? "trending/weekly" : (SkinsNew.IsChecked.GetValueOrDefault() ? "new" : (SkinsRandom.IsChecked.GetValueOrDefault() ? "random" : "trending/daily")));
			_ = LoadSkinsAsync(append: false);
		}
	}

	private void OnSkinSearchChanged(object sender, TextChangedEventArgs e)
	{
		if (_ready)
		{
			SkinSearchHint.Visibility = ((SkinSearch.Text.Length != 0) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private async void OnSkinSearchKey(object sender, KeyEventArgs e)
	{
		if (e.Key == Key.Return && _skinsLoaded)
		{
			string text = SkinSearch.Text.Trim();
			_skinSource = ((text.Length == 0) ? "trending/daily" : NameMcClient.Tag(text));
			SkinsTrending.IsChecked = text.Length == 0;
			await LoadSkinsAsync(append: false);
		}
	}

	private void OnSkinHover(object sender, MouseEventArgs e)
	{
		if (!PlayerModel.Accelerated && sender is FrameworkElement { DataContext: SkinItem dataContext })
		{
			PlayerModel.SetSpinning(dataContext.Model, spinning: true);
		}
	}

	private void OnSkinUnhover(object sender, MouseEventArgs e)
	{
		if (!PlayerModel.Accelerated && sender is FrameworkElement { DataContext: SkinItem dataContext })
		{
			PlayerModel.SetSpinning(dataContext.Model, spinning: false);
		}
	}

	private async void OnSkinsLoadMore(object sender, RoutedEventArgs e)
	{
		await LoadSkinsAsync(append: true);
	}

	private async void OnSkinApply(object sender, RoutedEventArgs e)
	{
		if ((object)_evoUser == null || _nameMc == null || !(sender is FrameworkElement { DataContext: var dataContext }) || !(dataContext is SkinItem item))
		{
			return;
		}
		item.Action = SkinAction.Applying;
		try
		{
			string text = item.LibraryKey;
			if (text == null)
			{
				text = await ImportAsync(item);
			}
			string key = text;
			CharacterProfile characterProfile = await _character.EquipAsync(_evoUser.Token, "playerskin", key, CancellationToken.None);
			_profile = (((object)_profile == null) ? characterProfile : _profile with
			{
				Cosmetics = characterProfile.Cosmetics,
				Skins = characterProfile.Skins
			});
			MarkAppliedSkin(item);
			await PushCharacterAsync();
			SkinsStatus.Text = string.Format("{0} applied — the client picks it up on the next cosmetics sync.", item.Name);
		}
		catch (CharacterFailure characterFailure)
		{
			item.Action = SkinAction.Apply;
			SkinsStatus.Text = ((characterFailure.Message == "skin_library_full") ? "Your skin library is full (12). Remove one under MY SKINS first." : string.Format("Could not apply the skin: {0}", characterFailure.Message));
		}
		catch (Exception ex) when (((ex is HttpRequestException || ex is InvalidOperationException) ? 1 : 0) != 0)
		{
			item.Action = SkinAction.Apply;
			SkinsStatus.Text = string.Format("Could not apply the skin: {0}", ex.Message);
		}
	}

	private async Task<string> ImportAsync(SkinItem item)
	{
		byte[] png = await _nameMc.TextureAsync(item.Id, CancellationToken.None);
		bool slim = await Task.Run(() => PlayerModel.IsSlim(png));
		try
		{
			return await _character.AddSkinAsync(_evoUser.Token, item.Name, slim, png, CancellationToken.None);
		}
		catch (CharacterFailure characterFailure) when (characterFailure.Message == "skin_duplicate")
		{
			return CharacterClient.SkinKey(png, slim);
		}
	}

	private string AppliedSkinLabel()
	{
		string text = (((object)_profile == null) ? null : Slot(_profile.Cosmetics, "playerskin"));
		if (text == null || (object)_profile == null)
		{
			return "no skin";
		}
		foreach (SkinEntry skin in _profile.Skins)
		{
			if (skin.Key == text)
			{
				return skin.Name;
			}
		}
		return "custom skin";
	}

	private void MarkAppliedSkin(SkinItem? applied)
	{
		foreach (SkinItem skin in _skins)
		{
			skin.Action = ((skin == applied) ? SkinAction.Applied : SkinAction.Apply);
		}
	}

	private async void OnSkinRemove(object sender, RoutedEventArgs e)
	{
		if ((object)_evoUser == null || !(sender is FrameworkElement { DataContext: var dataContext }) || !(dataContext is SkinItem { LibraryKey: not null } item))
		{
			return;
		}
		try
		{
			await _character.RemoveSkinAsync(_evoUser.Token, item.LibraryKey, CancellationToken.None);
			_skins.Remove(item);
			await RefreshCharacterAsync();
			SkinsStatus.Text = string.Format("{0} removed from your library.", item.Name);
		}
		catch (Exception ex) when (((ex is CharacterFailure || ex is HttpRequestException) ? 1 : 0) != 0)
		{
			SkinsStatus.Text = string.Format("Could not apply the skin: {0}", ex.Message);
		}
	}

	private async Task<RendererDecision> EnsureRendererAsync(string javaExecutable, HttpDownloader downloader)
	{
		_homeStatus.Report("Checking graphics support...");
		GlSupport support = await Task.Run((Func<GlSupport>)OpenGlProbe.Detect);
		if (support.MeetsMinimum)
		{
			GraphicsProvisioner.Remove(javaExecutable);
			return new RendererDecision(support, Software: false);
		}
		IProgress<string> homeStatus = _homeStatus;
		DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(58, 3);
		defaultInterpolatedStringHandler.AppendLiteral("No OpenGL ");
		defaultInterpolatedStringHandler.AppendFormatted(3);
		defaultInterpolatedStringHandler.AppendLiteral(".");
		defaultInterpolatedStringHandler.AppendFormatted(3);
		defaultInterpolatedStringHandler.AppendLiteral(" driver ");
		defaultInterpolatedStringHandler.AppendLiteral("(");
		defaultInterpolatedStringHandler.AppendFormatted(support.Description);
		defaultInterpolatedStringHandler.AppendLiteral(") - switching to software rendering...");
		homeStatus.Report(defaultInterpolatedStringHandler.ToStringAndClear());
		await new GraphicsProvisioner(_paths, downloader).InstallAsync(javaExecutable, _homeStatus, _percent, CancellationToken.None);
		return new RendererDecision(support, Software: true);
	}

	private LaunchTelemetry BuildTelemetry(string launchEvent, string name, string java, GlSupport? graphics, bool softwareRenderer, ModDelivery delivery, long elapsedMs, string stage, string? error)
	{
		return new LaunchTelemetry(launchEvent, name, ModVersion.Text, "1.21.11", java, GraphicsAdapter(graphics), GraphicsVersion(graphics), softwareRenderer, ModJarCount(), delivery.Ready, delivery.Entitled, elapsedMs, (error == null) ? null : stage, error, DeliveryMirror.IsPreferred);
	}

	private static string GraphicsAdapter(GlSupport? graphics)
	{
		if ((object)graphics == null)
		{
			return string.Empty;
		}
		if (graphics.Renderer.Length <= 0)
		{
			return graphics.Vendor;
		}
		return graphics.Renderer;
	}

	private static string GraphicsVersion(GlSupport? graphics)
	{
		if ((object)graphics == null)
		{
			return string.Empty;
		}
		if (graphics.Failure.Length <= 0)
		{
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 2);
			defaultInterpolatedStringHandler.AppendFormatted(graphics.Major);
			defaultInterpolatedStringHandler.AppendLiteral(".");
			defaultInterpolatedStringHandler.AppendFormatted(graphics.Minor);
			return defaultInterpolatedStringHandler.ToStringAndClear();
		}
		return graphics.Failure;
	}

	private int ModJarCount()
	{
		try
		{
			return Directory.Exists(_paths.Mods) ? Directory.GetFiles(_paths.Mods, "*.jar").Length : 0;
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
			return 0;
		}
	}

	private async Task OpenPacksAsync()
	{
		await RefreshInstalledAsync(showOnModsPage: false);
		RebuildPacks();
	}

	private void RebuildPacks()
	{
		ModPack active = _packs.Active;
		_packItems.Clear();
		foreach (ModPack pack in _packs.Packs)
		{
			_packItems.Add(new PackItem(pack, pack == active));
		}
		PackItem chosen = _packItems.FirstOrDefault((PackItem item) => item.Id == _selectedPackId) ?? _packItems.FirstOrDefault((PackItem item) => item.IsActive) ?? _packItems.FirstOrDefault();
		Select(chosen);
	}

	private void Select(PackItem? chosen)
	{
		_selectedPackId = chosen?.Id;
		foreach (PackItem packItem in _packItems)
		{
			packItem.IsSelected = packItem == chosen;
		}
		ShowSelectedPack(chosen);
	}

	private void ShowSelectedPack(PackItem? chosen)
	{
		bool flag = chosen != null;
		PackNameBox.IsEnabled = flag;
		PlayPackButton.IsEnabled = flag && !_launchBusy;
		DuplicatePackButton.IsEnabled = flag;
		ExportPackButton.IsEnabled = flag && !_importingPack;
		DeletePackButton.IsEnabled = flag && _packItems.Count > 1;
		_renamingPack = true;
		PackNameBox.Text = chosen?.Name ?? string.Empty;
		_renamingPack = false;
		_packMods.Clear();
		if (chosen == null)
		{
			PackSummary.Text = "No mods selected · applied on launch";
			PackModsEmpty.Visibility = Visibility.Visible;
			return;
		}
		HashSet<string> hashSet = new HashSet<string>(chosen.Pack.Files, StringComparer.OrdinalIgnoreCase);
		foreach (InstalledMod item in _library)
		{
			_packMods.Add(new PackModItem(item, hashSet.Contains(item.File)));
		}
		PackModsEmpty.Visibility = ((_packMods.Count != 0) ? Visibility.Collapsed : Visibility.Visible);
		ShowPackSummary(chosen);
	}

	private void ShowPackSummary(PackItem chosen)
	{
		int num = _packMods.Count((PackModItem mod) => mod.IsEditable);
		int num2 = _packMods.Count((PackModItem mod) => mod.IsEditable && mod.Included);
		PackSummary.Text = ((num2 == 0) ? "No mods selected · applied on launch" : string.Format("{0} of {1} library mods · applied on launch", num2, num));
		chosen.Refresh();
	}

	private PackItem? SelectedPack()
	{
		return _packItems.FirstOrDefault((PackItem item) => item.IsSelected);
	}

	private void MarkActivePack()
	{
		ModPack active = _packs.Active;
		foreach (PackItem packItem in _packItems)
		{
			packItem.IsActive = packItem.Pack == active;
		}
		if (active != null)
		{
			ApplyPackIdentity(active);
		}
	}

	private void OnSelectPack(object sender, RoutedEventArgs e)
	{
		if (sender is FrameworkElement { DataContext: PackItem dataContext })
		{
			Select(dataContext);
		}
	}

	private void OnPackModToggled(object sender, RoutedEventArgs e)
	{
		PackItem packItem = SelectedPack();
		if (packItem != null && sender is FrameworkElement { DataContext: PackModItem { IsEditable: not false } dataContext })
		{
			_packs.Include(packItem.Pack, dataContext.File, dataContext.Included);
			ShowPackSummary(packItem);
			_packsStatus.Report(string.Format(dataContext.Included ? "{0} added to {1}." : "{0} removed from {1}.", dataContext.Title, packItem.Name));
		}
	}

	private void OnNewPackNameChanged(object sender, TextChangedEventArgs e)
	{
		if (_ready)
		{
			NewPackHint.Visibility = ((NewPackName.Text.Length != 0) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void OnNewPackKeyDown(object sender, KeyEventArgs e)
	{
		if (e.Key == Key.Return)
		{
			e.Handled = true;
			OnCreatePack(sender, e);
		}
	}

	private void OnCreatePack(object sender, RoutedEventArgs e)
	{
		string text = NewPackName.Text.Trim();
		if (text.Length == 0)
		{
			text = string.Format("Pack {0}", _packItems.Count + 1);
		}
		ModPack modPack = _packs.Create(text, Array.Empty<string>());
		NewPackName.Clear();
		_selectedPackId = modPack.Id;
		RebuildPacks();
		_packsStatus.Report(string.Format("Created {0}.", modPack.Name));
	}

	private void OnDuplicatePack(object sender, RoutedEventArgs e)
	{
		PackItem packItem = SelectedPack();
		if (packItem != null)
		{
			ModPack modPack = _packs.Create(packItem.Name + " copy", packItem.Pack.Files);
			_selectedPackId = modPack.Id;
			RebuildPacks();
			_packsStatus.Report(string.Format("Created {0}.", modPack.Name));
		}
	}

	private void OnDeletePack(object sender, RoutedEventArgs e)
	{
		PackItem packItem = SelectedPack();
		if (packItem != null)
		{
			if (!_packs.Delete(packItem.Pack))
			{
				_packsStatus.Report("The last pack cannot be deleted.");
				return;
			}
			_selectedPackId = null;
			RebuildPacks();
			MarkActivePack();
			_packsStatus.Report(string.Format("Deleted {0}.", packItem.Name));
		}
	}

	private void OnPackNameKeyDown(object sender, KeyEventArgs e)
	{
		if (e.Key == Key.Return)
		{
			e.Handled = true;
			CommitPackName();
		}
	}

	private void OnPackNameCommitted(object sender, RoutedEventArgs e)
	{
		CommitPackName();
	}

	private void CommitPackName()
	{
		PackItem packItem = SelectedPack();
		if (!_renamingPack && packItem != null && _packs.Rename(packItem.Pack, PackNameBox.Text))
		{
			packItem.Refresh();
			MarkActivePack();
			_packsStatus.Report(string.Format("Renamed to {0}.", packItem.Name));
		}
	}

	private void OnLaunchPack(object sender, RoutedEventArgs e)
	{
		PackItem packItem = SelectedPack();
		if (packItem != null && (object)_evoUser != null && !_launchBusy)
		{
			_packs.Activate(packItem.Pack);
			MarkActivePack();
			_packsStatus.Report(string.Format("{0} is live.", packItem.Name));
			_launching = true;
			NavHome.IsChecked = true;
			OnLaunch(sender, e);
		}
	}

	private async Task<MinecraftSession> ResolveMinecraftSessionAsync()
	{
		MicrosoftAccount account = _microsoft;
		if ((object)account == null)
		{
			return GameLauncher.OfflineSession(OfflineName());
		}
		try
		{
			MicrosoftAccount microsoftAccount = await MicrosoftAuth.EnsureFreshAsync(account, MinecraftTokenReserve, CancellationToken.None);
			if ((object)microsoftAccount != account)
			{
				StoreMinecraftAccount(microsoftAccount);
			}
			return microsoftAccount.ToSession();
		}
		catch (MicrosoftAuthException ex) when (ex.SignInRequired)
		{
			ForgetMinecraftAccount();
			throw;
		}
	}

	private async void OnMinecraftAccount(object sender, RoutedEventArgs e)
	{
		if (_microsoftBusy || _launchBusy)
		{
			return;
		}
		if ((object)_microsoft != null)
		{
			ForgetMinecraftAccount();
			return;
		}
		_microsoftBusy = true;
		MinecraftAccountButton.IsEnabled = false;
		MinecraftAccountStatus.Text = "Waiting for Microsoft sign-in...";
		string notice = null;
		try
		{
			MicrosoftSignInRequest request = MicrosoftAuth.CreateSignInRequest();
			string code = await MicrosoftSignInWindow.RequestCodeAsync(this, request);
			MinecraftAccountStatus.Text = "Waiting for Microsoft sign-in...";
			if (!StoreMinecraftAccount(await MicrosoftAuth.RedeemCodeAsync(code, CancellationToken.None)))
			{
				notice = "Signed in, but the Microsoft session could not be saved on this PC.";
			}
		}
		catch (Exception ex) when (((ex is MicrosoftAuthException || ex is HttpRequestException || ex is TaskCanceledException || ex is JsonException) ? 1 : 0) != 0)
		{
			notice = string.Format(CultureInfo.CurrentCulture, "Microsoft sign-in failed: {0}", ex.Message);
		}
		finally
		{
			_microsoftBusy = false;
			MinecraftAccountButton.IsEnabled = true;
		}
		ApplyMinecraftAccount(notice);
	}

	private bool StoreMinecraftAccount(MicrosoftAccount account)
	{
		_microsoft = account;
		bool result = MicrosoftAccountStorage.Save(account);
		ApplyMinecraftAccount(null);
		return result;
	}

	private void ForgetMinecraftAccount()
	{
		MicrosoftAccountStorage.Clear();
		_microsoft = null;
		ApplyMinecraftAccount(null);
	}

	private string OfflineName()
	{
		return string.IsNullOrWhiteSpace(_evoUser?.Username) ? "player" : _evoUser!.Username!;
	}

	private void ApplyMinecraftAccount(string? notice)
	{
		string text = OfflineName();
		bool linked = _microsoft != null;
		MinecraftAccountButton.Content = (linked ? "Sign out of Microsoft" : "Sign in with Microsoft");
		string text2 = (linked ? ("Signed in as " + _microsoft!.Name + " — servers see your licensed Minecraft account.") : ("Not linked — you play offline as " + text + ". Servers with premium login (e.g. AstrumMC) reject licensed nicknames without a Microsoft sign-in."));
		MinecraftAccountStatus.Text = ((notice == null) ? text2 : (notice + "\n" + text2));
		if (_evoUser != null)
		{
			PlayerName.Text = (linked ? _microsoft!.Name : text);
		}
	}

	private void SetLaunchBusy(bool busy)
	{
		_launchBusy = busy;
		LaunchButton.IsEnabled = !busy;
		ModsButton.IsEnabled = !busy;
		SidePlayButton.IsEnabled = !busy;
		PlayPackButton.IsEnabled = !busy && SelectedPack() != null;
		ImportPackButton.IsEnabled = !busy;
		MinecraftAccountButton.IsEnabled = !busy && !_microsoftBusy;
	}

	private void SetPackExchangeBusy(bool busy)
	{
		_importingPack = busy;
		ImportPackButton.IsEnabled = !busy && !_launchBusy;
		CreatePackButton.IsEnabled = !busy;
		ExportPackButton.IsEnabled = !busy && SelectedPack() != null;
		DuplicatePackButton.IsEnabled = !busy && SelectedPack() != null;
		DeletePackButton.IsEnabled = !busy && SelectedPack() != null && _packItems.Count > 1;
		PlayPackButton.IsEnabled = !busy && !_launchBusy && SelectedPack() != null;
	}

	private void OnExportPack(object sender, RoutedEventArgs e)
	{
		PackItem packItem = SelectedPack();
		if (packItem == null)
		{
			return;
		}
		SaveFileDialog saveFileDialog = new SaveFileDialog
		{
			Title = "Export pack",
			Filter = "ShadeVis mod pack (*.evopack)|*.evopack",
			DefaultExt = ".evopack",
			FileName = packItem.Name + ".evopack",
			AddExtension = true,
			OverwritePrompt = true
		};
		if (!saveFileDialog.ShowDialog(this).GetValueOrDefault())
		{
			return;
		}
		try
		{
			PackExport packExport = PackExchange.Write(packItem.Pack, _catalog.Entries(), saveFileDialog.FileName);
			if (packExport.Mods == 0)
			{
				_packsStatus.Report("Nothing to export — this pack has no mods installed from Modrinth.");
				return;
			}
			string text = string.Format("Exported {0} mods to {1}.", packExport.Mods, System.IO.Path.GetFileName(packExport.Path));
			if (packExport.Skipped > 0)
			{
				text += string.Format(" {0} mods without a Modrinth source were left out.", packExport.Skipped);
			}
			_packsStatus.Report(text);
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
			_packsStatus.Report("Could not write the .evopack file.");
		}
	}

	private async void OnImportPack(object sender, RoutedEventArgs e)
	{
		if (_importingPack || _launchBusy)
		{
			return;
		}
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Title = "Import pack",
			Filter = "ShadeVis mod pack (*.evopack)|*.evopack",
			DefaultExt = ".evopack",
			CheckFileExists = true,
			Multiselect = false
		};
		if (!openFileDialog.ShowDialog(this).GetValueOrDefault())
		{
			return;
		}
		PackManifest packManifest = PackExchange.Read(openFileDialog.FileName);
		if ((object)packManifest == null)
		{
			_packsStatus.Report("That file is not a valid .evopack export.");
			return;
		}
		SetPackExchangeBusy(busy: true);
		try
		{
			PackImport imported = await PackExchange.ImportAsync(packManifest, System.IO.Path.GetFileNameWithoutExtension(openFileDialog.FileName), _packs, _catalog, _packsStatus, CancellationToken.None);
			_selectedPackId = null;
			SetPackExchangeBusy(busy: false);
			await OpenPacksAsync();
			PackItem packItem = _packItems.LastOrDefault();
			if (packItem != null)
			{
				Select(packItem);
			}
			string text = string.Format("{0} imported with {1} mods.", imported.Name, imported.Mods);
			if (imported.Missing > 0)
			{
				text += string.Format(" {0} mods could not be downloaded.", imported.Missing);
			}
			_packsStatus.Report(text);
		}
		catch (Exception ex) when (((ex is HttpRequestException || ex is JsonException || ex is IOException || ex is InvalidOperationException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
			SetPackExchangeBusy(busy: false);
			_packsStatus.Report(string.Format("Import failed: {0}", ex.Message));
		}
	}

	private async Task ApplyActivePackAsync()
	{
		ModPack active = _packs.Active;
		if (active == null)
		{
			ReportConflicts(await Task.Run(() => _packs.ParkConflicts(CancellationToken.None)));
			return;
		}
		_homeStatus.Report(string.Format("Applying pack {0}...", active.Name));
		PackSync packSync = await _packs.ApplyAsync(active, _catalog, _homeStatus, CancellationToken.None);
		if (packSync.Linked > 0)
		{
			_homeStatus.Report(string.Format("Added {0} missing dependencies to the pack.", packSync.Linked));
		}
		ReportConflicts(packSync.Conflicts);
		if (packSync.Missing > 0)
		{
			_homeStatus.Report(string.Format("{0} pack mods could not be restored and were skipped.", packSync.Missing));
		}
		if (packSync.Failed > 0)
		{
			_homeStatus.Report(string.Format("{0} pack mods are in use and were left where they are.", packSync.Failed));
		}
	}

	private void ReportConflicts(IReadOnlyList<ModConflict> conflicts)
	{
		foreach (ModConflict conflict in conflicts)
		{
			_homeStatus.Report(string.Format("{0} was turned off for this launch: it crashes the game together with {1}.", conflict.Disabled, conflict.Kept));
		}
	}

	private async void OnLaunch(object sender, RoutedEventArgs e)
	{
		if ((object)_evoUser == null || _microsoftBusy)
		{
			return;
		}
		SetLaunchBusy(busy: true);
		LaunchProgress.Visibility = Visibility.Visible;
		LaunchProgress.Value = 0.0;
		_launching = true;
		Stopwatch elapsed = Stopwatch.StartNew();
		string stage = "instance";
		string java = "unknown";
		GlSupport graphics = null;
		bool softwareRenderer = false;
		ModDelivery delivery = new ModDelivery(Ready: false, PayloadAccess.Unverified);
		try
		{
			GameProcessState gameProcessState = await Task.Run(() => RunningGame.Reconcile(_paths));
			if (gameProcessState.Blocked)
			{
				throw new InvalidOperationException("Minecraft is already running — close it before launching again.");
			}
			if (gameProcessState.Released > 0)
			{
				_homeStatus.Report(string.Format("Closed {0} stuck Minecraft process(es) from the last session.", gameProcessState.Released));
			}
            _launching = false;
            ProvisionResult result = await new InstanceProvisioner(_paths, _downloader)
                .ProvisionAsync(false, _homeStatus, _percent, CancellationToken.None);
            string javaExecutable = _paths.JavaExecutable;
            if (!File.Exists(javaExecutable))
                throw new InvalidOperationException("Local Java runtime is missing. Install it manually.");
            _homeStatus.Report("Starting installed Minecraft...");
            GameLauncher launcher = new GameLauncher(_paths);
            MinecraftSession minecraftSession = await ResolveMinecraftSessionAsync();
            Process game = launcher.Launch(javaExecutable, result.Classpath, result.AssetIndexId,
                minecraftSession, null, null, false);
			_game = game;
			DateTime gameStartedUtc = DateTime.UtcNow;
			string gameModVersion = ModVersion.Text;
			game.EnableRaisingEvents = true;
			game.Exited += delegate
			{
				game.WaitForExit();
				int exitCode = game.ExitCode;
				bool blocked2 = RuntimeBlock.IsLoaderFailure(exitCode);
				if (!blocked2)
				{
					CrashReporter.ReportGameExit(_paths.Minecraft, exitCode, gameStartedUtc, gameModVersion);
				}
				base.Dispatcher.Invoke(delegate
				{
					SetLaunchBusy(busy: false);
					LaunchProgress.Visibility = Visibility.Collapsed;
					RestoreFromGame();
					if (blocked2)
					{
						ShowRuntimeBlocked(new RuntimeBlockedException(_paths.Runtime));
					}
					else
					{
						_homeStatus.Report((exitCode == 0) ? "Minecraft closed." : string.Format(CultureInfo.CurrentCulture, "Minecraft closed unexpectedly (exit code {0}). No crash report is sent.", exitCode));
					}
				});
			};
			_homeStatus.Report("Minecraft is running.");
			LaunchReporter.Report(_evoUser, BuildTelemetry("start", minecraftSession.Name, java, graphics, softwareRenderer, delivery, elapsed.ElapsedMilliseconds, stage, null));
			base.WindowState = WindowState.Minimized;
		}
		catch (Exception ex)
		{
			_launching = false;
			_homeStatus.Report("Launch failed: " + ex.Message);
			LaunchReporter.Report(_evoUser, BuildTelemetry("failed", "user", java, graphics, softwareRenderer, delivery, elapsed.ElapsedMilliseconds, stage, ex.Message));
			SetLaunchBusy(busy: false);
			LaunchProgress.Visibility = Visibility.Collapsed;
			if (ex is RuntimeBlockedException blocked)
			{
				ShowRuntimeBlocked(blocked);
			}
			if (ex is PayloadAccessDeniedException { Access: PayloadAccess.SignInRequired } ex2)
			{
				SignOut(ex2.Message);
				return;
			}
			await RefreshInstalledAsync(showOnModsPage: false);
		}
	}

	private void ShowRuntimeBlocked(RuntimeBlockedException blocked)
	{
		_homeStatus.Report("Launch failed: " + blocked.Message);
		MessageBox.Show(this, blocked.Message, "Java was blocked", MessageBoxButton.OK, MessageBoxImage.Exclamation);
	}

	private void RestoreFromGame()
	{
		if (base.WindowState == WindowState.Minimized)
		{
			base.WindowState = WindowState.Normal;
		}
		base.Topmost = true;
		base.Topmost = false;
		Activate();
	}

	[DllImport("dwmapi.dll")]
	private static extern int DwmSetWindowAttribute(nint window, int attribute, ref int value, int size);

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "9.0.19.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/ShadeVisLauncher;component/mainwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "9.0.19.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 1:
			Greeting = (TextBlock)target;
			break;
		case 2:
			Clock = (TextBlock)target;
			break;
		case 3:
			((Button)target).Click += OnMinimize;
			break;
		case 4:
			((Button)target).Click += OnClose;
			break;
		case 5:
			LoginRoot = (Grid)target;
			break;
		case 6:
			HwidText = (TextBlock)target;
			break;
		case 7:
			LoginField = (TextBox)target;
			LoginField.KeyDown += OnCredentialsKeyDown;
			break;
		case 8:
			PasswordField = (PasswordBox)target;
			PasswordField.KeyDown += OnCredentialsKeyDown;
			break;
		case 9:
			PasswordSignInButton = (Button)target;
			PasswordSignInButton.Click += OnRegister;
			break;
		case 10:
			EvoButton = (Button)target;
			EvoButton.Click += OnEvoSignIn;
			break;
		case 11:
			LoginStatus = (TextBlock)target;
			break;
		case 12:
			SignInPanel = (Border)target;
			break;
		case 13:
			SignInPanelStatus = (TextBlock)target;
			break;
		case 14:
			((Button)target).Click += OnSignInCancel;
			break;
		case 15:
			SignInView = (WebView2)target;
			break;
		case 16:
			ShellRoot = (Grid)target;
			break;
		case 17:
			NavHome = (RadioButton)target;
			NavHome.Checked += OnNavigate;
			break;
		case 18:
			NavCosmetics = (RadioButton)target;
			NavCosmetics.Checked += OnNavigate;
			break;
		case 19:
			NavSkins = (RadioButton)target;
			NavSkins.Checked += OnNavigate;
			break;
		case 20:
			NavMods = (RadioButton)target;
			NavMods.Checked += OnNavigate;
			break;
		case 21:
			NavPacks = (RadioButton)target;
			NavPacks.Checked += OnNavigate;
			break;
		case 22:
			NavSettings = (RadioButton)target;
			NavSettings.Checked += OnNavigate;
			break;
		case 23:
			SidePlayButton = (Button)target;
			SidePlayButton.Click += OnLaunch;
			break;
		case 24:
			((Button)target).Click += OnOpenMods;
			break;
		case 25:
			SessionDot = (Ellipse)target;
			break;
		case 26:
			SessionState = (TextBlock)target;
			break;
		case 27:
			SidebarBuild = (TextBlock)target;
			break;
		case 28:
			SidebarMods = (TextBlock)target;
			break;
		case 29:
			SidebarPack = (TextBlock)target;
			break;
		case 30:
			AvatarInitial = (TextBlock)target;
			break;
		case 31:
			AvatarEllipse = (Ellipse)target;
			break;
		case 32:
			AvatarBrush = (ImageBrush)target;
			break;
		case 33:
			UserName = (TextBlock)target;
			break;
		case 34:
			UserRole = (TextBlock)target;
			break;
		case 35:
			HomePage = (Grid)target;
			break;
		case 36:
			HeroClip = (Grid)target;
			HeroClip.SizeChanged += OnHeroResized;
			break;
		case 37:
			BgVideo = (MediaElement)target;
			break;
		case 38:
			LaunchButton = (Button)target;
			LaunchButton.Click += OnLaunch;
			break;
		case 39:
			McVersion = (TextBlock)target;
			break;
		case 40:
			ModVersion = (TextBlock)target;
			break;
		case 41:
			((Button)target).Click += OnOpenMods;
			break;
		case 42:
			HomeStatus = (TextBlock)target;
			break;
		case 43:
			LaunchProgress = (ProgressBar)target;
			break;
		case 44:
			PlayerName = (TextBlock)target;
			break;
		case 45:
			HeroPack = (TextBlock)target;
			break;
		case 46:
			StatMods = (TextBlock)target;
			break;
		case 47:
			StatMemory = (TextBlock)target;
			break;
		case 48:
			StatJava = (TextBlock)target;
			break;
		case 49:
			StatShaders = (TextBlock)target;
			break;
		case 50:
			InstanceModsNote = (TextBlock)target;
			break;
		case 51:
			ManagedList = (ItemsControl)target;
			break;
		case 52:
			ManagedEmpty = (TextBlock)target;
			break;
		case 53:
			((Button)target).Click += OnBrowseMods;
			break;
		case 54:
			ModsButton = (Button)target;
			ModsButton.Click += OnOpenMods;
			break;
		case 55:
			AccountName = (TextBlock)target;
			break;
		case 56:
			AccountRole = (TextBlock)target;
			break;
		case 57:
			AccountDevice = (TextBlock)target;
			break;
		case 58:
			((Button)target).Click += OnSignOut;
			break;
		case 59:
			CosmeticsPage = (Grid)target;
			break;
		case 60:
			CharacterName = (TextBlock)target;
			break;
		case 61:
			CharacterWornCount = (TextBlock)target;
			break;
		case 62:
			CharacterView = (WebView2)target;
			break;
		case 63:
			ViewerFallback = (TextBlock)target;
			break;
		case 64:
			EquippedList = (ItemsControl)target;
			break;
		case 66:
			EquippedEmpty = (TextBlock)target;
			break;
		case 67:
			ResetCosmeticsButton = (Button)target;
			ResetCosmeticsButton.Click += OnResetCosmetics;
			break;
		case 68:
			CosmeticsStatus = (TextBlock)target;
			break;
		case 69:
			CosmeticsSearchHint = (TextBlock)target;
			break;
		case 70:
			CosmeticsSearch = (TextBox)target;
			CosmeticsSearch.TextChanged += OnCosmeticsSearchChanged;
			break;
		case 71:
			CosmeticTabs = (ItemsControl)target;
			break;
		case 73:
			CosmeticsList = (ItemsControl)target;
			break;
		case 75:
			CosmeticsEmpty = (TextBlock)target;
			break;
		case 76:
			SkinsPage = (Grid)target;
			break;
		case 77:
			SkinSearchHint = (TextBlock)target;
			break;
		case 78:
			SkinSearch = (TextBox)target;
			SkinSearch.KeyDown += OnSkinSearchKey;
			SkinSearch.TextChanged += OnSkinSearchChanged;
			break;
		case 79:
			SkinsTrending = (RadioButton)target;
			SkinsTrending.Checked += OnSkinSourceChanged;
			break;
		case 80:
			SkinsWeekly = (RadioButton)target;
			SkinsWeekly.Checked += OnSkinSourceChanged;
			break;
		case 81:
			SkinsNew = (RadioButton)target;
			SkinsNew.Checked += OnSkinSourceChanged;
			break;
		case 82:
			SkinsRandom = (RadioButton)target;
			SkinsRandom.Checked += OnSkinSourceChanged;
			break;
		case 83:
			SkinsLibrary = (RadioButton)target;
			SkinsLibrary.Checked += OnSkinSourceChanged;
			break;
		case 84:
			SkinsStatus = (TextBlock)target;
			break;
		case 85:
			SkinsList = (ItemsControl)target;
			break;
		case 89:
			SkinsEmpty = (TextBlock)target;
			break;
		case 90:
			SkinsMoreButton = (Button)target;
			SkinsMoreButton.Click += OnSkinsLoadMore;
			break;
		case 91:
			ModsPage = (Grid)target;
			break;
		case 92:
			ModsSubtitle = (TextBlock)target;
			break;
		case 93:
			SearchPlaceholder = (TextBlock)target;
			break;
		case 94:
			SearchBox = (TextBox)target;
			SearchBox.TextChanged += OnSearchChanged;
			break;
		case 95:
			TabBrowse = (RadioButton)target;
			TabBrowse.Checked += OnModsTabChanged;
			break;
		case 96:
			TabInstalled = (RadioButton)target;
			TabInstalled.Checked += OnModsTabChanged;
			break;
		case 97:
			SortRow = (StackPanel)target;
			break;
		case 98:
			SortPopular = (RadioButton)target;
			SortPopular.Checked += OnSortChanged;
			break;
		case 99:
			SortRelevant = (RadioButton)target;
			SortRelevant.Checked += OnSortChanged;
			break;
		case 100:
			SortUpdated = (RadioButton)target;
			SortUpdated.Checked += OnSortChanged;
			break;
		case 101:
			ModsStatus = (TextBlock)target;
			break;
		case 102:
			ModsScroll = (ScrollViewer)target;
			break;
		case 103:
			ModsList = (ItemsControl)target;
			break;
		case 105:
			ModsEmpty = (TextBlock)target;
			break;
		case 106:
			LoadMoreButton = (Button)target;
			LoadMoreButton.Click += OnLoadMore;
			break;
		case 107:
			PacksPage = (Grid)target;
			break;
		case 108:
			PacksSubtitle = (TextBlock)target;
			break;
		case 109:
			PacksStatus = (TextBlock)target;
			break;
		case 110:
			PacksList = (ItemsControl)target;
			break;
		case 112:
			NewPackHint = (TextBlock)target;
			break;
		case 113:
			NewPackName = (TextBox)target;
			NewPackName.TextChanged += OnNewPackNameChanged;
			NewPackName.KeyDown += OnNewPackKeyDown;
			break;
		case 114:
			CreatePackButton = (Button)target;
			CreatePackButton.Click += OnCreatePack;
			break;
		case 115:
			ImportPackButton = (Button)target;
			ImportPackButton.Click += OnImportPack;
			break;
		case 116:
			PackNameBox = (TextBox)target;
			PackNameBox.LostFocus += OnPackNameCommitted;
			PackNameBox.KeyDown += OnPackNameKeyDown;
			break;
		case 117:
			PackSummary = (TextBlock)target;
			break;
		case 118:
			PlayPackButton = (Button)target;
			PlayPackButton.Click += OnLaunchPack;
			break;
		case 119:
			ExportPackButton = (Button)target;
			ExportPackButton.Click += OnExportPack;
			break;
		case 120:
			DuplicatePackButton = (Button)target;
			DuplicatePackButton.Click += OnDuplicatePack;
			break;
		case 121:
			DeletePackButton = (Button)target;
			DeletePackButton.Click += OnDeletePack;
			break;
		case 122:
			PackModsList = (ItemsControl)target;
			break;
		case 124:
			PackModsEmpty = (TextBlock)target;
			break;
		case 125:
			SettingsPage = (Grid)target;
			break;
		case 126:
			MemoryValue = (TextBlock)target;
			break;
		case 127:
			MemorySlider = (Slider)target;
			MemorySlider.ValueChanged += OnMemoryChanged;
			break;
		case 128:
			InstanceFolder = (TextBlock)target;
			break;
		case 129:
			((Button)target).Click += OnOpenInstance;
			break;
		case 130:
			((Button)target).Click += OnOpenMods;
			break;
		case 131:
			MoveInstanceButton = (Button)target;
			MoveInstanceButton.Click += OnChangeInstallLocation;
			break;
		case 132:
			DefaultInstanceButton = (Button)target;
			DefaultInstanceButton.Click += OnDefaultInstallLocation;
			break;
		case 133:
			MoveInstanceProgress = (ProgressBar)target;
			break;
		case 134:
			MoveInstanceStatus = (TextBlock)target;
			break;
		case 135:
			LauncherVersion = (TextBlock)target;
			break;
		case 136:
			UpdateStatus = (TextBlock)target;
			break;
		case 137:
			UpdateButton = (Button)target;
			UpdateButton.Click += OnCheckUpdates;
			break;
		case 138:
			MinecraftAccountStatus = (TextBlock)target;
			break;
		case 139:
			MinecraftAccountButton = (Button)target;
			MinecraftAccountButton.Click += OnMinecraftAccount;
			break;
		case 140:
			SettingsDevice = (TextBlock)target;
			break;
		case 141:
			((Button)target).Click += OnCopyDevice;
			break;
		case 142:
			((Button)target).Click += OnSignOut;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "9.0.19.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IStyleConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 65:
			((Button)target).Click += OnUnequipSlot;
			break;
		case 72:
			((RadioButton)target).Checked += OnCosmeticTabChanged;
			break;
		case 74:
			((Button)target).Click += OnCosmeticClick;
			((Button)target).MouseEnter += OnCosmeticHover;
			((Button)target).MouseLeave += OnCosmeticUnhover;
			break;
		case 86:
			((Border)target).MouseEnter += OnSkinHover;
			((Border)target).MouseLeave += OnSkinUnhover;
			break;
		case 87:
			((Button)target).Click += OnSkinApply;
			break;
		case 88:
			((Button)target).Click += OnSkinRemove;
			break;
		case 104:
			((Button)target).Click += OnModAction;
			break;
		case 111:
			((Button)target).Click += OnSelectPack;
			break;
		case 123:
			((CheckBox)target).Click += OnPackModToggled;
			break;
		}
	}
}
