using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using ShadeVisLauncher.Auth;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher.Instance;

public sealed class GameLauncher
{
    [CompilerGenerated]
    private InstancePaths _003Cpaths_003EP;

    private const string KnotClient = "net.fabricmc.loader.impl.launch.knot.KnotClient";

    private const string AgentPayloadVariable = "SHADE_AGENT_PAYLOAD";

    private const string TokenVariable = "SHADE_TOKEN";

    private const string HwidVariable = "SHADE_HWID";

    private const string KeyRouteVariable = "SHADE_KEY_ROUTE";

    private const string MaxHeapFormat = "-Xmx{0}G";

    private const int MinimumHeapGigabytes = 2;

    private const int MaximumHeapGigabytes = 6;

    private const int HeapShareDivisor = 2;

    private const int SystemReserveGigabytes = 2;

    private static readonly string[] HardeningFlags = new string[1] { "-XX:+DisableAttachMechanism" };

    private static readonly string[] InjectedOptionVariables = new string[5]
    {
        "JAVA_TOOL_OPTIONS",
        "_JAVA_OPTIONS",
        "JDK_JAVA_OPTIONS",
        "JAVA_OPTIONS",
        "CLASSPATH"
    };

    private const string OfflinePrefix = "OfflinePlayer:";

    private const string GalliumDriverVariable = "GALLIUM_DRIVER";

    private const string GalliumSoftwareDriver = "llvmpipe";

    private const string ForceSoftwareVariable = "LIBGL_ALWAYS_SOFTWARE";

    private const string ForceSoftwareValue = "1";

    public GameLauncher(InstancePaths paths)
    {
        _003Cpaths_003EP = paths;
    }

    public static MinecraftSession OfflineSession(string name)
    {
        return new MinecraftSession(OfflineUuid(name), name, "0");
    }

    public bool WillAttachAgent(string? evoToken) => false;

    public Process Launch(string javaExecutable, string classpath, string assetIndexId, MinecraftSession session, string? evoToken, string? hwid, bool softwareRenderer)
    {
        List<string> list = new List<string> { MaxHeap() };
        list.AddRange(HardeningFlags);
        list.Add("-Djava.library.path=" + _003Cpaths_003EP.Natives);

        list.AddRange(new string[21]
        {
            "-cp",
            classpath,
            "net.fabricmc.loader.impl.launch.knot.KnotClient",
            "--username",
            session.Name,
            "--version",
            "1.21.11",
            "--gameDir",
            _003Cpaths_003EP.Minecraft,
            "--assetsDir",
            Path.Combine(_003Cpaths_003EP.Minecraft, "assets"),
            "--assetIndex",
            assetIndexId,
            "--uuid",
            session.Uuid,
            "--accessToken",
            session.AccessToken,
            "--userType",
            "msa",
            "--versionType",
            "release"
        });
        ProcessStartInfo processStartInfo = new ProcessStartInfo(javaExecutable)
        {
            UseShellExecute = false,
            WorkingDirectory = _003Cpaths_003EP.Minecraft
        };
        string[] injectedOptionVariables = InjectedOptionVariables;
        foreach (string key in injectedOptionVariables)
        {
            processStartInfo.Environment.Remove(key);
        }
        GameOutputLog.Prepare(processStartInfo);
        foreach (string key in new[] { "SHADE_AGENT_PAYLOAD", "SHADE_TOKEN", "SHADE_HWID", "SHADE_KEY_ROUTE" })
            processStartInfo.Environment.Remove(key);
        string? deviceId = hwid ?? HardwareId.Value;
        if (!string.IsNullOrEmpty(deviceId))
            processStartInfo.Environment["SHADE_HWID"] = deviceId;
        processStartInfo.Environment["SHADE_ROLE"] = SessionRole.Current;
        processStartInfo.Environment["SHADE_COSMETICS"] = SessionCosmetics.Current;
        if (softwareRenderer)
        {
            processStartInfo.Environment["GALLIUM_DRIVER"] = "llvmpipe";
            processStartInfo.Environment["LIBGL_ALWAYS_SOFTWARE"] = "1";
        }
        foreach (string item in list)
        {
            processStartInfo.ArgumentList.Add(item);
        }
        Process? obj = Process.Start(processStartInfo) ?? throw new InvalidOperationException("failed to start the game process");
        GameOutputLog.Capture(obj, _003Cpaths_003EP.Minecraft);
        return obj;
    }

    public static int AutomaticHeapGigabytes()
    {
        int physicalMemoryGigabytes = MachineProfile.PhysicalMemoryGigabytes;
        if (physicalMemoryGigabytes > 0)
        {
            return Math.Clamp(physicalMemoryGigabytes / 2, 2, 6);
        }
        return 2;
    }

    public static int AllowedHeapGigabytes()
    {
        int physicalMemoryGigabytes = MachineProfile.PhysicalMemoryGigabytes;
        if (physicalMemoryGigabytes > 0)
        {
            return Math.Clamp(physicalMemoryGigabytes - 2, 2, 16);
        }
        return 16;
    }

    public static int ConfiguredHeapGigabytes()
    {
        int heapGigabytes = LauncherSettings.Current.HeapGigabytes;
        if (heapGigabytes != 0)
        {
            return Math.Min(heapGigabytes, AllowedHeapGigabytes());
        }
        return AutomaticHeapGigabytes();
    }

    private static string MaxHeap()
    {
        int num = ConfiguredHeapGigabytes();
        return string.Format(CultureInfo.InvariantCulture, "-Xmx{0}G", num);
    }

    private static string OfflineUuid(string name)
    {
        byte[] array = MD5.HashData(Encoding.UTF8.GetBytes("OfflinePlayer:" + name));
        array[6] = (byte)((array[6] & 0xFu) | 0x30u);
        array[8] = (byte)((array[8] & 0x3Fu) | 0x80u);
        string text = Convert.ToHexStringLower(array);
        DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(4, 5);
        defaultInterpolatedStringHandler.AppendFormatted(text.Substring(0, 8));
        defaultInterpolatedStringHandler.AppendLiteral("-");
        defaultInterpolatedStringHandler.AppendFormatted(text.Substring(8, 4));
        defaultInterpolatedStringHandler.AppendLiteral("-");
        defaultInterpolatedStringHandler.AppendFormatted(text.Substring(12, 4));
        defaultInterpolatedStringHandler.AppendLiteral("-");
        defaultInterpolatedStringHandler.AppendFormatted(text.Substring(16, 4));
        defaultInterpolatedStringHandler.AppendLiteral("-");
        string text2 = text;
        defaultInterpolatedStringHandler.AppendFormatted(text2.Substring(20, text2.Length - 20));
        return defaultInterpolatedStringHandler.ToStringAndClear();
    }
}