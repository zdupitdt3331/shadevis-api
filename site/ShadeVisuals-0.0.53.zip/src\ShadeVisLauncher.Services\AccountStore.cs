using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace ShadeVisLauncher.Services;

public sealed class AccountRecord
{
	public string Nick { get; set; } = string.Empty;

	public string Salt { get; set; } = string.Empty;

	public string Hash { get; set; } = string.Empty;

	public string Role { get; set; } = string.Empty;

	public int Uid { get; set; }

	public string CreatedUtc { get; set; } = string.Empty;
}

/// <summary>Локальные аккаунты лаунчера: регистрация по нику и паролю, вход по паролю.</summary>
public static class AccountStore
{
	public const int MinNickLength = 3;

	public const int MaxNickLength = 16;

	public const int MinPasswordLength = 6;

	private const int Iterations = 120000;

	private const int HashBytes = 32;

	private static readonly object Gate = new object();

	private static readonly JsonSerializerOptions Format = new JsonSerializerOptions
	{
		WriteIndented = true
	};

	internal static string? RootOverride;

	public static string FolderPath => RootOverride ?? System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ShadeVis");

	public static string FilePath => System.IO.Path.Combine(FolderPath, "accounts.json");

	public static string LastNickPath => System.IO.Path.Combine(FolderPath, "last-user.txt");

	public static string? LastNick
	{
		get
		{
			try
			{
				return File.Exists(LastNickPath) ? File.ReadAllText(LastNickPath).Trim() : null;
			}
			catch (Exception ex) when (IsAccessError(ex))
			{
				return null;
			}
		}
	}

	public static bool Validate(string nick, string password, out string error)
	{
		error = string.Empty;
		if (string.IsNullOrWhiteSpace(nick))
		{
			error = "Enter a nickname.";
			return false;
		}
		if (nick.Length < MinNickLength || nick.Length > MaxNickLength)
		{
			error = "The nickname must be " + MinNickLength + "-" + MaxNickLength + " characters long.";
			return false;
		}
		foreach (char c in nick)
		{
			bool allowed = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_';
			if (!allowed)
			{
				error = "The nickname may contain Latin letters, digits and underscore only.";
				return false;
			}
		}
		if (password.Length < MinPasswordLength)
		{
			error = "The password must be at least " + MinPasswordLength + " characters long.";
			return false;
		}
		return true;
	}

	public static bool Register(string nick, string password, out ShadeVisUser? user, out string error)
	{
		user = null;
		error = string.Empty;
		if (!Validate(nick, password, out error))
		{
			return false;
		}
		lock (Gate)
		{
			List<AccountRecord> accounts = Read();
			AccountRecord? existing = accounts.FirstOrDefault(a => string.Equals(a.Nick, nick, StringComparison.OrdinalIgnoreCase));
			if (existing != null)
			{
				error = "An account with this nickname already exists. Sign in instead.";
				return false;
			}
			byte[] salt = RandomNumberGenerator.GetBytes(16);
			AccountRecord record = new AccountRecord
			{
				Nick = nick,
				Salt = Convert.ToBase64String(salt),
				Hash = Convert.ToBase64String(Derive(password, salt)),
				Role = RoleCatalog.Resolve(nick),
				Uid = accounts.Count == 0 ? 1 : accounts.Max(a => a.Uid) + 1,
				CreatedUtc = DateTime.UtcNow.ToString("o")
			};
			accounts.Add(record);
			if (!Write(accounts, out error))
			{
				return false;
			}
			Remember(record.Nick);
			user = ToUser(record);
			return true;
		}
	}

	public static bool Login(string nick, string password, out ShadeVisUser? user, out string error)
	{
		user = null;
		error = string.Empty;
		if (!Validate(nick, password, out error))
		{
			return false;
		}
		lock (Gate)
		{
			AccountRecord? record = Read().FirstOrDefault(a => string.Equals(a.Nick, nick, StringComparison.OrdinalIgnoreCase));
			if (record == null)
			{
				error = "No account with this nickname. Create one first.";
				return false;
			}
			byte[] salt;
			byte[] expected;
			try
			{
				salt = Convert.FromBase64String(record.Salt);
				expected = Convert.FromBase64String(record.Hash);
			}
			catch (FormatException)
			{
				error = "The account file is damaged. Create the account again.";
				return false;
			}
			if (!CryptographicOperations.FixedTimeEquals(Derive(password, salt), expected))
			{
				error = "Wrong password.";
				return false;
			}
			Remember(record.Nick);
			user = ToUser(record);
			return true;
		}
	}

	public static bool Exists(string nick)
	{
		lock (Gate)
		{
			return Read().Any(a => string.Equals(a.Nick, nick, StringComparison.OrdinalIgnoreCase));
		}
	}

	private static ShadeVisUser ToUser(AccountRecord record)
	{
		return new ShadeVisUser(record.Nick, RandomNumberGenerator.GetHexString(32, lowercase: true), RoleCatalog.Resolve(record.Nick), record.Uid, null);
	}

	private static byte[] Derive(string password, byte[] salt)
	{
		return Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(password), salt, Iterations, HashAlgorithmName.SHA256, HashBytes);
	}

	private static void Remember(string nick)
	{
		try
		{
			Directory.CreateDirectory(FolderPath);
			File.WriteAllText(LastNickPath, nick);
		}
		catch (Exception ex) when (IsAccessError(ex))
		{
		}
	}

	private static List<AccountRecord> Read()
	{
		try
		{
			if (!File.Exists(FilePath))
			{
				return new List<AccountRecord>();
			}
			return JsonSerializer.Deserialize<List<AccountRecord>>(File.ReadAllText(FilePath)) ?? new List<AccountRecord>();
		}
		catch (Exception ex) when (IsAccessError(ex) || ex is JsonException)
		{
			return new List<AccountRecord>();
		}
	}

	private static bool Write(List<AccountRecord> accounts, out string error)
	{
		error = string.Empty;
		try
		{
			Directory.CreateDirectory(FolderPath);
			File.WriteAllText(FilePath, JsonSerializer.Serialize(accounts, Format));
			return true;
		}
		catch (Exception ex) when (IsAccessError(ex))
		{
			error = "Could not save the account: " + ex.Message;
			return false;
		}
	}

	private static bool IsAccessError(Exception error)
	{
		return error is IOException || error is UnauthorizedAccessException || error is System.Security.SecurityException;
	}
}
