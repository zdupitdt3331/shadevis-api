using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
namespace ShadeVisLauncher.Services;

public sealed class PayloadKeyClient
{
	private static readonly string Endpoint = "https://shadevis-protect.vercel.app/api/payload-key";

	private const string ErrorProperty = "error";

	private const string DeviceUnboundError = "hwid";

	private const string RevokedError = "revoked";

	private static readonly HttpClient Http = LauncherHttp.Create(TimeSpan.FromSeconds(20L));

	public async Task<PayloadAccess> CheckAccessAsync(string token, string hwid, string payloadSha256, CancellationToken cancel)
	{
		using HttpResponseMessage response = await Http.PostAsJsonAsync(Endpoint, new
		{
			token = token,
			hwid = hwid,
			payload = payloadSha256
		}, cancel);
		NetworkRetry.ThrowIfTransient(response);
		if (response.IsSuccessStatusCode)
		{
			return PayloadAccess.Granted;
		}
		if (response.StatusCode == HttpStatusCode.Unauthorized)
		{
			return PayloadAccess.SignInRequired;
		}
		if (response.StatusCode != HttpStatusCode.Forbidden)
		{
			return PayloadAccess.Denied;
		}
		string text = await ErrorCodeAsync(response, cancel);
		return (text == "hwid") ? PayloadAccess.SignInRequired : ((!(text == "revoked")) ? PayloadAccess.Denied : PayloadAccess.Revoked);
	}

	public static string Sha256Hex(string filePath)
	{
		using FileStream source = File.OpenRead(filePath);
		return Convert.ToHexStringLower(SHA256.HashData(source));
	}

	private static async Task<string?> ErrorCodeAsync(HttpResponseMessage response, CancellationToken cancel)
	{
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancel));
			JsonElement value;
			return (jsonDocument.RootElement.ValueKind == JsonValueKind.Object && jsonDocument.RootElement.TryGetProperty("error", out value) && value.ValueKind == JsonValueKind.String) ? value.GetString() : null;
		}
		catch (JsonException)
		{
			return null;
		}
	}
}
