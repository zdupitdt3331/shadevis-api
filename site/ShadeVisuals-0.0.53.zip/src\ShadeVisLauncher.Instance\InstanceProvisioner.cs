using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ShadeVisLauncher.Services;
namespace ShadeVisLauncher.Instance;

/// <summary>Reads an existing installation and never downloads or decrypts files.</summary>
public sealed class InstanceProvisioner
{
    public const string MinecraftVersion = "1.21.11";
    public const string LoaderVersion = "0.19.5";
    private readonly InstancePaths paths;
    public InstanceProvisioner(InstancePaths paths, HttpDownloader downloader) { this.paths = paths; }
    public Task<ProvisionResult> ProvisionAsync(bool includeAssets, IProgress<string> status, IProgress<double> percent, CancellationToken cancel)
    {
        cancel.ThrowIfCancellationRequested();
        string client = Path.Combine(paths.Minecraft, MinecraftVersion + ".jar");
        string libraries = Path.Combine(paths.Minecraft, "libraries");
        string indexes = Path.Combine(paths.Minecraft, "assets", "indexes");
        if (!File.Exists(client) || !Directory.Exists(libraries) || !Directory.Exists(paths.Fabric) || !Directory.Exists(indexes))
            throw new InvalidOperationException("Local installation is incomplete. Install Minecraft, Fabric, libraries and assets manually.");
        string[] fabric = Directory.GetFiles(paths.Fabric, "*.jar", SearchOption.AllDirectories);
        if (!fabric.Any(file => Path.GetFileName(file).StartsWith("fabric-loader-", StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("Local Fabric loader is missing.");
        string? index = Directory.GetFiles(indexes, "*.json").OrderByDescending(File.GetLastWriteTimeUtc).FirstOrDefault();
        if (index == null) throw new InvalidOperationException("Local asset index is missing.");
        string[] classpath = fabric.Concat(Directory.GetFiles(libraries, "*.jar", SearchOption.AllDirectories))
            .Append(client).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        status.Report("Using installed files. Downloads disabled.");
        percent.Report(1);
        return Task.FromResult(new ProvisionResult(string.Join(Path.PathSeparator, classpath),
            "net.fabricmc.loader.impl.launch.knot.KnotClient", Path.GetFileNameWithoutExtension(index)));
    }
}

