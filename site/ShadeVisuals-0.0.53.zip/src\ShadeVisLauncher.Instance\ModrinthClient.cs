using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher.Instance;

public sealed class ModrinthClient
{
    [CompilerGenerated]
    private sealed class _003CRequiredDependencies_003Ed__20 : IEnumerable<ModrinthDependency>, IEnumerable, IEnumerator<ModrinthDependency>, IEnumerator, IDisposable
    {
        private int _003C_003E1__state;

        private ModrinthDependency _003C_003E2__current;

        private int _003C_003El__initialThreadId;

        private JsonElement version;

        public JsonElement _003C_003E3__version;

        private JsonElement.ArrayEnumerator _003C_003E7__wrap1;

        ModrinthDependency IEnumerator<ModrinthDependency>.Current
        {
            [DebuggerHidden]
            get
            {
                return _003C_003E2__current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return _003C_003E2__current;
            }
        }

        [DebuggerHidden]
        public _003CRequiredDependencies_003Ed__20(int _003C_003E1__state)
        {
            this._003C_003E1__state = _003C_003E1__state;
            _003C_003El__initialThreadId = Environment.CurrentManagedThreadId;
        }

        [DebuggerHidden]
        void IDisposable.Dispose()
        {
            int num = _003C_003E1__state;
            if (num == -3 || num == 1)
            {
                try
                {
                }
                finally
                {
                    _003C_003Em__Finally1();
                }
            }
            _003C_003E7__wrap1 = default(JsonElement.ArrayEnumerator);
            _003C_003E1__state = -2;
        }

        private bool MoveNext()
        {
            try
            {
                switch (_003C_003E1__state)
                {
                default:
                    return false;
                case 0:
                {
                    _003C_003E1__state = -1;
                    if (!version.TryGetProperty("dependencies", out var value))
                    {
                        return false;
                    }
                    _003C_003E7__wrap1 = value.EnumerateArray().GetEnumerator();
                    _003C_003E1__state = -3;
                    break;
                }
                case 1:
                    _003C_003E1__state = -3;
                    break;
                }
                while (_003C_003E7__wrap1.MoveNext())
                {
                    JsonElement current = _003C_003E7__wrap1.Current;
                    if (!(Optional(current, "dependency_type") != "required"))
                    {
                        _003C_003E2__current = new ModrinthDependency(Optional(current, "project_id"), Optional(current, "version_id"));
                        _003C_003E1__state = 1;
                        return true;
                    }
                }
                _003C_003Em__Finally1();
                _003C_003E7__wrap1 = default(JsonElement.ArrayEnumerator);
                return false;
            }
            catch
            {
                //try-fault
                ((IDisposable)this).Dispose();
                throw;
            }
        }

        bool IEnumerator.MoveNext()
        {
            //ILSpy generated this explicit interface implementation from .override directive in MoveNext
            return this.MoveNext();
        }

        private void _003C_003Em__Finally1()
        {
            _003C_003E1__state = -1;
            ((IDisposable)_003C_003E7__wrap1).Dispose();
        }

        [DebuggerHidden]
        void IEnumerator.Reset()
        {
            throw new NotSupportedException();
        }

        [DebuggerHidden]
        IEnumerator<ModrinthDependency> IEnumerable<ModrinthDependency>.GetEnumerator()
        {
            _003CRequiredDependencies_003Ed__20 _003CRequiredDependencies_003Ed__;
            if (_003C_003E1__state == -2 && _003C_003El__initialThreadId == Environment.CurrentManagedThreadId)
            {
                _003C_003E1__state = 0;
                _003CRequiredDependencies_003Ed__ = this;
            }
            else
            {
                _003CRequiredDependencies_003Ed__ = new _003CRequiredDependencies_003Ed__20(0);
            }
            _003CRequiredDependencies_003Ed__.version = _003C_003E3__version;
            return _003CRequiredDependencies_003Ed__;
        }

        [DebuggerHidden]
        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IEnumerable<ModrinthDependency>)this).GetEnumerator();
        }
    }

    [CompilerGenerated]
    private HttpDownloader _003Cdownloader_003EP;

    public const string SortRelevance = "relevance";

    public const string SortDownloads = "downloads";

    public const string SortUpdated = "updated";

    private const string SearchUrl = "https://api.modrinth.com/v2/search?query={0}&facets={1}&index={2}&offset={3}&limit={4}";

    private const string ProjectVersionsUrl = "https://api.modrinth.com/v2/project/{0}/version?game_versions=%5B%22{1}%22%5D&loaders=%5B%22fabric%22%5D";

    private const string VersionUrl = "https://api.modrinth.com/v2/version/{0}";

    private const string ProjectUrl = "https://api.modrinth.com/v2/project/{0}";

    private const string SearchFacets = "[[\"project_type:mod\"],[\"categories:fabric\"],[\"versions:{0}\"]]";

    private const string ReleaseChannel = "release";

    private const string RequiredDependency = "required";

    private const int MaxCategories = 3;

    private const string CategorySeparator = " · ";

    public ModrinthClient(HttpDownloader downloader)
    {
        _003Cdownloader_003EP = downloader;
    }

    public async Task<ModrinthPage> SearchAsync(string query, string index, int offset, int limit, CancellationToken cancel)
    {
        string text = Uri.EscapeDataString(string.Format("[[\"project_type:mod\"],[\"categories:fabric\"],[\"versions:{0}\"]]", "1.21.11"));
        string format = "https://api.modrinth.com/v2/search?query={0}&facets={1}&index={2}&offset={3}&limit={4}";
        _003C_003Ey__InlineArray5<object> buffer = default(_003C_003Ey__InlineArray5<object>);
        global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray5<object>, object>(ref buffer, 0) = Uri.EscapeDataString(query);
        global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray5<object>, object>(ref buffer, 1) = text;
        global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray5<object>, object>(ref buffer, 2) = index;
        global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray5<object>, object>(ref buffer, 3) = offset;
        global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray5<object>, object>(ref buffer, 4) = limit;
        string url = string.Format(format, global::_003CPrivateImplementationDetails_003E.InlineArrayAsReadOnlySpan<_003C_003Ey__InlineArray5<object>, object>(in buffer, 5));
        using JsonDocument jsonDocument = JsonDocument.Parse(await _003Cdownloader_003EP.GetStringAsync(url, cancel));
        List<ModrinthHit> list = new List<ModrinthHit>(limit);
        foreach (JsonElement item in jsonDocument.RootElement.GetProperty("hits").EnumerateArray())
        {
            list.Add(new ModrinthHit(Text(item, "project_id"), Text(item, "slug"), Text(item, "title"), Text(item, "description"), Text(item, "author"), item.TryGetProperty("downloads", out var value) ? value.GetInt64() : 0, Optional(item, "icon_url"), Categories(item)));
        }
        return new ModrinthPage(list, jsonDocument.RootElement.GetProperty("total_hits").GetInt32());
    }

    public async Task<ModrinthProject> ProjectAsync(string idOrSlug, CancellationToken cancel)
    {
        string url = string.Format("https://api.modrinth.com/v2/project/{0}", idOrSlug);
        using JsonDocument jsonDocument = JsonDocument.Parse(await _003Cdownloader_003EP.GetStringAsync(url, cancel));
        JsonElement rootElement = jsonDocument.RootElement;
        return new ModrinthProject(Text(rootElement, "id"), Text(rootElement, "slug"), Text(rootElement, "title"), Optional(rootElement, "icon_url"));
    }

    public async Task<string> ProjectIdAsync(string slug, CancellationToken cancel)
    {
        return (await ProjectAsync(slug, cancel)).Id;
    }

    public async Task<JsonElement> LatestVersionAsync(string project, bool stableOnly, CancellationToken cancel)
    {
        string url = string.Format("https://api.modrinth.com/v2/project/{0}/version?game_versions=%5B%22{1}%22%5D&loaders=%5B%22fabric%22%5D", project, "1.21.11");
        using JsonDocument jsonDocument = JsonDocument.Parse(await _003Cdownloader_003EP.GetStringAsync(url, cancel));
        foreach (JsonElement item in jsonDocument.RootElement.EnumerateArray())
        {
            if (!stableOnly || !(item.GetProperty("version_type").GetString() != "release"))
            {
                return item.Clone();
            }
        }
        throw new InvalidOperationException("no " + project + " build for Minecraft 1.21.11");
    }

    public async Task<JsonElement> VersionAsync(string versionId, CancellationToken cancel)
    {
        string url = string.Format("https://api.modrinth.com/v2/version/{0}", versionId);
        using JsonDocument jsonDocument = JsonDocument.Parse(await _003Cdownloader_003EP.GetStringAsync(url, cancel));
        return jsonDocument.RootElement.Clone();
    }

    public static ModrinthFile PrimaryFile(JsonElement version)
    {
        foreach (JsonElement item in version.GetProperty("files").EnumerateArray())
        {
            if (!item.TryGetProperty("primary", out var value) || value.GetBoolean())
            {
                return new ModrinthFile(item.GetProperty("filename").GetString(), item.GetProperty("url").GetString(), item.GetProperty("hashes").GetProperty("sha1").GetString());
            }
        }
        throw new InvalidOperationException("the Modrinth version carries no primary file");
    }

    [IteratorStateMachine(typeof(_003CRequiredDependencies_003Ed__20))]
    public static IEnumerable<ModrinthDependency> RequiredDependencies(JsonElement version)
    {
        return new _003CRequiredDependencies_003Ed__20(-2)
        {
            _003C_003E3__version = version
        };
    }

    public static string VersionNumber(JsonElement version)
    {
        return Text(version, "version_number");
    }

    public static string VersionId(JsonElement version)
    {
        return Text(version, "id");
    }

    private static string Text(JsonElement element, string property)
    {
        return Optional(element, property) ?? string.Empty;
    }

    private static string? Optional(JsonElement element, string property)
    {
        if (!element.TryGetProperty(property, out var value) || value.ValueKind != JsonValueKind.String)
        {
            return null;
        }
        return value.GetString();
    }

    private static string Categories(JsonElement hit)
    {
        if (!hit.TryGetProperty("display_categories", out var value) || value.ValueKind != JsonValueKind.Array)
        {
            return string.Empty;
        }
        List<string> list = new List<string>(3);
        foreach (JsonElement item in value.EnumerateArray())
        {
            if (item.ValueKind == JsonValueKind.String)
            {
                list.Add(item.GetString());
                if (list.Count == 3)
                {
                    break;
                }
            }
        }
        return string.Join(" · ", list);
    }
}