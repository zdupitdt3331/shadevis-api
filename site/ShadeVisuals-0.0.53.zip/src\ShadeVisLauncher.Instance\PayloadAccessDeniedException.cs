using System;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher.Instance;

public sealed class PayloadAccessDeniedException : InvalidOperationException
{
	public PayloadAccess Access { get; }

	public PayloadAccessDeniedException(PayloadAccess access) : base(access switch
		{
			PayloadAccess.SignInRequired => "This device is linked to a different ShadeVis account or was unlinked. Please sign in again.", 
			PayloadAccess.Revoked => "Your ShadeVis access has been revoked. Contact support if you think this is a mistake.", 
			_ => "The ShadeVis server refused access to this build. Press Play again to download the latest version.", 
		})
	{
		Access = access;
		
	}
}
