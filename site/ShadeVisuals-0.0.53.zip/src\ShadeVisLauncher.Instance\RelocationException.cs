using System;

namespace ShadeVisLauncher.Instance;

public sealed class RelocationException : Exception
{
	public RelocationException(string message)
		: base(message)
	{
	}
}
