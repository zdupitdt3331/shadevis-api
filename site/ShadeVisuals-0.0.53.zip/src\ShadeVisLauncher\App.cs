using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using ShadeVisLauncher.Instance;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher;

public class App : Application
{
	private sealed class DelegateProgress : IProgress<string>
	{
		[CompilerGenerated]
		private Action<string> _003Caction_003EP;

		public DelegateProgress(Action<string> action)
		{
			_003Caction_003EP = action;
			
		}

		public void Report(string value)
		{
			_003Caction_003EP(value);
		}
	}

	private const string ProvisionFlag = "--provision";

	private const string AssetsFlag = "--assets";



	private bool _contentLoaded;


	protected override void OnStartup(StartupEventArgs e)
	{
		CrashReporter.Install(this);
		RoleCatalog.EnsureFile();
		HiddenMods.EnsureFile();
		if (TrySetRole(e.Args))
		{
			Shutdown(0);
			return;
		}
		if (Array.Exists(e.Args, (string argument) => argument == "--provision"))
		{
			RunProvision(Array.Exists(e.Args, (string argument) => argument == "--assets"));
			Shutdown(0);
			return;
		}
		if (!HwidGuard.Enforce(out string reason))
		{
			MessageBox.Show(reason, "ShadeVis", MessageBoxButton.OK, MessageBoxImage.Hand);
			Shutdown(1);
			return;
		}
		base.OnStartup(e);
	}

	private static bool TrySetRole(string[] args)
	{
		int index = Array.IndexOf(args, "--set-role");
		if (index < 0)
		{
			return false;
		}
		string nick = (index + 1 < args.Length) ? args[index + 1] : string.Empty;
		string role = (index + 2 < args.Length) ? args[index + 2] : string.Empty;
		if (nick.Length == 0 || role.Length == 0)
		{
			MessageBox.Show("Usage: shade_launcher.exe --set-role <nickname> <Admin|Media|User|none>", "ShadeVis", MessageBoxButton.OK, MessageBoxImage.Information);
			return true;
		}
		if (RoleCatalog.SetRole(nick, role, out string error))
		{
			string text = role.Trim().Equals("none", StringComparison.OrdinalIgnoreCase) ? ("Role override removed for " + nick + ".") : ("Role " + RoleCatalog.Resolve(nick) + " is now set for " + nick + ".");
			MessageBox.Show(text, "ShadeVis", MessageBoxButton.OK, MessageBoxImage.Information);
		}
		else
		{
			MessageBox.Show(error, "ShadeVis", MessageBoxButton.OK, MessageBoxImage.Warning);
		}
		return true;
	}

	private static void RunProvision(bool includeAssets)
    {
        Console.WriteLine("Provisioning and downloads are disabled in this build.");
    }

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "9.0.19.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			base.StartupUri = new Uri("MainWindow.xaml", UriKind.Relative);
			Uri resourceLocator = new Uri("/ShadeVisLauncher;component/app.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[STAThread]
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "9.0.19.0")]
	public static void Main()
	{
		App app = new App();
		app.InitializeComponent();
		app.Run();
	}
}
