using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
namespace ShadeVisLauncher.Services;

public sealed class ReleaseClient
{
	private static readonly string Endpoint = "https://shadevis-protect.vercel.app/api/release";

	private const string LatestTag = "latest";

	private static readonly HttpClient Http = LauncherHttp.Create(TimeSpan.FromSeconds(30L));

	public async Task<string?> ResolveAsync(string? token, string? hwid, string asset, string? tag, CancellationToken cancel)
	{
		try
		{
			return await ResolveOrThrowAsync(token, hwid, asset, tag, cancel);
		}
		catch (Exception)
		{
			return null;
		}
	}

	public async Task<string?> ResolveOrThrowAsync(string? token, string? hwid, string asset, string? tag, CancellationToken cancel)
	{
		if (string.IsNullOrEmpty(token) || string.IsNullOrEmpty(hwid))
		{
			return null;
		}
		using HttpResponseMessage response = await Http.PostAsJsonAsync(Endpoint, new
		{
			token = token,
			hwid = hwid,
			asset = asset,
			tag = (tag ?? "latest")
		}, cancel);
		NetworkRetry.ThrowIfTransient(response);
		if (!response.IsSuccessStatusCode)
		{
			return null;
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancel));
		JsonElement value;
		return (jsonDocument.RootElement.TryGetProperty("url", out value) && value.ValueKind == JsonValueKind.String) ? value.GetString() : null;
	}
}
