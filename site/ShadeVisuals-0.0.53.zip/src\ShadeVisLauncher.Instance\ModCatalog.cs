using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher.Instance;

public sealed class ModCatalog
{
	[CompilerGenerated]
	private InstancePaths _003Cpaths_003EP;

	[CompilerGenerated]
	private ModrinthClient _003Cmodrinth_003EP;

	[CompilerGenerated]
	private HttpDownloader _003Cdownloader_003EP;

	private const string ManualDetail = "Added manually";

	private const string DetailSeparator = " · ";

	private const string SizeFormat = "{0:0.#} MB";

	private const double BytesPerMegabyte = 1048576.0;

	private const string ProjectIdProperty = "project_id";

	private const string DownloadFormat = "Downloading {0}...";

	private static readonly JsonSerializerOptions CatalogFormat = new JsonSerializerOptions
	{
		WriteIndented = false
	};

	public ModCatalog(InstancePaths paths, ModrinthClient modrinth, HttpDownloader downloader)
	{
		_003Cpaths_003EP = paths;
		_003Cmodrinth_003EP = modrinth;
		_003Cdownloader_003EP = downloader;
		
	}

	public async Task<IReadOnlyList<InstalledMod>> ListAsync(CancellationToken cancel)
	{
		return await Task.Run(() => Scan(cancel), cancel);
	}

	public IReadOnlySet<string> InstalledProjects()
	{
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (ModEntry item in ReadCatalog())
		{
			if (Locate(item.File) != null)
			{
				hashSet.Add(item.ProjectId);
			}
		}
		return hashSet;
	}

	public IReadOnlyList<ModEntry> Entries()
	{
		return ReadCatalog();
	}

	public async Task<int> InstallAsync(string projectId, IProgress<string> status, CancellationToken cancel)
	{
		Directory.CreateDirectory(_003Cpaths_003EP.Mods);
		List<ModEntry> catalog = ReadCatalog();
		HashSet<string> visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		Queue<ModrinthDependency> pending = new Queue<ModrinthDependency>();
		pending.Enqueue(new ModrinthDependency(projectId, null));
		int installed = 0;
		try
		{
			while (pending.Count > 0)
			{
				ModrinthDependency next = pending.Dequeue();
				JsonElement jsonElement = ((next.VersionId == null) ? (await _003Cmodrinth_003EP.LatestVersionAsync(next.ProjectId, stableOnly: false, cancel)) : (await _003Cmodrinth_003EP.VersionAsync(next.VersionId, cancel)));
				JsonElement version = jsonElement;
				string id = next.ProjectId ?? ProjectOf(version);
				if (visited.Add(id))
				{
					ModrinthProject project = await _003Cmodrinth_003EP.ProjectAsync(id, cancel);
					ModrinthFile file = ModrinthClient.PrimaryFile(version);
					status.Report(string.Format(CultureInfo.CurrentCulture, "Downloading {0}...", project.Title));
					await _003Cdownloader_003EP.DownloadAsync(file.Url, Path.Combine(_003Cpaths_003EP.Mods, file.Name), file.Sha1, cancel);
					Replace(catalog, new ModEntry(id, project.Slug, project.Title, file.Name, ModrinthClient.VersionNumber(version), project.IconUrl));
					installed++;
					EnqueueDependencies(version, visited, catalog, pending);
				}
			}
			return installed;
		}
		finally
		{
			WriteCatalog(catalog);
		}
	}

	public async Task<string?> RestoreAsync(string file, IProgress<string> status, CancellationToken cancel)
	{
		string file2 = file;
		ModEntry entry = ReadCatalog().Find((ModEntry candidate) => string.Equals(candidate.File, file2, StringComparison.OrdinalIgnoreCase));
		if ((object)entry == null)
		{
			return null;
		}
		try
		{
			await InstallAsync(entry.ProjectId, status, cancel);
		}
		catch (Exception ex) when (((ex is HttpRequestException || ex is JsonException || ex is IOException || ex is InvalidOperationException) ? 1 : 0) != 0)
		{
			return null;
		}
		ModEntry modEntry = ReadCatalog().Find((ModEntry candidate) => string.Equals(candidate.ProjectId, entry.ProjectId, StringComparison.OrdinalIgnoreCase));
		return ((object)modEntry != null && Locate(modEntry.File) != null) ? modEntry.File : null;
	}

	public void Remove(InstalledMod mod)
	{
		InstalledMod mod2 = mod;
		Delete(mod2.Path);
		List<ModEntry> list = ReadCatalog();
		if (list.RemoveAll((ModEntry entry) => string.Equals(entry.File, mod2.File, StringComparison.OrdinalIgnoreCase)) > 0)
		{
			WriteCatalog(list);
		}
	}

	public string? Locate(string file)
	{
		string text = Path.Combine(_003Cpaths_003EP.Mods, file);
		if (File.Exists(text))
		{
			return text;
		}
		string text2 = Path.Combine(_003Cpaths_003EP.ModStore, file);
		if (!File.Exists(text2))
		{
			return null;
		}
		return text2;
	}

	private void EnqueueDependencies(JsonElement version, HashSet<string> visited, List<ModEntry> catalog, Queue<ModrinthDependency> pending)
	{
		foreach (ModrinthDependency item in ModrinthClient.RequiredDependencies(version))
		{
			if ((item.ProjectId != null || item.VersionId != null) && (item.ProjectId == null || (!visited.Contains(item.ProjectId) && !IsSatisfied(catalog, item.ProjectId))))
			{
				pending.Enqueue(item);
			}
		}
	}

	private bool IsSatisfied(List<ModEntry> catalog, string projectId)
	{
		string projectId2 = projectId;
		return catalog.Exists((ModEntry entry) => string.Equals(entry.ProjectId, projectId2, StringComparison.OrdinalIgnoreCase) && Locate(entry.File) != null);
	}

	private List<InstalledMod> Scan(CancellationToken cancel)
	{
		List<ModEntry> list = ReadCatalog();
		Dictionary<string, ModEntry> dictionary = new Dictionary<string, ModEntry>(StringComparer.OrdinalIgnoreCase);
		foreach (ModEntry item in list)
		{
			dictionary[item.File] = item;
		}
		List<InstalledMod> list2 = new List<InstalledMod>();
		HashSet<string> present = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		Collect(_003Cpaths_003EP.Mods, active: true, dictionary, list2, present, cancel);
		Collect(_003Cpaths_003EP.ModStore, active: false, dictionary, list2, present, cancel);
		if (list.RemoveAll((ModEntry entry) => !present.Contains(entry.File)) > 0)
		{
			WriteCatalog(list);
		}
		list2.Sort((InstalledMod left, InstalledMod right) => string.Compare(left.Title, right.Title, StringComparison.CurrentCultureIgnoreCase));
		return list2;
	}

	private static void Collect(string folder, bool active, Dictionary<string, ModEntry> known, List<InstalledMod> mods, HashSet<string> present, CancellationToken cancel)
	{
		if (!Directory.Exists(folder))
		{
			return;
		}
		foreach (string item in Directory.EnumerateFiles(folder, "*.jar"))
		{
			cancel.ThrowIfCancellationRequested();
			string fileName = Path.GetFileName(item);
			if (present.Add(fileName))
			{
				JarMetadata metadata = ModJar.Read(item);
				if (HiddenMods.Contains(metadata.Id, fileName))
				{
					continue;
				}
				bool managed = ManagedMods.Contains(metadata.Id);
				known.TryGetValue(fileName, out ModEntry value);
				mods.Add(new InstalledMod(item, metadata.Id, value?.Title ?? metadata.Name ?? Path.GetFileNameWithoutExtension(item), Detail(value, metadata, item, managed), value?.ProjectId, value?.IconUrl, managed, active));
			}
		}
	}

	private static string Detail(ModEntry? entry, JarMetadata metadata, string jar, bool managed)
	{
		List<string> list = new List<string>(3);
		string text = entry?.VersionNumber ?? metadata.Version;
		if (!string.IsNullOrWhiteSpace(text))
		{
			list.Add(text);
		}
		list.Add((managed || (object)entry != null) ? Size(jar) : "Added manually");
		return string.Join(" · ", list);
	}

	private static string Size(string jar)
	{
		try
		{
			return string.Format(CultureInfo.CurrentCulture, "{0:0.#} MB", (double)new FileInfo(jar).Length / 1048576.0);
		}
		catch (IOException)
		{
			return string.Empty;
		}
	}

	private static string ProjectOf(JsonElement version)
	{
		if (!version.TryGetProperty("project_id", out var value) || value.ValueKind != JsonValueKind.String)
		{
			throw new InvalidOperationException("the Modrinth version carries no project");
		}
		return value.GetString();
	}

	private void Replace(List<ModEntry> catalog, ModEntry fresh)
	{
		for (int num = catalog.Count - 1; num >= 0; num--)
		{
			ModEntry modEntry = catalog[num];
			if (string.Equals(modEntry.ProjectId, fresh.ProjectId, StringComparison.OrdinalIgnoreCase))
			{
				if (!string.Equals(modEntry.File, fresh.File, StringComparison.OrdinalIgnoreCase))
				{
					string text = Locate(modEntry.File);
					if (text != null)
					{
						Delete(text);
					}
				}
				catalog.RemoveAt(num);
			}
		}
		catalog.Add(fresh);
	}

	private static void Delete(string path)
	{
		try
		{
			File.Delete(path);
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
		}
	}

	private List<ModEntry> ReadCatalog()
	{
		try
		{
			return File.Exists(_003Cpaths_003EP.ModsManifest) ? (JsonSerializer.Deserialize<List<ModEntry>>(File.ReadAllText(_003Cpaths_003EP.ModsManifest)) ?? new List<ModEntry>()) : new List<ModEntry>();
		}
		catch (Exception ex) when (((ex is IOException || ex is JsonException) ? 1 : 0) != 0)
		{
			return new List<ModEntry>();
		}
	}

	private void WriteCatalog(List<ModEntry> catalog)
	{
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(_003Cpaths_003EP.ModsManifest));
			File.WriteAllText(_003Cpaths_003EP.ModsManifest, JsonSerializer.Serialize(catalog, CatalogFormat));
		}
		catch (IOException)
		{
		}
	}
}
