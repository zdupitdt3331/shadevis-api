using System;
using System.ComponentModel;
using System.Windows.Media.Media3D;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher.Ui;

public sealed class SkinItem : INotifyPropertyChanged
{
	private const string ApplyText = "Apply";

	private const string ApplyingText = "Applying";

	private const string AppliedText = "In game";

	private SkinAction action;

	private Model3DGroup? model;

	public string Id { get; }

	public string Name { get; }

	public bool Slim { get; }

	public string? ThumbnailUrl { get; }

	public string? LibraryKey { get; }

	public bool FromLibrary => LibraryKey != null;

	public Model3DGroup? Model
	{
		get
		{
			return model;
		}
		set
		{
			model = value;
			Raise("Model");
			Raise("HasModel");
		}
	}

	public bool HasModel => model != null;

	public SkinAction Action
	{
		get
		{
			return action;
		}
		set
		{
			if (action != value)
			{
				action = value;
				Raise("Action");
				Raise("ActionText");
				Raise("ActionEnabled");
			}
		}
	}

	public string ActionText => action switch
	{
		SkinAction.Applying => "Applying", 
		SkinAction.Applied => "In game", 
		_ => "Apply", 
	};

	public bool ActionEnabled => action == SkinAction.Apply;

	public event PropertyChangedEventHandler? PropertyChanged;

	private SkinItem(string id, string name, bool slim, string? thumbnailUrl, string? libraryKey, SkinAction action)
	{
		Id = id;
		Name = name;
		Slim = slim;
		ThumbnailUrl = thumbnailUrl;
		LibraryKey = libraryKey;
		this.action = action;
	}

	public static SkinItem FromNameMc(NameMcSkin skin, bool applied)
	{
		return new SkinItem(skin.Id, skin.Name, slim: false, NameMcClient.Thumbnail(skin.Id), null, applied ? SkinAction.Applied : SkinAction.Apply);
	}

	public static SkinItem FromLibraryEntry(SkinEntry entry, bool applied)
	{
		return new SkinItem(entry.Key, entry.Name, entry.Key.EndsWith("_slim", StringComparison.Ordinal), null, entry.Key, applied ? SkinAction.Applied : SkinAction.Apply);
	}

	private void Raise(string property)
	{
		this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
	}
}
