using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
namespace ShadeVisLauncher.Services;

public sealed class CharacterClient
{
	public const string PlayerSkinSlot = "playerskin";

	private const string CharacterEndpoint = "https://www.evoproject.xyz/api/character";

	private const string SyncEndpoint = "https://www.evoproject.xyz/api/sync";

	private const string ShopEndpoint = "https://www.evoproject.xyz/api/configs";

	private const string ShopHeader = "x-evo-shop";

	private const string ShopHeaderEnabled = "1";

	private const string ShopStateAction = "state";

	private const string OwnedField = "owned";

	private const string DataUrlPrefix = "data:image/png;base64,";

	private const string AddAction = "add";

	private const string RemoveAction = "remove";

	private const string UnknownFailure = "the request was rejected";

	private const string TimeoutFailure = "the account server did not respond in time";

	private const int KeyLength = 32;

	public const string SlimSuffix = "_slim";

	public const string DuplicateSkin = "skin_duplicate";

	public const string LibraryFull = "skin_library_full";

	private static readonly HttpClient Http = LauncherHttp.Create(TimeSpan.FromSeconds(20L));

	public async Task<CharacterProfile> LoadAsync(string token, CancellationToken cancel)
	{
		try
		{
			using JsonDocument jsonDocument = await PostAsync(new { token }, cancel);
			JsonElement rootElement = jsonDocument.RootElement;
			JsonElement value;
			JsonElement value2;
			return new CharacterProfile(rootElement.TryGetProperty("linked", out value) && value.ValueKind == JsonValueKind.True, Text(rootElement, "name"), Text(rootElement, "skinUrl"), rootElement.TryGetProperty("slim", out value2) && value2.ValueKind == JsonValueKind.True, ReadCosmetics(rootElement), ReadSkins(rootElement));
		}
		catch (Exception ex) when (IsOffline(ex, cancel))
		{
			return LocalCharacterStore.Load(null);
		}

	}

	public Task<CharacterProfile> EquipAsync(string token, string slot, string? key, CancellationToken cancel)
	{
		return SetAsync(token, new Dictionary<string, string> { [slot] = key }, cancel);
	}

	public async Task<CharacterProfile> SetAsync(string token, IReadOnlyDictionary<string, string?> patch, CancellationToken cancel)
	{
		try
		{
			using JsonDocument jsonDocument = await PostAsync(new
			{
				token = token,
				set = patch
			}, cancel);
			JsonElement rootElement = jsonDocument.RootElement;
			return new CharacterProfile(Linked: false, null, null, Slim: false, ReadCosmetics(rootElement), ReadSkins(rootElement));
		}
		catch (Exception ex) when (IsOffline(ex, cancel))
		{
			return LocalCharacterStore.Apply(null, patch);
		}

	}

	public async Task<string> AddSkinAsync(string token, string name, bool slim, byte[] png, CancellationToken cancel)
	{
		using JsonDocument jsonDocument = await PostAsync(new
		{
			token = token,
			skin = new
			{
				action = "add",
				name = name,
				slim = slim,
				data = "data:image/png;base64," + Convert.ToBase64String(png)
			}
		}, cancel);
		return Text(jsonDocument.RootElement, "key") ?? throw new CharacterFailure("the account did not return a skin key");
	}

	public async Task RemoveSkinAsync(string token, string key, CancellationToken cancel)
	{
		using (await PostAsync(new
		{
			token = token,
			skin = new
			{
				action = "remove",
				key = key
			}
		}, cancel))
		{
		}
	}

	public static string SkinKey(byte[] png, bool slim)
	{
		return Convert.ToHexStringLower(SHA256.HashData(png)).Substring(0, 32) + (slim ? "_slim" : string.Empty);
	}

	public async Task<string?> SkinPngAsync(string key, CancellationToken cancel)
	{
		_ = 1;
		try
		{
			using HttpResponseMessage response = await Http.PostAsJsonAsync("https://www.evoproject.xyz/api/sync", new
			{
				skins = new string[1] { key }
			}, cancel);
			if (!response.IsSuccessStatusCode)
			{
				return null;
			}
			using JsonDocument jsonDocument = JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancel));
			JsonElement value;
			JsonElement value2;
			return (jsonDocument.RootElement.TryGetProperty("skinData", out value) && value.ValueKind == JsonValueKind.Object && value.TryGetProperty(key, out value2) && value2.ValueKind == JsonValueKind.String) ? value2.GetString() : null;
		}
		catch (Exception ex) when (((ex is HttpRequestException || ex is JsonException) ? true : false) || (ex is OperationCanceledException && !cancel.IsCancellationRequested))
		{
			return null;
		}
	}

	public async Task<IReadOnlySet<string>?> OwnedAsync(string token, CancellationToken cancel)
	{
		_ = 1;
		try
		{
			using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "https://www.evoproject.xyz/api/configs")
			{
				Content = JsonContent.Create(new
				{
					token = token,
					action = "state"
				})
			};
			request.Headers.Add("x-evo-shop", "1");
			using HttpResponseMessage response = await Http.SendAsync(request, cancel);
			if (!response.IsSuccessStatusCode)
			{
				return null;
			}
			using JsonDocument jsonDocument = JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancel));
			if (!jsonDocument.RootElement.TryGetProperty("owned", out var value) || value.ValueKind != JsonValueKind.Array)
			{
				return null;
			}
			HashSet<string> hashSet = new HashSet<string>(StringComparer.Ordinal);
			foreach (JsonElement item in value.EnumerateArray())
			{
				if (item.ValueKind == JsonValueKind.String)
				{
					hashSet.Add(item.GetString());
				}
			}
			return hashSet;
		}
		catch (Exception ex) when (((ex is HttpRequestException || ex is JsonException) ? true : false) || (ex is OperationCanceledException && !cancel.IsCancellationRequested))
		{
			return null;
		}
	}

	public static string ItemId(string slot, string key)
	{
		return slot + ":" + key;
	}

	private static bool IsOffline(Exception error, CancellationToken cancel)
	{
		if (error is CharacterFailure failure && failure.Message == "not_owned")
		{
			return false;
		}
		return error is HttpRequestException || error is CharacterFailure || (error is OperationCanceledException && !cancel.IsCancellationRequested);
	}

	private static async Task<JsonDocument> PostAsync(object request, CancellationToken cancel)
	{
		try
		{
			return await SendAsync(request, cancel);
		}
		catch (OperationCanceledException) when (!cancel.IsCancellationRequested)
		{
			throw new CharacterFailure("the account server did not respond in time");
		}
	}

	private static async Task<JsonDocument> SendAsync(object request, CancellationToken cancel)
	{
		using HttpResponseMessage response = await Http.PostAsJsonAsync("https://www.evoproject.xyz/api/character", request, cancel);
		string json = await response.Content.ReadAsStringAsync(cancel);
		JsonDocument jsonDocument;
		try
		{
			jsonDocument = JsonDocument.Parse(json);
		}
		catch (JsonException)
		{
			throw new CharacterFailure("the request was rejected");
		}
		if (response.IsSuccessStatusCode)
		{
			return jsonDocument;
		}
		string? reason = Text(jsonDocument.RootElement, "error") ?? "the request was rejected";
		jsonDocument.Dispose();
		throw new CharacterFailure(reason);
	}

	private static IReadOnlyDictionary<string, string> ReadCosmetics(JsonElement root)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>(StringComparer.Ordinal);
		if (!root.TryGetProperty("cosmetics", out var value) || value.ValueKind != JsonValueKind.Object)
		{
			return dictionary;
		}
		foreach (JsonProperty item in value.EnumerateObject())
		{
			if (item.Value.ValueKind == JsonValueKind.String)
			{
				dictionary[item.Name] = item.Value.GetString();
			}
		}
		return dictionary;
	}

	private static IReadOnlyList<SkinEntry> ReadSkins(JsonElement root)
	{
		List<SkinEntry> list = new List<SkinEntry>();
		if (!root.TryGetProperty("skins", out var value) || value.ValueKind != JsonValueKind.Array)
		{
			return list;
		}
		foreach (JsonElement item in value.EnumerateArray())
		{
			string text = Text(item, "key");
			if (text != null)
			{
				list.Add(new SkinEntry(text, Text(item, "name") ?? text));
			}
		}
		return list;
	}

	private static string? Text(JsonElement element, string property)
	{
		if (!element.TryGetProperty(property, out var value) || value.ValueKind != JsonValueKind.String)
		{
			return null;
		}
		return value.GetString();
	}
}
