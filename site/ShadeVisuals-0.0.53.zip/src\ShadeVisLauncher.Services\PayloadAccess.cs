namespace ShadeVisLauncher.Services;

public enum PayloadAccess
{
	Unverified,
	Granted,
	SignInRequired,
	Revoked,
	Denied
}
