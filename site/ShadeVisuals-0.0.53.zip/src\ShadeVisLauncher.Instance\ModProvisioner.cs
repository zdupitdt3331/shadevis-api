using System;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher.Instance;

public sealed class ModProvisioner
{
	[CompilerGenerated]
	private InstancePaths _003Cpaths_003EP;

	[CompilerGenerated]
	private HttpDownloader _003Cdownloader_003EP;

	private const string PayloadManifestName = "payload.json";

	private const string PayloadFileName = "shadevis.payload";

	private const string AgentFileName = "evo-agent.jar";

	private const string FabricApiOperation = "Fabric API download";

	private const string ShadersOperation = "Shader support download";

	private const string UpdateCheckOperation = "Update check";

	private const string PayloadOperation = "ShadeVisuals download";

	private const string AgentOperation = "ShadeVisuals agent download";

	private const string AccessOperation = "Access check";

	private const string KeepingInstalledFormat = "{0} failed, using the installed version.";

	private const string PayloadDeniedText = "access to the ShadeVisuals payload was denied";

	private const string AgentDeniedText = "access to the ShadeVisuals agent was denied";

	private const string PayloadCorruptedText = "the ShadeVisuals payload failed integrity verification";

	private readonly ReleaseClient release;

	private readonly ModrinthClient modrinth;

	public ModProvisioner(InstancePaths paths, HttpDownloader downloader)
	{
		_003Cpaths_003EP = paths;
		_003Cdownloader_003EP = downloader;
		release = new ReleaseClient();
		modrinth = new ModrinthClient(_003Cdownloader_003EP);
		
	}

	public async Task<ModDelivery> EnsureAsync(string? token, string? hwid, IProgress<string> status, IProgress<double> percent, CancellationToken cancel)
	{
		await EnsureFabricApiAsync(status, cancel);
		await EnsureShadersAsync(status, cancel);
		await UpdatePayloadAsync(token, hwid, status, percent, cancel);
		bool ready = File.Exists(_003Cpaths_003EP.Agent) && File.Exists(_003Cpaths_003EP.PayloadEnvelope) && token != null;
		PayloadAccess payloadAccess = (ready ? (await VerifyAccessAsync(token, hwid, status, cancel)) : PayloadAccess.Unverified);
		PayloadAccess access = payloadAccess;
		return new ModDelivery(ready, access);
	}

	private async Task<PayloadAccess> VerifyAccessAsync(string token, string? hwid, IProgress<string> status, CancellationToken cancel)
	{
		string token2 = token;
		string hwid2 = hwid;
		if (hwid2 == null)
		{
			return PayloadAccess.Denied;
		}
		status.Report("Verifying access...");
		string sha256 = PayloadKeyClient.Sha256Hex(_003Cpaths_003EP.PayloadEnvelope);
		PayloadKeyClient keys = new PayloadKeyClient();
		PayloadAccess num = await NetworkRetry.RequireAsync("Access check", (CancellationToken attemptCancel) => keys.CheckAccessAsync(token2, hwid2, sha256, attemptCancel), status, cancel);
		if (num == PayloadAccess.Denied)
		{
			File.Delete(_003Cpaths_003EP.PayloadEnvelope);
		}
		return num;
	}

	private async Task EnsureFabricApiAsync(IProgress<string> status, CancellationToken cancel)
	{
		status.Report("Checking Fabric API...");
		try
		{
			await NetworkRetry.RunAsync("Fabric API download", async delegate(CancellationToken attemptCancel)
			{
				ModrinthFile modrinthFile = ModrinthClient.PrimaryFile(await modrinth.LatestVersionAsync("fabric-api", stableOnly: false, attemptCancel));
				string destination = Path.Combine(_003Cpaths_003EP.Mods, modrinthFile.Name);
				await _003Cdownloader_003EP.DownloadAsync(modrinthFile.Url, destination, modrinthFile.Sha1, attemptCancel);
				RemoveConflicting("fabric-api", destination);
				return true;
			}, status, cancel);
		}
		catch (Exception failure) when (NetworkRetry.IsTransient(failure, cancel))
		{
			if (!HasMod("fabric-api"))
			{
				throw NetworkRetry.Unreachable("Fabric API download", failure);
			}
			status.Report(string.Format(CultureInfo.InvariantCulture, "{0} failed, using the installed version.", "Fabric API download"));
		}
	}

	private async Task EnsureShadersAsync(IProgress<string> status, CancellationToken cancel)
	{
		IProgress<string> status2 = status;
		status2.Report("Checking shader support...");
		try
		{
			await NetworkRetry.RunAsync("Shader support download", async delegate(CancellationToken attemptCancel)
			{
				await InstallShadersAsync(status2, attemptCancel);
				return true;
			}, status2, cancel);
		}
		catch (InvalidOperationException)
		{
			status2.Report("Shader support is unavailable right now.");
		}
		catch (Exception failure) when (NetworkRetry.IsTransient(failure, cancel))
		{
			if (!HasMod("iris") || !HasMod("sodium"))
			{
				throw NetworkRetry.Unreachable("Shader support download", failure);
			}
			status2.Report(string.Format(CultureInfo.InvariantCulture, "{0} failed, using the installed version.", "Shader support download"));
		}
	}

	private async Task InstallShadersAsync(IProgress<string> status, CancellationToken cancel)
	{
		JsonElement jsonElement = await modrinth.LatestVersionAsync("iris", stableOnly: true, cancel);
		ModrinthFile irisFile = ModrinthClient.PrimaryFile(jsonElement);
		ModrinthFile sodiumFile = ModrinthClient.PrimaryFile(await CompanionSodiumAsync(jsonElement, cancel));
		string irisPath = Path.Combine(_003Cpaths_003EP.Mods, irisFile.Name);
		string sodiumPath = Path.Combine(_003Cpaths_003EP.Mods, sodiumFile.Name);
		if (!File.Exists(irisPath) || !File.Exists(sodiumPath))
		{
			status.Report("Installing shader support...");
			await _003Cdownloader_003EP.DownloadAsync(irisFile.Url, irisPath, irisFile.Sha1, cancel);
			await _003Cdownloader_003EP.DownloadAsync(sodiumFile.Url, sodiumPath, sodiumFile.Sha1, cancel);
		}
		RemoveConflicting("iris", irisPath);
		RemoveConflicting("sodium", sodiumPath);
	}

	private async Task<JsonElement> CompanionSodiumAsync(JsonElement iris, CancellationToken cancel)
	{
		string text = await modrinth.ProjectIdAsync("sodium", cancel);
		foreach (ModrinthDependency item in ModrinthClient.RequiredDependencies(iris))
		{
			if (!(item.ProjectId != text) && item.VersionId != null)
			{
				return await modrinth.VersionAsync(item.VersionId, cancel);
			}
		}
		return await modrinth.LatestVersionAsync("sodium", stableOnly: true, cancel);
	}

	private void RemoveConflicting(string modId, string? keep)
	{
		foreach (string item in Directory.EnumerateFiles(_003Cpaths_003EP.Mods, "*.jar"))
		{
			if (!string.Equals(item, keep, StringComparison.OrdinalIgnoreCase) && !(ModJar.IdOf(item) != modId))
			{
				try
				{
					File.Delete(item);
				}
				catch (IOException)
				{
				}
			}
		}
	}

	private bool HasMod(string modId)
	{
		foreach (string item in Directory.EnumerateFiles(_003Cpaths_003EP.Mods, "*.jar"))
		{
			if (ModJar.IdOf(item) == modId)
			{
				return true;
			}
		}
		return false;
	}

	private async Task UpdatePayloadAsync(string? token, string? hwid, IProgress<string> status, IProgress<double> percent, CancellationToken cancel)
	{
		string token2 = token;
		string hwid2 = hwid;
		IProgress<string> status2 = status;
		IProgress<double> percent2 = percent;
		status2.Report("Checking for updates...");
		using JsonDocument manifest = await NetworkRetry.RequireAsync("Update check", (CancellationToken attemptCancel) => FetchManifestAsync(token2, hwid2, attemptCancel), status2, cancel);
		if (manifest == null)
		{
			return;
		}
		string digest = manifest.RootElement.GetProperty("sha256").GetString();
		bool firstInstall = !File.Exists(_003Cpaths_003EP.PayloadEnvelope);
		bool flag = !firstInstall;
		if (flag)
		{
			flag = await FileDigest.MatchesSha256Async(_003Cpaths_003EP.PayloadEnvelope, digest, cancel);
		}
		if (flag)
		{
			status2.Report("ShadeVisuals is up to date.");
			return;
		}
		JsonElement value;
		string text = ((manifest.RootElement.TryGetProperty("version", out value) && value.ValueKind == JsonValueKind.String) ? value.GetString() : string.Empty);
		string downloadText = (firstInstall ? "Downloading ShadeVisuals..." : ("Installing update" + ((text.Length > 0) ? (" " + text) : string.Empty) + "..."));
		await NetworkRetry.RequireAsync("ShadeVisuals download", async delegate(CancellationToken attemptCancel)
		{
			status2.Report(downloadText);
			string url2 = (await release.ResolveOrThrowAsync(token2, hwid2, "shadevis.payload", null, attemptCancel)) ?? throw new InvalidOperationException("access to the ShadeVisuals payload was denied");
			await _003Cdownloader_003EP.DownloadWithProgressAsync(url2, _003Cpaths_003EP.PayloadEnvelope, percent2, attemptCancel);
			if (!(await FileDigest.MatchesSha256Async(_003Cpaths_003EP.PayloadEnvelope, digest, attemptCancel)))
			{
				File.Delete(_003Cpaths_003EP.PayloadEnvelope);
				throw new IOException("the ShadeVisuals payload failed integrity verification");
			}
			return true;
		}, status2, cancel);
		await NetworkRetry.RequireAsync("ShadeVisuals agent download", async delegate(CancellationToken attemptCancel)
		{
			string url = (await release.ResolveOrThrowAsync(token2, hwid2, "evo-agent.jar", null, attemptCancel)) ?? throw new InvalidOperationException("access to the ShadeVisuals agent was denied");
			await _003Cdownloader_003EP.DownloadAsync(url, _003Cpaths_003EP.Agent, null, attemptCancel);
			return true;
		}, status2, cancel);
	}

	private async Task<JsonDocument?> FetchManifestAsync(string? token, string? hwid, CancellationToken cancel)
	{
		string text = await release.ResolveOrThrowAsync(token, hwid, "payload.json", null, cancel);
		if (text == null)
		{
			return null;
		}
		return JsonDocument.Parse(await _003Cdownloader_003EP.GetStringAsync(text, cancel));
	}
}
