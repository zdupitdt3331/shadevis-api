using System;

namespace ShadeVisLauncher.Services;

public sealed class CharacterFailure : Exception
{
	public CharacterFailure(string reason)
		: base(reason)
	{
	}
}
