using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text.Json;
namespace ShadeVisLauncher.Instance;

public static class ModJar
{
	public const string SearchPattern = "*.jar";

	private const string MetadataEntry = "fabric.mod.json";

	private const string IdProperty = "id";

	private const string NameProperty = "name";

	private const string VersionProperty = "version";

	private const string ProvidesProperty = "provides";

	private const string DependsProperty = "depends";

	public static JarMetadata Read(string jar)
	{
		try
		{
			using ZipArchive zipArchive = ZipFile.OpenRead(jar);
			ZipArchiveEntry entry = zipArchive.GetEntry("fabric.mod.json");
			if (entry == null)
			{
				return default(JarMetadata);
			}
			using Stream utf8Json = entry.Open();
			using JsonDocument jsonDocument = JsonDocument.Parse(utf8Json);
			JsonElement rootElement = jsonDocument.RootElement;
			return new JarMetadata(Text(rootElement, "id"), Text(rootElement, "name"), Text(rootElement, "version"));
		}
		catch (Exception ex) when (((ex is IOException || ex is InvalidDataException || ex is JsonException) ? 1 : 0) != 0)
		{
			return default(JarMetadata);
		}
	}

	public static string? IdOf(string jar)
	{
		return Read(jar).Id;
	}

	public static ModManifest Manifest(string jar)
	{
		try
		{
			using ZipArchive zipArchive = ZipFile.OpenRead(jar);
			ZipArchiveEntry entry = zipArchive.GetEntry("fabric.mod.json");
			if (entry == null)
			{
				return ModManifest.Empty;
			}
			using Stream utf8Json = entry.Open();
			using JsonDocument jsonDocument = JsonDocument.Parse(utf8Json);
			JsonElement rootElement = jsonDocument.RootElement;
			string text = Text(rootElement, "id");
			HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
			if (text != null)
			{
				hashSet.Add(text);
			}
			if (rootElement.TryGetProperty("provides", out var value) && value.ValueKind == JsonValueKind.Array)
			{
				foreach (JsonElement item in value.EnumerateArray())
				{
					if (item.ValueKind == JsonValueKind.String)
					{
						string @string = item.GetString();
						if (@string != null && @string.Length > 0)
						{
							hashSet.Add(@string);
						}
					}
				}
			}
			HashSet<string> hashSet2 = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
			if (rootElement.TryGetProperty("depends", out var value2) && value2.ValueKind == JsonValueKind.Object)
			{
				foreach (JsonProperty item2 in value2.EnumerateObject())
				{
					hashSet2.Add(item2.Name);
				}
			}
			return new ModManifest(text, hashSet, hashSet2);
		}
		catch (Exception ex) when (((ex is IOException || ex is InvalidDataException || ex is JsonException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
			return ModManifest.Empty;
		}
	}

	private static string? Text(JsonElement element, string property)
	{
		if (!element.TryGetProperty(property, out var value) || value.ValueKind != JsonValueKind.String)
		{
			return null;
		}
		return value.GetString();
	}
}
