namespace ShadeVisLauncher.Ui;

public enum SkinAction
{
	Apply,
	Applying,
	Applied
}
