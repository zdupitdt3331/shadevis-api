using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public readonly record struct ModrinthDependency(string? ProjectId, string? VersionId)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("ModrinthDependency");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		builder.Append("ProjectId = ");
		builder.Append((object?)ProjectId);
		builder.Append(", VersionId = ");
		builder.Append((object?)VersionId);
		return true;
	}
}
