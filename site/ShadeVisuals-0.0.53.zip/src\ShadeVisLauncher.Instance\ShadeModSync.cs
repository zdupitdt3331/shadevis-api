using System;
using System.IO;

namespace ShadeVisLauncher.Instance;

/// <summary>Держит мод ShadeVisuals в shade_mod и подкладывает его в mods.</summary>
public static class ShadeModSync
{
	public static void Ensure(InstancePaths paths)
	{
		try
		{
			Directory.CreateDirectory(paths.Mods);
			Directory.CreateDirectory(paths.ShadeMod);
			foreach (string jar in Directory.EnumerateFiles(paths.ShadeMod, "*.jar"))
			{
				string target = Path.Combine(paths.Mods, Path.GetFileName(jar));
				if (!File.Exists(target))
				{
					File.Copy(jar, target, overwrite: false);
				}
			}
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is System.Security.SecurityException)
		{
		}
	}
}
