using System.ComponentModel;
using System.Globalization;
using ShadeVisLauncher.Instance;

namespace ShadeVisLauncher.Ui;

public sealed class PackItem : INotifyPropertyChanged
{
	private const string SummaryFormat = "{0} mods";

	private const string SingleSummary = "1 mod";

	private const string EmptySummary = "empty";

	private bool active;

	private bool selected;

	public ModPack Pack { get; }

	public string Id => Pack.Id;

	public string Name => Pack.Name;

	public string Summary => Pack.Files.Count switch
	{
		0 => "empty", 
		1 => "1 mod", 
		_ => string.Format(CultureInfo.CurrentCulture, "{0} mods", Pack.Files.Count), 
	};

	public bool IsActive
	{
		get
		{
			return active;
		}
		set
		{
			if (active != value)
			{
				active = value;
				Raise("IsActive");
			}
		}
	}

	public bool IsSelected
	{
		get
		{
			return selected;
		}
		set
		{
			if (selected != value)
			{
				selected = value;
				Raise("IsSelected");
			}
		}
	}

	public event PropertyChangedEventHandler? PropertyChanged;

	public PackItem(ModPack pack, bool active)
	{
		Pack = pack;
		this.active = active;
	}

	public void Refresh()
	{
		Raise("Name");
		Raise("Summary");
	}

	private void Raise(string property)
	{
		this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
	}
}
