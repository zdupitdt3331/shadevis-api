using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
namespace ShadeVisLauncher.Instance;

public static class RunningGame
{
	private const string ProcessName = "javaw";

	private const int StaleGraceSeconds = 60;

	private const int ExitTimeoutMillis = 5000;

	public static bool IsRunning(InstancePaths paths)
	{
		string runtime = RuntimePrefix(paths);
		bool flag = false;
		Process[] processesByName = Process.GetProcessesByName("javaw");
		foreach (Process process in processesByName)
		{
			using (process)
			{
				flag |= BelongsTo(process, runtime);
			}
		}
		return flag;
	}

	private static string RuntimePrefix(InstancePaths paths)
	{
		ReadOnlySpan<char> readOnlySpan = Path.TrimEndingDirectorySeparator(Path.GetFullPath(paths.Runtime));
		char reference = Path.DirectorySeparatorChar;
		return string.Concat(readOnlySpan, new ReadOnlySpan<char>(ref reference));
	}

	public static GameProcessState Reconcile(InstancePaths paths)
	{
		string runtime = RuntimePrefix(paths);
		bool blocked = false;
		int num = 0;
		Process[] processesByName = Process.GetProcessesByName("javaw");
		foreach (Process process in processesByName)
		{
			using (process)
			{
				if (BelongsTo(process, runtime))
				{
					if (IsStale(process) && Release(process))
					{
						num++;
					}
					else
					{
						blocked = true;
					}
				}
			}
		}
		return new GameProcessState(blocked, num);
	}

	private static bool BelongsTo(Process process, string runtime)
	{
		try
		{
			string text = process.MainModule?.FileName;
			return text != null && Path.GetFullPath(text).StartsWith(runtime, StringComparison.OrdinalIgnoreCase);
		}
		catch (Exception ex) when (((ex is Win32Exception || ex is InvalidOperationException || ex is NotSupportedException) ? 1 : 0) != 0)
		{
			return false;
		}
	}

	private static bool IsStale(Process process)
	{
		try
		{
			return process.MainWindowHandle == IntPtr.Zero && DateTime.Now - process.StartTime > TimeSpan.FromSeconds(60L);
		}
		catch (Exception ex) when (((ex is Win32Exception || ex is InvalidOperationException || ex is NotSupportedException) ? 1 : 0) != 0)
		{
			return false;
		}
	}

	private static bool Release(Process process)
	{
		try
		{
			process.Kill(entireProcessTree: true);
			return process.WaitForExit(5000);
		}
		catch (Exception ex) when (((ex is Win32Exception || ex is InvalidOperationException || ex is NotSupportedException || ex is AggregateException) ? 1 : 0) != 0)
		{
			return false;
		}
	}
}
