using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher.Auth;

public static class MicrosoftAuth
{
	private const string ClientId = "54fd49e4-2103-4044-9603-2b028c814ec3";

	private const string Scope = "XboxLive.signin XboxLive.offline_access";

	private const int RedirectPort = 59125;

	private const string RedirectPath = "/in_game_account_switcher_long_enough_uri_to_prevent_accidental_leaks_on_screensharing_even_if_you_have_like_extremely_big_screen_though_it_might_not_mork_but_we_will_try_it_anyway_to_prevent_funny_things_from_happening_or_something";

	private const string AuthorizeEndpoint = "https://login.live.com/oauth20_authorize.srf";

	private const string TokenEndpoint = "https://login.live.com/oauth20_token.srf";

	private const string XblEndpoint = "https://user.auth.xboxlive.com/user/authenticate";

	private const string XstsEndpoint = "https://xsts.auth.xboxlive.com/xsts/authorize";

	private const string MinecraftLoginEndpoint = "https://api.minecraftservices.com/authentication/login_with_xbox";

	private const string ProfileEndpoint = "https://api.minecraftservices.com/minecraft/profile";

	private const string InvalidGrant = "invalid_grant";

	private const string AccessDenied = "access_denied";

	private const int StateBytes = 32;

	private const long NoXboxProfile = 2148916233L;

	private const long RegionBlocked = 2148916235L;

	private const long ChildAccountFirst = 2148916236L;

	private const long ChildAccountLast = 2148916238L;

	private static readonly TimeSpan DefaultMinecraftLifetime = TimeSpan.FromHours(24);

	private static readonly HttpClient Http = LauncherHttp.Create(TimeSpan.FromSeconds(30L));

	private static string RedirectUri
	{
		get
		{
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(17, 2);
			defaultInterpolatedStringHandler.AppendLiteral("http://localhost:");
			defaultInterpolatedStringHandler.AppendFormatted(59125);
			defaultInterpolatedStringHandler.AppendFormatted("/in_game_account_switcher_long_enough_uri_to_prevent_accidental_leaks_on_screensharing_even_if_you_have_like_extremely_big_screen_though_it_might_not_mork_but_we_will_try_it_anyway_to_prevent_funny_things_from_happening_or_something");
			return defaultInterpolatedStringHandler.ToStringAndClear();
		}
	}

	public static MicrosoftSignInRequest CreateSignInRequest()
	{
		string text = Convert.ToHexStringLower(RandomNumberGenerator.GetBytes(32));
		_003C_003Ey__InlineArray6<string> buffer = default(_003C_003Ey__InlineArray6<string>);
		global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray6<string>, string>(ref buffer, 0) = "client_id=54fd49e4-2103-4044-9603-2b028c814ec3";
		global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray6<string>, string>(ref buffer, 1) = "response_type=code";
		global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray6<string>, string>(ref buffer, 2) = "scope=" + Uri.EscapeDataString("XboxLive.signin XboxLive.offline_access");
		global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray6<string>, string>(ref buffer, 3) = "redirect_uri=" + Uri.EscapeDataString(RedirectUri);
		global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray6<string>, string>(ref buffer, 4) = "prompt=select_account";
		global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<_003C_003Ey__InlineArray6<string>, string>(ref buffer, 5) = "state=" + text;
		string text2 = string.Join('&', global::_003CPrivateImplementationDetails_003E.InlineArrayAsReadOnlySpan<_003C_003Ey__InlineArray6<string>, string>(in buffer, 6));
		return new MicrosoftSignInRequest(new Uri("https://login.live.com/oauth20_authorize.srf?" + text2), RedirectUri, text);
	}

	public static string ReadAuthorizationCode(Uri redirect, MicrosoftSignInRequest request)
	{
		Dictionary<string, string> dictionary = ParseQuery(redirect.Query);
		if (dictionary.TryGetValue("error", out var value))
		{
			throw new MicrosoftAuthException((value == "access_denied") ? "Sign-in was cancelled" : ("Microsoft rejected the sign-in: " + dictionary.GetValueOrDefault("error_description", value)));
		}
		if (!dictionary.TryGetValue("state", out var value2) || value2 != request.State)
		{
			throw new MicrosoftAuthException("Microsoft returned an invalid sign-in response");
		}
		if (!dictionary.TryGetValue("code", out var value3) || value3.Length <= 0)
		{
			throw new MicrosoftAuthException("Microsoft returned an empty sign-in response");
		}
		return value3;
	}

	public static async Task<MicrosoftAccount> RedeemCodeAsync(string code, CancellationToken cancel)
	{
		var (microsoftToken, refreshToken) = await RequestTokensAsync(new Dictionary<string, string>
		{
			["client_id"] = "54fd49e4-2103-4044-9603-2b028c814ec3",
			["code"] = code,
			["grant_type"] = "authorization_code",
			["redirect_uri"] = RedirectUri,
			["scope"] = "XboxLive.signin XboxLive.offline_access"
		}, cancel);
		return await SignInMinecraftAsync(microsoftToken, refreshToken, cancel);
	}

	public static async Task<MicrosoftAccount> EnsureFreshAsync(MicrosoftAccount account, TimeSpan minimumLifetime, CancellationToken cancel)
	{
		string accessToken = account.AccessToken;
		if (accessToken != null && accessToken.Length > 0 && account.AccessExpiresUtc - DateTime.UtcNow > minimumLifetime)
		{
			return account;
		}
		var (microsoftToken, refreshToken) = await RequestTokensAsync(new Dictionary<string, string>
		{
			["client_id"] = "54fd49e4-2103-4044-9603-2b028c814ec3",
			["refresh_token"] = account.RefreshToken,
			["grant_type"] = "refresh_token",
			["scope"] = "XboxLive.signin XboxLive.offline_access"
		}, cancel);
		return await SignInMinecraftAsync(microsoftToken, refreshToken, cancel);
	}

	private static async Task<MicrosoftAccount> SignInMinecraftAsync(string microsoftToken, string refreshToken, CancellationToken cancel)
	{
		var (xblToken, userHash) = await AuthenticateXboxAsync(microsoftToken, cancel);
		var (minecraftToken, lifetime) = await LoginMinecraftAsync(userHash, await AuthorizeXstsAsync(xblToken, cancel), cancel);
		var (uuid, name) = await FetchProfileAsync(minecraftToken, cancel);
		return new MicrosoftAccount(uuid, name, refreshToken, minecraftToken, DateTime.UtcNow + lifetime);
	}

	private static async Task<(string Access, string Refresh)> RequestTokensAsync(Dictionary<string, string> form, CancellationToken cancel)
	{
		using HttpResponseMessage response = await Http.PostAsync("https://login.live.com/oauth20_token.srf", new FormUrlEncodedContent(form), cancel);
		using JsonDocument jsonDocument = ParseOrEmpty(await response.Content.ReadAsStringAsync(cancel));
		JsonElement rootElement = jsonDocument.RootElement;
		if (!response.IsSuccessStatusCode)
		{
			string text = ReadString(rootElement, "error");
			if (text == null)
			{
				DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(5, 1);
				defaultInterpolatedStringHandler.AppendLiteral("HTTP ");
				defaultInterpolatedStringHandler.AppendFormatted((int)response.StatusCode);
				text = defaultInterpolatedStringHandler.ToStringAndClear();
			}
			string text2 = text;
			bool flag = text2 == "invalid_grant";
			throw new MicrosoftAuthException(flag ? "Microsoft session expired — sign in to Microsoft again" : ("Microsoft token request failed: " + text2), flag);
		}
		string? item = ReadString(rootElement, "access_token") ?? throw new MicrosoftAuthException("Microsoft returned no access token");
		string item2 = ReadString(rootElement, "refresh_token") ?? throw new MicrosoftAuthException("Microsoft returned no refresh token");
		return (Access: item, Refresh: item2);
	}

	private static async Task<(string Token, string UserHash)> AuthenticateXboxAsync(string microsoftToken, CancellationToken cancel)
	{
		var value = new
		{
			Properties = new
			{
				AuthMethod = "RPS",
				SiteName = "user.auth.xboxlive.com",
				RpsTicket = "d=" + microsoftToken
			},
			RelyingParty = "http://auth.xboxlive.com",
			TokenType = "JWT"
		};
		using HttpResponseMessage response = await Http.PostAsJsonAsync("https://user.auth.xboxlive.com/user/authenticate", value, cancel);
		return ReadXboxToken(await ExpectOkAsync(response, "Xbox Live sign-in failed", cancel));
	}

	private static async Task<string> AuthorizeXstsAsync(string xblToken, CancellationToken cancel)
	{
		var value = new
		{
			Properties = new
			{
				SandboxId = "RETAIL",
				UserTokens = new string[1] { xblToken }
			},
			RelyingParty = "rp://api.minecraftservices.com/",
			TokenType = "JWT"
		};
		using HttpResponseMessage response = await Http.PostAsJsonAsync("https://xsts.auth.xboxlive.com/xsts/authorize", value, cancel);
		if (response.StatusCode == HttpStatusCode.Unauthorized)
		{
			using (JsonDocument jsonDocument = ParseOrEmpty(await response.Content.ReadAsStringAsync(cancel)))
			{
				throw new MicrosoftAuthException(XstsError(jsonDocument.RootElement));
			}
		}
		return ReadXboxToken(await ExpectOkAsync(response, "Xbox authorization failed", cancel)).Token;
	}

	private static string XstsError(JsonElement root)
	{
		if (root.ValueKind != JsonValueKind.Object || !root.TryGetProperty("XErr", out var value) || !value.TryGetInt64(out var value2))
		{
			return "Xbox denied the sign-in";
		}
		switch (value2)
		{
		case 2148916233L:
			return "This Microsoft account has no Xbox profile — open minecraft.net once and sign in there";
		case 2148916235L:
			return "Xbox Live is not available in your region";
		case 2148916236L:
		case 2148916237L:
		case 2148916238L:
			return "This is a child account — add it to a Microsoft family first";
		default:
		{
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(31, 1);
			defaultInterpolatedStringHandler.AppendLiteral("Xbox denied the sign-in (XErr ");
			defaultInterpolatedStringHandler.AppendFormatted(value2);
			defaultInterpolatedStringHandler.AppendLiteral(")");
			return defaultInterpolatedStringHandler.ToStringAndClear();
		}
		}
	}

	private static async Task<(string Token, TimeSpan Lifetime)> LoginMinecraftAsync(string userHash, string xstsToken, CancellationToken cancel)
	{
		var value = new
		{
			identityToken = "XBL3.0 x=" + userHash + ";" + xstsToken
		};
		using HttpResponseMessage response = await Http.PostAsJsonAsync("https://api.minecraftservices.com/authentication/login_with_xbox", value, cancel);
		JsonElement element = await ExpectOkAsync(response, "Minecraft services sign-in failed", cancel);
		string? item = ReadString(element, "access_token") ?? throw new MicrosoftAuthException("Minecraft returned no access token");
		JsonElement value2;
		int value3;
		TimeSpan item2 = ((element.TryGetProperty("expires_in", out value2) && value2.TryGetInt32(out value3)) ? TimeSpan.FromSeconds(value3) : DefaultMinecraftLifetime);
		return (Token: item, Lifetime: item2);
	}

	private static async Task<(string Uuid, string Name)> FetchProfileAsync(string minecraftToken, CancellationToken cancel)
	{
		using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "https://api.minecraftservices.com/minecraft/profile");
		request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", minecraftToken);
		using HttpResponseMessage response = await Http.SendAsync(request, cancel);
		if (response.StatusCode == HttpStatusCode.NotFound)
		{
			throw new MicrosoftAuthException("This Microsoft account doesn't own Minecraft: Java Edition");
		}
		JsonElement element = await ExpectOkAsync(response, "Couldn't fetch the Minecraft profile", cancel);
		string item = ReadString(element, "id") ?? throw new MicrosoftAuthException("Minecraft profile has no id");
		string item2 = ReadString(element, "name") ?? throw new MicrosoftAuthException("Minecraft profile has no name");
		return (Uuid: item, Name: item2);
	}

	private static (string Token, string UserHash) ReadXboxToken(JsonElement root)
	{
		string? item = ReadString(root, "Token") ?? throw new MicrosoftAuthException("Xbox returned no token");
		if (!root.TryGetProperty("DisplayClaims", out var value) || !value.TryGetProperty("xui", out var value2) || value2.ValueKind != JsonValueKind.Array || value2.GetArrayLength() == 0)
		{
			throw new MicrosoftAuthException("Xbox returned no user hash");
		}
		string item2 = ReadString(value2[0], "uhs") ?? throw new MicrosoftAuthException("Xbox returned no user hash");
		return (Token: item, UserHash: item2);
	}

	private static async Task<JsonElement> ExpectOkAsync(HttpResponseMessage response, string failure, CancellationToken cancel)
	{
		string body = await response.Content.ReadAsStringAsync(cancel);
		if (!response.IsSuccessStatusCode)
		{
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(8, 2);
			defaultInterpolatedStringHandler.AppendFormatted(failure);
			defaultInterpolatedStringHandler.AppendLiteral(" (HTTP ");
			defaultInterpolatedStringHandler.AppendFormatted((int)response.StatusCode);
			defaultInterpolatedStringHandler.AppendLiteral(")");
			throw new MicrosoftAuthException(defaultInterpolatedStringHandler.ToStringAndClear());
		}
		using JsonDocument jsonDocument = ParseOrEmpty(body);
		if (jsonDocument.RootElement.ValueKind != JsonValueKind.Object)
		{
			throw new MicrosoftAuthException(failure + " (unreadable response)");
		}
		return jsonDocument.RootElement.Clone();
	}

	private static JsonDocument ParseOrEmpty(string body)
	{
		try
		{
			return JsonDocument.Parse(body);
		}
		catch (JsonException)
		{
			return JsonDocument.Parse("null");
		}
	}

	private static string? ReadString(JsonElement element, string property)
	{
		if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(property, out var value) || value.ValueKind != JsonValueKind.String)
		{
			return null;
		}
		return value.GetString();
	}

	private static Dictionary<string, string> ParseQuery(string query)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>(StringComparer.Ordinal);
		string[] array = query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries);
		foreach (string text in array)
		{
			int num = text.IndexOf('=');
			string key = Uri.UnescapeDataString((num < 0) ? text : text.Substring(0, num));
			string text3;
			if (num >= 0)
			{
				string text2 = text;
				int num2 = num + 1;
				text3 = Uri.UnescapeDataString(text2.Substring(num2, text2.Length - num2).Replace('+', ' '));
			}
			else
			{
				text3 = string.Empty;
			}
			string value = text3;
			dictionary[key] = value;
		}
		return dictionary;
	}
}
