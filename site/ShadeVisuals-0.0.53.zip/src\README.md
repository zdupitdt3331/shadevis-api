# ShadeVis

Windows x64 launcher. Build: `build.bat`. Output: `dist/win-x64/ShadeVisLauncher.exe`.

## Accounts

Accounts are local: the launcher stores them in `%APPDATA%\ShadeVis\accounts.json`.
Passwords are hashed with PBKDF2-SHA256 (120000 iterations, random 16-byte salt).

- **Create account** — nickname (3-16 chars, letters/digits/underscore) + password (6+ chars).
- **Sign in** — same nickname and password.
- The last used nickname is remembered and prefilled.

## Minecraft account

"Sign in with Microsoft" opens the Microsoft OAuth page inside the launcher (WebView2),
then exchanges the code for Xbox Live / XSTS / Minecraft tokens and stores the session in
`%APPDATA%\ShadeVis\microsoft.dat` (DPAPI-encrypted, per Windows user). While linked,
the game launches with your licensed nickname and token, so premium servers accept you;
"Sign out of Microsoft" clears it and falls back to the offline nickname.

## Mods

Modrinth is used directly from the launcher: search, sort (Popular / Relevant / Updated),
install (required dependencies are pulled in too) and remove. Files land in
`%APPDATA%\ShadeVis\instance\mc\mods` and are checked against the Modrinth SHA-1.
Only mods are downloaded; the Minecraft instance itself stays local (no auto-provisioning).

## Cosmetics

The catalog mirrors the ShadeVisuals mod (`assets/xavisual`): 8 tabs — Capes, Wings, Hats,
Backpacks, Companions, Knives, Nametags, Models (85 items). Cape textures come from the mod
(`textures/capes/*.png`, stored base64 in `assets/viewer/capes.json`). The choice is kept in
`%APPDATA%\ShadeVis\character.json` and passed to the game as `SHADE_COSMETICS`
(`cape:capes2,hat:crown`). Thumbnails/3D preview need the original `assets/viewer` renderer.

## Home background

`assets/hero.png` is drawn behind the home hero card (rounded clip, `UniformToFill`).
If `assets/background.mp4` exists, the video plays on top of it.

## Avatar

Click your avatar (or nickname) in the sidebar to pick any image from disk
(PNG/JPG/WEBP/BMP/GIF, up to 8 MB) — it is cropped into the round avatar and stored per
account in `%APPDATA%\ShadeVis\avatars\<nick>.img`. Shift+click the avatar to reset it
back to the first letter of the nickname. Broken images fall back to the letter.

## Roles

Roles: `Admin`, `Media`, `User`. They live in `%APPDATA%\ShadeVis\roles.json`
(created on first start, `Art1x` is Admin by default).

Assign a role:

    ShadeVisLauncher.exe --set-role <nickname> <Admin|Media|User>

Remove an override:

    ShadeVisLauncher.exe --set-role <nickname> none

You can also edit `roles.json` by hand. The role is applied on the next sign-in,
shown in the account panel, and passed to the game as the `SHADE_ROLE` environment variable.

## HWID binding

The launcher is bound to the first computer it runs on: `%APPDATA%\ShadeVis\hwid.txt`
stores the HWID (SHA-256 of the Windows MachineGuid with the `shadevis|` salt).
Delete that file to re-bind the launcher to another PC. The HWID is also exposed to the
game process as the `SHADE_HWID` environment variable.

## Instance

The launcher runs an installed Minecraft 1.21.11 + Fabric instance from
`%APPDATA%\ShadeVis\instance` (client jar, libraries, assets, fabric loader, runtime, mods).
Downloads, updates and remote metadata are disabled; only installed files are used.
