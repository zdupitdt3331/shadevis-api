using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
namespace ShadeVisLauncher.Services;

public static class NetworkRetry
{
	public const int MaxAttempts = 3;

	private static readonly TimeSpan BaseDelay = TimeSpan.FromSeconds(2L);

	private const string RetryFormat = "{0} failed, retrying ({1}/{2})...";

	private const string UnreachableFormat = "{0} failed after {1} attempts. Check your internet connection, VPN or bypass list and try again.";

	public static async Task<T> RequireAsync<T>(string operation, Func<CancellationToken, Task<T>> action, IProgress<string> status, CancellationToken cancel)
	{
		try
		{
			return await RunAsync(operation, action, status, cancel);
		}
		catch (Exception failure) when (IsTransient(failure, cancel))
		{
			throw Unreachable(operation, failure);
		}
	}

	public static Task RequireAsync(string operation, Func<CancellationToken, Task> action, IProgress<string> status, CancellationToken cancel)
	{
		Func<CancellationToken, Task> action2 = action;
		return RequireAsync(operation, async delegate(CancellationToken attemptCancel)
		{
			await action2(attemptCancel);
			return true;
		}, status, cancel);
	}

	public static InvalidOperationException Unreachable(string operation, Exception failure)
	{
		return new InvalidOperationException(string.Format(CultureInfo.InvariantCulture, "{0} failed after {1} attempts. Check your internet connection, VPN or bypass list and try again.", operation, 3), failure);
	}

	public static async Task<T> RunAsync<T>(string operation, Func<CancellationToken, Task<T>> action, IProgress<string> status, CancellationToken cancel)
	{
		int attempt = 1;
		while (true)
		{
			try
			{
				return await action(cancel);
			}
			catch (Exception failure) when (attempt < 3 && IsTransient(failure, cancel))
			{
				status.Report(string.Format(CultureInfo.InvariantCulture, "{0} failed, retrying ({1}/{2})...", operation, attempt + 1, 3));
				await Task.Delay(BaseDelay * attempt, cancel);
			}
			attempt++;
		}
	}

	public static bool IsTransient(Exception failure, CancellationToken cancel)
	{
		if (!(failure is OperationCanceledException))
		{
			if (failure is HttpRequestException || failure is IOException || failure is TimeoutException || failure is JsonException)
			{
				return true;
			}
			return false;
		}
		return !cancel.IsCancellationRequested;
	}

	public static bool IsTransientStatus(HttpStatusCode status)
	{
		bool flag = status >= HttpStatusCode.InternalServerError;
		if (!flag)
		{
			bool flag2 = ((status == HttpStatusCode.RequestTimeout || status == HttpStatusCode.TooManyRequests) ? true : false);
			flag = flag2;
		}
		return flag;
	}

	public static void ThrowIfTransient(HttpResponseMessage response)
	{
		if (IsTransientStatus(response.StatusCode))
		{
			throw new HttpRequestException(response.ReasonPhrase, null, response.StatusCode);
		}
	}
}
