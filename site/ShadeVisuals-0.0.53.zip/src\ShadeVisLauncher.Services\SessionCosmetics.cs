using System;
using System.Collections.Generic;

namespace ShadeVisLauncher.Services;

/// <summary>Выбранная косметика текущей сессии, передаётся игре переменной SHADE_COSMETICS.</summary>
public static class SessionCosmetics
{
	public static string Current { get; set; } = string.Empty;

	public static string Build(IReadOnlyDictionary<string, string>? cosmetics)
	{
		if (cosmetics == null || cosmetics.Count == 0)
		{
			return string.Empty;
		}
		List<string> parts = new List<string>(cosmetics.Count);
		foreach (KeyValuePair<string, string> item in cosmetics)
		{
			if (!string.IsNullOrEmpty(item.Value))
			{
				parts.Add(item.Key + ":" + item.Value);
			}
		}
		return string.Join(",", parts);
	}
}
