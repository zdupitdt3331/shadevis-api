using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using ShadeVisLauncher.Services;
using SharpCompress.Archives.SevenZip;

namespace ShadeVisLauncher.Instance;

public sealed class GraphicsProvisioner
{
	[CompilerGenerated]
	private InstancePaths _003Cpaths_003EP;

	[CompilerGenerated]
	private HttpDownloader _003Cdownloader_003EP;

	private const string MesaVersion = "26.2.0";

	private const string ReleaseUrl = "https://github.com/mmozeiko/build-mesa/releases/download/{0}/mesa-llvmpipe-{1}-{0}.7z";

	private const string LibraryName = "opengl32.dll";

	private const string ArchiveName = "mesa-llvmpipe.7z";

	private const string Arm64Architecture = "arm64";

	private const string X64Architecture = "x64";

	private const string Arm64LibraryDigest = "c8e12ddc660d10bfecfb956d21e320613d2487efb16e840b8a6df1de508331ed";

	private const string X64LibraryDigest = "ec5e6b2916d719671c8a4f013276d809b1e730d85e0c1bcfddb493083eb4db1a";

	private const int CopyBuffer = 65536;

	public GraphicsProvisioner(InstancePaths paths, HttpDownloader downloader)
	{
		_003Cpaths_003EP = paths;
		_003Cdownloader_003EP = downloader;
		
	}

	public async Task InstallAsync(string javaExecutable, IProgress<string> status, IProgress<double> percent, CancellationToken cancel)
	{
		(string, string) tuple = Target();
		string architecture = tuple.Item1;
		string digest = tuple.Item2;
		string cached = Path.Combine(_003Cpaths_003EP.Graphics, "opengl32.dll");
		if (!(await FileDigest.MatchesSha256Async(cached, digest, cancel)))
		{
			Directory.CreateDirectory(_003Cpaths_003EP.Graphics);
			string archive = Path.Combine(_003Cpaths_003EP.Graphics, "mesa-llvmpipe.7z");
			status.Report("Downloading software renderer...");
			await _003Cdownloader_003EP.DownloadWithProgressAsync(string.Format("https://github.com/mmozeiko/build-mesa/releases/download/{0}/mesa-llvmpipe-{1}-{0}.7z", "26.2.0", architecture), archive, percent, cancel);
			status.Report("Installing software renderer...");
			await ExtractLibraryAsync(archive, cached, cancel);
			TryDelete(archive);
			if (!(await FileDigest.MatchesSha256Async(cached, digest, cancel)))
			{
				TryDelete(cached);
				throw new InvalidOperationException("the software renderer failed integrity verification");
			}
		}
		string installed = LibraryPath(javaExecutable);
		if (!(await FileDigest.MatchesSha256Async(installed, digest, cancel)))
		{
			File.Copy(cached, installed, overwrite: true);
		}
	}

	public static void Remove(string javaExecutable)
	{
		TryDelete(LibraryPath(javaExecutable));
	}

	private static string LibraryPath(string javaExecutable)
	{
		return Path.Combine(Path.GetDirectoryName(javaExecutable), "opengl32.dll");
	}

	private static (string Architecture, string Digest) Target()
	{
		Architecture oSArchitecture = RuntimeInformation.OSArchitecture;
		switch (oSArchitecture)
		{
		case Architecture.Arm64:
			return (Architecture: "arm64", Digest: "c8e12ddc660d10bfecfb956d21e320613d2487efb16e840b8a6df1de508331ed");
		case Architecture.X64:
			return (Architecture: "x64", Digest: "ec5e6b2916d719671c8a4f013276d809b1e730d85e0c1bcfddb493083eb4db1a");
		default:
		{
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(25, 1);
			defaultInterpolatedStringHandler.AppendLiteral("no software renderer for ");
			defaultInterpolatedStringHandler.AppendFormatted(oSArchitecture);
			throw new PlatformNotSupportedException(defaultInterpolatedStringHandler.ToStringAndClear());
		}
		}
	}

	private static async Task ExtractLibraryAsync(string archive, string destination, CancellationToken cancel)
	{
		using SevenZipArchive container = SevenZipArchive.Open(archive);
		foreach (SevenZipArchiveEntry entry in container.Entries)
		{
			if (entry.IsDirectory || !string.Equals(entry.Key, "opengl32.dll", StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}
			string temporary = destination + ".part";
			Stream source = entry.OpenEntryStream();
			try
			{
				FileStream target = File.Create(temporary);
				try
				{
					await source.CopyToAsync(target, 65536, cancel);
				}
				finally
				{
					if (target != null)
					{
						await target.DisposeAsync();
					}
				}
			}
			finally
			{
				if (source != null)
				{
					await source.DisposeAsync();
				}
			}
			File.Move(temporary, destination, overwrite: true);
			return;
		}
		throw new InvalidOperationException("opengl32.dll is missing from the software renderer archive");
	}

	private static void TryDelete(string path)
	{
		try
		{
			File.Delete(path);
		}
		catch (Exception)
		{
		}
	}
}
