using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
namespace ShadeVisLauncher.Services;

public static class ReleaseInfo
{
	private const string ManifestAsset = "payload.json";

	private const string Unknown = "dev";

	private static readonly HttpClient Http = LauncherHttp.Create(TimeSpan.FromSeconds(10L));

	private static readonly ReleaseClient Release = new ReleaseClient();

	public static async Task<string> ModVersionAsync(string? token, string? hwid, CancellationToken cancel)
	{
		_ = 1;
		try
		{
			string text = await Release.ResolveAsync(token, hwid, "payload.json", null, cancel);
			if (text == null)
			{
				return "dev";
			}
			using JsonDocument jsonDocument = JsonDocument.Parse(await Http.GetStringAsync(text, cancel));
			JsonElement value;
			return (jsonDocument.RootElement.TryGetProperty("version", out value) && value.ValueKind == JsonValueKind.String) ? (value.GetString() ?? "dev") : "dev";
		}
		catch (Exception)
		{
			return "dev";
		}
	}
}
