using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public sealed record PackManifest(int Format, string Name, List<PackManifestMod> Mods)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("PackManifest");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Format = ");
		builder.Append(Format.ToString());
		builder.Append(", Name = ");
		builder.Append((object?)Name);
		builder.Append(", Mods = ");
		builder.Append(Mods);
		return true;
	}
}
