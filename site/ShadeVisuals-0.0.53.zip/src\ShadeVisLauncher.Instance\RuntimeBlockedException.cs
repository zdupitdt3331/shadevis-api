using System;
using System.IO;
namespace ShadeVisLauncher.Instance;

public sealed class RuntimeBlockedException : InvalidOperationException
{
	public string RuntimeDirectory { get; }

	public RuntimeBlockedException(string runtimeDirectory) : base("Java files were removed or blocked by Windows Security or your antivirus. Add \"" + (Path.GetDirectoryName(runtimeDirectory) ?? runtimeDirectory) + "\" to your antivirus exclusions, restore any quarantined ShadeVis files and launch again.")
	{
		RuntimeDirectory = runtimeDirectory;
		
	}
}
