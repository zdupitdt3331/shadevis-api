using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace ShadeVisLauncher.Services;

/// <summary>Локальное хранение косметики на случай, если сервер аккаунтов недоступен.</summary>
public static class LocalCharacterStore
{
	private static readonly object Gate = new object();

	private static readonly JsonSerializerOptions Format = new JsonSerializerOptions
	{
		WriteIndented = true
	};

	internal static string? RootOverride;

	private static string FilePath => Path.Combine(RootOverride ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ShadeVis"), "character.json");

	public static CharacterProfile Load(string? name)
	{
		lock (Gate)
		{
			return new CharacterProfile(Linked: false, name, null, Slim: false, Read(), Array.Empty<SkinEntry>());
		}
	}

	public static CharacterProfile Apply(string? name, IReadOnlyDictionary<string, string?> patch)
	{
		lock (Gate)
		{
			Dictionary<string, string> map = new Dictionary<string, string>(Read(), StringComparer.Ordinal);
			foreach (KeyValuePair<string, string?> item in patch)
			{
				if (string.IsNullOrEmpty(item.Value))
				{
					map.Remove(item.Key);
				}
				else
				{
					map[item.Key] = item.Value!;
				}
			}
			Write(map);
			return new CharacterProfile(Linked: false, name, null, Slim: false, map, Array.Empty<SkinEntry>());
		}
	}

	private static IReadOnlyDictionary<string, string> Read()
	{
		try
		{
			if (!File.Exists(FilePath))
			{
				return new Dictionary<string, string>(StringComparer.Ordinal);
			}
			Dictionary<string, string>? parsed = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(FilePath));
			return parsed != null ? new Dictionary<string, string>(parsed, StringComparer.Ordinal) : new Dictionary<string, string>(StringComparer.Ordinal);
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is JsonException || ex is System.Security.SecurityException)
		{
			return new Dictionary<string, string>(StringComparer.Ordinal);
		}
	}

	private static void Write(IReadOnlyDictionary<string, string> map)
	{
		try
		{
			string? folder = Path.GetDirectoryName(FilePath);
			if (!string.IsNullOrEmpty(folder))
			{
				Directory.CreateDirectory(folder);
			}
			File.WriteAllText(FilePath, JsonSerializer.Serialize(map, Format));
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is System.Security.SecurityException)
		{
		}
	}
}
