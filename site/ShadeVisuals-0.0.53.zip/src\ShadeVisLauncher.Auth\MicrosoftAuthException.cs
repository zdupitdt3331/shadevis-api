using System;

namespace ShadeVisLauncher.Auth;

public sealed class MicrosoftAuthException : Exception
{
	public bool SignInRequired { get; }

	public MicrosoftAuthException(string message, bool signInRequired = false) : base(message)
	{
		SignInRequired = signInRequired;
		
	}
}
