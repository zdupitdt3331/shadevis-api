using System;
using System.IO;
using System.Text;

namespace ShadeVisLauncher.Services;

/// <summary>Аватарки аккаунтов: любые картинки, выбранные пользователем.</summary>
public static class AvatarStore
{
	private const string FolderName = "avatars";

	private const string Extension = ".img";

	internal static string? RootOverride;

	private static string Folder => Path.Combine(RootOverride ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ShadeVis"), FolderName);

	private static string PathFor(string nick)
	{
		StringBuilder builder = new StringBuilder(nick.Length);
		foreach (char c in nick.Trim().ToLowerInvariant())
		{
			builder.Append((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-' ? c : '_');
		}
		return Path.Combine(Folder, builder.ToString() + Extension);
	}

	public static byte[]? Load(string? nick)
	{
		if (string.IsNullOrWhiteSpace(nick))
		{
			return null;
		}
		try
		{
			string path = PathFor(nick);
			return File.Exists(path) ? File.ReadAllBytes(path) : null;
		}
		catch (Exception ex) when (IsAccessError(ex))
		{
			return null;
		}
	}

	public static bool Save(string nick, byte[] data)
	{
		if (string.IsNullOrWhiteSpace(nick) || data.Length == 0)
		{
			return false;
		}
		try
		{
			Directory.CreateDirectory(Folder);
			File.WriteAllBytes(PathFor(nick), data);
			return true;
		}
		catch (Exception ex) when (IsAccessError(ex))
		{
			return false;
		}
	}

	public static void Clear(string? nick)
	{
		if (string.IsNullOrWhiteSpace(nick))
		{
			return;
		}
		try
		{
			File.Delete(PathFor(nick));
		}
		catch (Exception ex) when (IsAccessError(ex))
		{
		}
	}

	private static bool IsAccessError(Exception error)
	{
		return error is IOException || error is UnauthorizedAccessException || error is System.Security.SecurityException;
	}
}
