using System.ComponentModel;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher.Ui;

public sealed class CosmeticTab : INotifyPropertyChanged
{
	private bool selected;

	public CosmeticCategory Category { get; }

	public string Title => Category.Title;

	public string Slot => Category.Slot;

	public int Count => Category.Entries.Count;

	public bool Selected
	{
		get
		{
			return selected;
		}
		set
		{
			if (selected != value)
			{
				selected = value;
				this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Selected"));
			}
		}
	}

	public event PropertyChangedEventHandler? PropertyChanged;

	public CosmeticTab(CosmeticCategory category, bool selected)
	{
		Category = category;
		this.selected = selected;
	}
}
