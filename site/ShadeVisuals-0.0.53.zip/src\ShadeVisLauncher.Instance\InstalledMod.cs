using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public sealed record InstalledMod(string Path, string? Id, string Title, string Detail, string? ProjectId, string? IconUrl, bool Managed, bool Active)
{
	public string File => System.IO.Path.GetFileName(Path);

	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("InstalledMod");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Path = ");
		builder.Append((object?)Path);
		builder.Append(", Id = ");
		builder.Append((object?)Id);
		builder.Append(", Title = ");
		builder.Append((object?)Title);
		builder.Append(", Detail = ");
		builder.Append((object?)Detail);
		builder.Append(", ProjectId = ");
		builder.Append((object?)ProjectId);
		builder.Append(", IconUrl = ");
		builder.Append((object?)IconUrl);
		builder.Append(", Managed = ");
		builder.Append(Managed.ToString());
		builder.Append(", Active = ");
		builder.Append(Active.ToString());
		builder.Append(", File = ");
		builder.Append((object?)File);
		return true;
	}
}
