using System;
using System.Globalization;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace ShadeVisLauncher.Services;

public static class MachineProfile
{
	private const string Kernel32 = "kernel32.dll";

	private const string ProcessorKey = "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0";

	private const string ProcessorNameValue = "ProcessorNameString";

	private const double KilobytesPerGigabyte = 1048576.0;

	private const string GigabyteFormat = "0.#";

	private const string GigabyteSuffix = " GB";

	private const string Unknown = "unknown";

	private static MachineSnapshot? _cached;

	public static MachineSnapshot Current => _cached ?? (_cached = Capture());

	public static int PhysicalMemoryGigabytes
	{
		get
		{
			try
			{
				long totalMemoryInKilobytes;
				return (GetPhysicallyInstalledSystemMemory(out totalMemoryInKilobytes) && totalMemoryInKilobytes > 0) ? ((int)((double)totalMemoryInKilobytes / 1048576.0)) : 0;
			}
			catch (Exception)
			{
				return 0;
			}
		}
	}

	private static MachineSnapshot Capture()
	{
		return new MachineSnapshot(RuntimeInformation.OSDescription, RuntimeInformation.OSArchitecture.ToString().ToLowerInvariant(), ProcessorName(), Environment.ProcessorCount, PhysicalMemory());
	}

	private static string ProcessorName()
	{
		try
		{
			using RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0");
			string text = registryKey?.GetValue("ProcessorNameString") as string;
			return string.IsNullOrWhiteSpace(text) ? "unknown" : text.Trim();
		}
		catch (Exception)
		{
			return "unknown";
		}
	}

	private static string PhysicalMemory()
	{
		try
		{
			if (!GetPhysicallyInstalledSystemMemory(out var totalMemoryInKilobytes) || totalMemoryInKilobytes <= 0)
			{
				return "unknown";
			}
			return ((double)totalMemoryInKilobytes / 1048576.0).ToString("0.#", CultureInfo.InvariantCulture) + " GB";
		}
		catch (Exception)
		{
			return "unknown";
		}
	}

	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool GetPhysicallyInstalledSystemMemory(out long totalMemoryInKilobytes);
}
