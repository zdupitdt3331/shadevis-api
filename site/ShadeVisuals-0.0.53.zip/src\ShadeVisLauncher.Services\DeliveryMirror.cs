using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
namespace ShadeVisLauncher.Services;

public static class DeliveryMirror
{
	public sealed class Mirror
	{
		private long retryAfter;

		public string Origin { get; }

		public bool IsAvailable => Environment.TickCount64 >= Interlocked.Read(ref retryAfter);

		public Mirror(string origin)
		{
			Origin = origin;
			
		}

		public bool Serves(Uri uri)
		{
			return uri.AbsoluteUri.StartsWith(Origin + "/m/", StringComparison.OrdinalIgnoreCase);
		}

		public Uri Route(Uri original)
		{
			return new Uri(Origin + "/m/" + original.Host.ToLowerInvariant() + original.PathAndQuery);
		}

		internal void CoolDown(TimeSpan cooldown)
		{
			Interlocked.Exchange(ref retryAfter, Environment.TickCount64 + (long)cooldown.TotalMilliseconds);
		}
	}

	[CompilerGenerated]
	private sealed class _003CCandidates_003Ed__19 : IEnumerable<Mirror>, IEnumerable, IEnumerator<Mirror>, IEnumerator, IDisposable
	{
		private int _003C_003E1__state;

		private Mirror _003C_003E2__current;

		private int _003C_003El__initialThreadId;

		private Mirror _003Cfirst_003E5__2;

		private Mirror[] _003C_003E7__wrap2;

		private int _003C_003E7__wrap3;

		Mirror IEnumerator<Mirror>.Current
		{
			[DebuggerHidden]
			get
			{
				return _003C_003E2__current;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _003C_003E2__current;
			}
		}

		[DebuggerHidden]
		public _003CCandidates_003Ed__19(int _003C_003E1__state)
		{
			this._003C_003E1__state = _003C_003E1__state;
			_003C_003El__initialThreadId = Environment.CurrentManagedThreadId;
		}

		[DebuggerHidden]
		void IDisposable.Dispose()
		{
			_003Cfirst_003E5__2 = null;
			_003C_003E7__wrap2 = null;
			_003C_003E1__state = -2;
		}

		private bool MoveNext()
		{
			switch (_003C_003E1__state)
			{
			default:
				return false;
			case 0:
				_003C_003E1__state = -1;
				_003Cfirst_003E5__2 = lastWorking;
				if (_003Cfirst_003E5__2 != null && _003Cfirst_003E5__2.IsAvailable)
				{
					_003C_003E2__current = _003Cfirst_003E5__2;
					_003C_003E1__state = 1;
					return true;
				}
				goto IL_009b;
			case 1:
				_003C_003E1__state = -1;
				goto IL_009b;
			case 2:
				{
					_003C_003E1__state = -1;
					goto IL_0122;
				}
				IL_0122:
				_003C_003E7__wrap3++;
				goto IL_013a;
				IL_009b:
				_003C_003E7__wrap2 = Mirrors;
				_003C_003E7__wrap3 = 0;
				goto IL_013a;
				IL_013a:
				if (_003C_003E7__wrap3 < _003C_003E7__wrap2.Length)
				{
					Mirror mirror = _003C_003E7__wrap2[_003C_003E7__wrap3];
					if (mirror != _003Cfirst_003E5__2 && mirror.IsAvailable)
					{
						_003C_003E2__current = mirror;
						_003C_003E1__state = 2;
						return true;
					}
					goto IL_0122;
				}
				_003C_003E7__wrap2 = null;
				return false;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		[DebuggerHidden]
		void IEnumerator.Reset()
		{
			throw new NotSupportedException();
		}

		[DebuggerHidden]
		IEnumerator<Mirror> IEnumerable<Mirror>.GetEnumerator()
		{
			if (_003C_003E1__state == -2 && _003C_003El__initialThreadId == Environment.CurrentManagedThreadId)
			{
				_003C_003E1__state = 0;
				return this;
			}
			return new _003CCandidates_003Ed__19(0);
		}

		[DebuggerHidden]
		IEnumerator IEnumerable.GetEnumerator()
		{
			return ((IEnumerable<Mirror>)this).GetEnumerator();
		}
	}

	private const string MirrorPrefix = "/m/";

	private static readonly TimeSpan FailureCooldown = TimeSpan.FromMinutes(2L);

	private static readonly TimeSpan SlowCooldown = TimeSpan.FromMinutes(10L);

	private static readonly HashSet<string> MirrorFirstRegions = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "RU" };

	private static readonly string[] DefaultOrder = new string[2]
	{
		"https://delivery-two.evoproject.xyz",
		"https://delivery.evoproject.xyz"
	};

	private static readonly HashSet<string> Hosts = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
	{
		"resources.download.minecraft.net",
		"libraries.minecraft.net",
		"piston-data.mojang.com",
		"piston-meta.mojang.com",
		"launchermeta.mojang.com",
		"maven.fabricmc.net",
		"meta.fabricmc.net",
		"api.modrinth.com",
		"cdn.modrinth.com",
		"aka.ms",
		"download.visualstudio.microsoft.com",
		"github.com",
		"objects.githubusercontent.com",
		"release-assets.githubusercontent.com",
		"shadevis-protect.vercel.app",
		"www.evoproject.xyz"
	};

	private static readonly Mirror[] Mirrors = DefaultOrder.Select((string origin) => new Mirror(origin)).ToArray();

	private static volatile bool preferred = LauncherSettings.Current.PreferMirror || IsMirrorFirstRegion();

	private static volatile Mirror? lastWorking = Array.Find(Mirrors, (Mirror mirror) => string.Equals(mirror.Origin, LauncherSettings.Current.MirrorOrigin, StringComparison.OrdinalIgnoreCase));

	public static bool IsPreferred
	{
		get
		{
			if (preferred)
			{
				return IsAvailable;
			}
			return false;
		}
	}

	public static string? PreferredOrigin
	{
		get
		{
			if (!IsPreferred)
			{
				return null;
			}
			return Candidates().FirstOrDefault()?.Origin;
		}
	}

	public static bool IsAvailable => Array.Exists(Mirrors, (Mirror mirror) => mirror.IsAvailable);

	public static event Action<bool>? StateChanged;

	public static bool IsMirrorable(Uri original)
	{
		if (original.Scheme == Uri.UriSchemeHttps && original.IsDefaultPort)
		{
			return Hosts.Contains(original.Host);
		}
		return false;
	}

	[IteratorStateMachine(typeof(_003CCandidates_003Ed__19))]
	public static IEnumerable<Mirror> Candidates()
	{
		//yield-return decompiler failed: Unexpected instruction in Iterator.Dispose()
		return new _003CCandidates_003Ed__19(-2);
	}

	public static bool TryEscapeSlow(Uri served)
	{
		Uri served2 = served;
		Mirror current = Array.Find(Mirrors, (Mirror mirror) => mirror.Serves(served2));
		if (current == null)
		{
			if (!IsMirrorable(served2) || !IsAvailable)
			{
				return false;
			}
			PreferForSession();
			return true;
		}
		if (!Array.Exists(Mirrors, (Mirror mirror) => mirror != current && mirror.IsAvailable))
		{
			return false;
		}
		current.CoolDown(SlowCooldown);
		if (lastWorking == current)
		{
			lastWorking = null;
		}
		return true;
	}

	public static void PreferForSession()
	{
		if (!preferred && IsAvailable)
		{
			preferred = true;
			DeliveryMirror.StateChanged?.Invoke(obj: true);
		}
	}

	public static void MarkWorking(Mirror mirror)
	{
		bool num = !preferred;
		preferred = true;
		lastWorking = mirror;
		LauncherSettings current = LauncherSettings.Current;
		if (!current.PreferMirror || !string.Equals(current.MirrorOrigin, mirror.Origin, StringComparison.Ordinal))
		{
			LauncherSettings.Save(current with
			{
				PreferMirror = true,
				MirrorOrigin = mirror.Origin
			});
		}
		if (num)
		{
			DeliveryMirror.StateChanged?.Invoke(obj: true);
		}
	}

	public static void MarkFailed(Mirror mirror)
	{
		mirror.CoolDown(FailureCooldown);
		if (preferred && !IsAvailable)
		{
			preferred = false;
			DeliveryMirror.StateChanged?.Invoke(obj: false);
		}
	}

	private static bool IsMirrorFirstRegion()
	{
		try
		{
			return MirrorFirstRegions.Contains(RegionInfo.CurrentRegion.TwoLetterISORegionName);
		}
		catch (ArgumentException)
		{
			return false;
		}
	}
}
