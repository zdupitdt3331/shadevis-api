using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Ui;

public sealed record EquippedSlot(string Slot, string Title, string Name)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("EquippedSlot");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Slot = ");
		builder.Append((object?)Slot);
		builder.Append(", Title = ");
		builder.Append((object?)Title);
		builder.Append(", Name = ");
		builder.Append((object?)Name);
		return true;
	}
}
