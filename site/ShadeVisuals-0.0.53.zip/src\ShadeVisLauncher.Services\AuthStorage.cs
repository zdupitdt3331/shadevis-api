using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace ShadeVisLauncher.Services;

public static class AuthStorage
{
    private const string FolderName = "ShadeVis";

    private const string FileName = "auth.dat";

    private static string FilePath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ShadeVis", "auth.dat");

    public static void Save(ShadeVisUser user)
    {
        try
        {
            byte[] bytes = ProtectedData.Protect(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(user)), null, DataProtectionScope.CurrentUser);
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
            File.WriteAllBytes(FilePath, bytes);
        }
        catch (Exception)
        {
        }
    }

    public static ShadeVisUser? Load()
    {
        if (!File.Exists(FilePath))
        {
            return null;
        }
        try
        {
            byte[] bytes = ProtectedData.Unprotect(File.ReadAllBytes(FilePath), null, DataProtectionScope.CurrentUser);
            return JsonSerializer.Deserialize<ShadeVisUser>(Encoding.UTF8.GetString(bytes));
        }
        catch (Exception)
        {
            return null;
        }
    }

    public static void Clear()
    {
        try
        {
            if (File.Exists(FilePath))
            {
                File.Delete(FilePath);
            }
        }
        catch (Exception)
        {
        }
    }
}