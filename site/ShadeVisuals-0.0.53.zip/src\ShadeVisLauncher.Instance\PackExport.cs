using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public sealed record PackExport(string Path, int Mods, int Skipped)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("PackExport");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Path = ");
		builder.Append((object?)Path);
		builder.Append(", Mods = ");
		builder.Append(Mods.ToString());
		builder.Append(", Skipped = ");
		builder.Append(Skipped.ToString());
		return true;
	}
}
