using System;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace ShadeVisLauncher.Services;

public sealed class MirrorFallbackHandler : DelegatingHandler
{
	private static readonly TimeSpan DirectBudget = TimeSpan.FromSeconds(7L);

	private static readonly TimeSpan MirrorBudget = TimeSpan.FromSeconds(12L);

	public MirrorFallbackHandler(HttpMessageHandler inner)
		: base(inner)
	{
	}

	protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancel)
	{
		Uri original = request.RequestUri;
		if ((object)original == null || original.IsLoopback || !DeliveryMirror.IsMirrorable(original))
		{
			return await base.SendAsync(request, cancel);
		}
		if (DeliveryMirror.IsPreferred)
		{
			HttpResponseMessage httpResponseMessage = await TryMirrorsAsync(request, original, cancel);
			if (httpResponseMessage != null)
			{
				return httpResponseMessage;
			}
		}
		if (!DeliveryMirror.IsAvailable)
		{
			return await base.SendAsync(request, cancel);
		}
		try
		{
			return await SendWithinAsync(request, DirectBudget, cancel);
		}
		catch (Exception ex) when (IsNetworkFailure(ex, cancel))
		{
			HttpResponseMessage httpResponseMessage2 = await TryMirrorsAsync(request, original, cancel);
			if (httpResponseMessage2 != null)
			{
				return httpResponseMessage2;
			}
			throw;
		}
	}

	private async Task<HttpResponseMessage?> TryMirrorsAsync(HttpRequestMessage request, Uri original, CancellationToken cancel)
	{
		foreach (DeliveryMirror.Mirror mirror in DeliveryMirror.Candidates().ToList())
		{
			request.RequestUri = mirror.Route(original);
			try
			{
				HttpResponseMessage result = await SendWithinAsync(request, MirrorBudget, cancel);
				DeliveryMirror.MarkWorking(mirror);
				return result;
			}
			catch (Exception failure) when (IsNetworkFailure(failure, cancel))
			{
				DeliveryMirror.MarkFailed(mirror);
			}
		}
		request.RequestUri = original;
		return null;
	}

	private async Task<HttpResponseMessage> SendWithinAsync(HttpRequestMessage request, TimeSpan budget, CancellationToken cancel)
	{
		using CancellationTokenSource limit = CancellationTokenSource.CreateLinkedTokenSource(cancel);
		limit.CancelAfter(budget);
		return await base.SendAsync(request, limit.Token);
	}

	private static bool IsNetworkFailure(Exception failure, CancellationToken cancel)
	{
		bool flag = !cancel.IsCancellationRequested;
		if (flag)
		{
			bool flag2 = ((failure is HttpRequestException || failure is OperationCanceledException) ? true : false);
			flag = flag2;
		}
		return flag;
	}
}
