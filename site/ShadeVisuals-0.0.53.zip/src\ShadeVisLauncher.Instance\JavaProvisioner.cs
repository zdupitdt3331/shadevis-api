using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher.Instance;

public sealed class JavaProvisioner
{
	private sealed record CustomRuntime(string File, string? Tag, string Sha256)
	{
		[CompilerGenerated]
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("CustomRuntime");
			stringBuilder.Append(" { ");
			if (PrintMembers(stringBuilder))
			{
				stringBuilder.Append(' ');
			}
			stringBuilder.Append('}');
			return stringBuilder.ToString();
		}

		[CompilerGenerated]
		private bool PrintMembers(StringBuilder builder)
		{
			RuntimeHelpers.EnsureSufficientExecutionStack();
			builder.Append("File = ");
			builder.Append((object?)File);
			builder.Append(", Tag = ");
			builder.Append((object?)Tag);
			builder.Append(", Sha256 = ");
			builder.Append((object?)Sha256);
			return true;
		}
	}

	[CompilerGenerated]
	private InstancePaths _003Cpaths_003EP;

	[CompilerGenerated]
	private HttpDownloader _003Cdownloader_003EP;

	private const int JavaMajor = 25;

	private const string JavaExecutableName = "javaw.exe";

	private const string RuntimeManifestName = "runtime.json";

	private const string CustomMarkerName = ".evojdk";

	private const string ReleaseFileName = "release";

	private const string JavaVersionKey = "JAVA_VERSION=";

	private const string ImplementorKey = "IMPLEMENTOR=";

	private const string CustomRuntimeLabel = " · ShadeVis JVM";

	private const string UnknownRuntime = "unknown";

	private const string RuntimeLookupOperation = "ShadeVis runtime lookup";

	private static readonly string[] RequiredBinaries = new string[3]
	{
		"java.dll",
		"jli.dll",
		Path.Combine("server", "jvm.dll")
	};

	private readonly ReleaseClient release;

	public bool HasCustomRuntime
	{
		get
		{
			if (ReadMarker() != null)
			{
				return FindCompleteJava(_003Cpaths_003EP.Runtime) != null;
			}
			return false;
		}
	}

	private string MarkerPath => Path.Combine(_003Cpaths_003EP.Runtime, ".evojdk");

	public JavaProvisioner(InstancePaths paths, HttpDownloader downloader)
	{
		_003Cpaths_003EP = paths;
		_003Cdownloader_003EP = downloader;
		release = new ReleaseClient();
		
	}

	public async Task<string> EnsureAsync(string? token, string? hwid, IProgress<string> status, IProgress<double> percent, CancellationToken cancel)
	{
		string token2 = token;
		string hwid2 = hwid;
		Directory.CreateDirectory(_003Cpaths_003EP.Runtime);
		CustomRuntime customRuntime;
		try
		{
			customRuntime = await NetworkRetry.RequireAsync("ShadeVis runtime lookup", (CancellationToken attemptCancel) => ResolveCustomRuntimeAsync(token2, hwid2, attemptCancel), status, cancel);
		}
		catch (InvalidOperationException) when (HasCustomRuntime)
		{
			return FindCompleteJava(_003Cpaths_003EP.Runtime);
		}
		if ((object)customRuntime != null)
		{
			return await EnsureCustomAsync(customRuntime, token2, hwid2, status, percent, cancel);
		}
		return await EnsureStockAsync(status, percent, cancel);
	}

	private async Task<string> EnsureCustomAsync(CustomRuntime custom, string? token, string? hwid, IProgress<string> status, IProgress<double> percent, CancellationToken cancel)
	{
		string text = FindCompleteJava(_003Cpaths_003EP.Runtime);
		if (text != null && string.Equals(ReadMarker(), custom.Sha256, StringComparison.OrdinalIgnoreCase))
		{
			return text;
		}
		status.Report("Installing ShadeVis runtime...");
		ResetRuntime();
		string archive = Path.Combine(_003Cpaths_003EP.Runtime, "evojdk.zip");
		string text2 = ((!custom.File.StartsWith("http", StringComparison.OrdinalIgnoreCase)) ? ((await release.ResolveAsync(token, hwid, custom.File, custom.Tag, cancel)) ?? throw new InvalidOperationException("access to the ShadeVis runtime was denied")) : custom.File);
		string url = text2;
		await _003Cdownloader_003EP.DownloadWithProgressAsync(url, archive, percent, cancel);
		if (!(await FileDigest.MatchesSha256Async(archive, custom.Sha256, cancel)))
		{
			TryDelete(archive);
			throw new InvalidOperationException("the ShadeVis runtime failed integrity verification");
		}
		status.Report("Extracting ShadeVis runtime...");
		ZipFile.ExtractToDirectory(archive, _003Cpaths_003EP.Runtime, overwriteFiles: true);
		TryDelete(archive);
		WriteMarker(custom.Sha256);
		return RequireCompleteJava();
	}

	private async Task<string> EnsureStockAsync(IProgress<string> status, IProgress<double> percent, CancellationToken cancel)
	{
		string text = FindCompleteJava(_003Cpaths_003EP.Runtime);
		if (text != null)
		{
			return text;
		}
		ResetRuntime();
		string value = ((RuntimeInformation.OSArchitecture == Architecture.Arm64) ? "aarch64" : "x64");
		DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(55, 2);
		defaultInterpolatedStringHandler.AppendLiteral("https://aka.ms/download-jdk/microsoft-jdk-");
		defaultInterpolatedStringHandler.AppendFormatted(25);
		defaultInterpolatedStringHandler.AppendLiteral("-windows-");
		defaultInterpolatedStringHandler.AppendFormatted(value);
		defaultInterpolatedStringHandler.AppendLiteral(".zip");
		string url = defaultInterpolatedStringHandler.ToStringAndClear();
		string archive = Path.Combine(_003Cpaths_003EP.Runtime, "jdk.zip");
		status.Report("Downloading Java runtime...");
		await _003Cdownloader_003EP.DownloadWithProgressAsync(url, archive, percent, cancel);
		status.Report("Extracting Java runtime...");
		ZipFile.ExtractToDirectory(archive, _003Cpaths_003EP.Runtime, overwriteFiles: true);
		TryDelete(archive);
		return RequireCompleteJava();
	}

	private string RequireCompleteJava()
	{
		string text = FindCompleteJava(_003Cpaths_003EP.Runtime);
		if (text != null)
		{
			return text;
		}
		ResetMarker();
		throw new RuntimeBlockedException(_003Cpaths_003EP.Runtime);
	}

	private async Task<CustomRuntime?> ResolveCustomRuntimeAsync(string? token, string? hwid, CancellationToken cancel)
	{
		string text = await release.ResolveOrThrowAsync(token, hwid, "runtime.json", null, cancel);
		if (text == null)
		{
			return null;
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(await _003Cdownloader_003EP.GetStringAsync(text, cancel));
		string propertyName = ((RuntimeInformation.OSArchitecture == Architecture.Arm64) ? "win-arm64" : "win-x64");
		if (!jsonDocument.RootElement.TryGetProperty(propertyName, out var value) || value.ValueKind != JsonValueKind.Object)
		{
			return null;
		}
		JsonElement value2;
		string text2 = (value.TryGetProperty("file", out value2) ? value2.GetString() : null);
		JsonElement value3;
		string text3 = (value.TryGetProperty("sha256", out value3) ? value3.GetString() : null);
		JsonElement value4;
		string tag = (value.TryGetProperty("tag", out value4) ? value4.GetString() : null);
		if (string.IsNullOrEmpty(text2) || string.IsNullOrEmpty(text3))
		{
			return null;
		}
		return new CustomRuntime(text2, tag, text3);
	}

	public string DescribeRuntime(string javaExecutable)
	{
		string text = ((ReadMarker() == null) ? string.Empty : " · ShadeVis JVM");
		return (ReadReleaseDescription(javaExecutable) ?? "unknown") + text;
	}

	private static string? ReadReleaseDescription(string javaExecutable)
	{
		try
		{
			string directoryName = Path.GetDirectoryName(Path.GetDirectoryName(javaExecutable));
			if (directoryName == null)
			{
				return null;
			}
			string path = Path.Combine(directoryName, "release");
			if (!File.Exists(path))
			{
				return null;
			}
			string text = null;
			string text2 = null;
			foreach (string item in File.ReadLines(path))
			{
				if (item.StartsWith("JAVA_VERSION=", StringComparison.Ordinal))
				{
					string text3 = item;
					int length = "JAVA_VERSION=".Length;
					text = Unquote(text3.Substring(length, text3.Length - length));
				}
				else if (item.StartsWith("IMPLEMENTOR=", StringComparison.Ordinal))
				{
					string text3 = item;
					int length = "IMPLEMENTOR=".Length;
					text2 = Unquote(text3.Substring(length, text3.Length - length));
				}
			}
			if (string.IsNullOrEmpty(text))
			{
				return null;
			}
			return string.IsNullOrEmpty(text2) ? text : (text + " (" + text2 + ")");
		}
		catch (Exception)
		{
			return null;
		}
	}

	private static string Unquote(string value)
	{
		return value.Trim().Trim('"');
	}

	private string? ReadMarker()
	{
		try
		{
			return File.Exists(MarkerPath) ? File.ReadAllText(MarkerPath).Trim() : null;
		}
		catch (Exception)
		{
			return null;
		}
	}

	private void WriteMarker(string sha256)
	{
		try
		{
			File.WriteAllText(MarkerPath, sha256);
		}
		catch (Exception)
		{
		}
	}

	private void ResetRuntime()
	{
		try
		{
			if (Directory.Exists(_003Cpaths_003EP.Runtime))
			{
				Directory.Delete(_003Cpaths_003EP.Runtime, recursive: true);
			}
		}
		catch (Exception)
		{
		}
		Directory.CreateDirectory(_003Cpaths_003EP.Runtime);
	}

	private static string? FindCompleteJava(string root)
	{
		if (!Directory.Exists(root))
		{
			return null;
		}
		return Directory.EnumerateFiles(root, "javaw.exe", SearchOption.AllDirectories).FirstOrDefault(IsComplete);
	}

	private static bool IsComplete(string javaExecutable)
	{
		string bin = Path.GetDirectoryName(javaExecutable);
		if (bin != null)
		{
			return RequiredBinaries.All((string binary) => File.Exists(Path.Combine(bin, binary)));
		}
		return false;
	}

	private void ResetMarker()
	{
		TryDelete(MarkerPath);
	}

	private static void TryDelete(string path)
	{
		try
		{
			File.Delete(path);
		}
		catch (Exception)
		{
		}
	}
}
