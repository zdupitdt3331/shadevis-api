using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using Microsoft.Web.WebView2.Core;

namespace ShadeVisLauncher.Ui;

public sealed class CosmeticThumbnails : IAsyncDisposable
{
	[CompilerGenerated]
	private nint _003Cowner_003EP;

	private const string VirtualHost = "evo.viewer";

	private const string PageUrl = "https://evo.viewer/thumbs.html";

	private const string AssetsFolder = "assets";

	private const string ViewerFolder = "viewer";

	private const string FolderName = "ShadeVis";

	private const string CacheFolderName = "thumbs";

	private const string SlotsScript = "evoThumbSlots()";

	private const string RenderScript = "evoThumb({0},{1},{2},{3})";

	private const string IdField = "id";

	private const string UrlField = "url";

	private const string DataPrefix = "data:image/png;base64,";

	private const string FileFormat = "{0}_{1}.png";

	private const string UnknownVersion = "0";

	private const int RenderSize = 256;

	private const char KeySeparator = '_';

	private const char KeyDash = '-';

	private static readonly TimeSpan NavigationTimeout = TimeSpan.FromSeconds(30L);

	private static readonly TimeSpan RenderTimeout = TimeSpan.FromSeconds(20L);

	private static readonly Rectangle OffscreenBounds = new Rectangle(0, 0, 1, 1);

	private readonly HashSet<string> slots;

	private readonly Dictionary<int, TaskCompletionSource<string>> awaiting;

	private CoreWebView2Controller? controller;

	private TaskCompletionSource<bool>? navigation;

	private int requests;

	private bool broken;

	public CosmeticThumbnails(nint owner)
	{
		_003Cowner_003EP = owner;
		slots = new HashSet<string>(StringComparer.Ordinal);
		awaiting = new Dictionary<int, TaskCompletionSource<string>>();
		
	}

	public async Task<BitmapSource?> LoadAsync(string slot, string? key, CancellationToken cancel)
	{
		if (key == null || key.Length == 0 || cancel.IsCancellationRequested)
		{
			return null;
		}
		string path = CachePath(slot, key);
		BitmapSource bitmapSource = FromCache(path);
		if (bitmapSource != null)
		{
			return bitmapSource;
		}
		if (!(await ReadyAsync()) || !slots.Contains(slot) || cancel.IsCancellationRequested)
		{
			return null;
		}
		byte[] array = await RenderAsync(slot, key);
		if (array == null)
		{
			return null;
		}
		Store(path, array);
		return Decode(array);
	}

	private async Task<byte[]?> RenderAsync(string slot, string key)
	{
		int id = ++requests;
		TaskCompletionSource<string> result = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
		awaiting[id] = result;
		try
		{
			CoreWebView2 coreWebView = controller.CoreWebView2;
			string format = "evoThumb({0},{1},{2},{3})";
			global::_003C_003Ey__InlineArray4<object> buffer = default(global::_003C_003Ey__InlineArray4<object>);
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<global::_003C_003Ey__InlineArray4<object>, object>(ref buffer, 0) = Literal(slot);
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<global::_003C_003Ey__InlineArray4<object>, object>(ref buffer, 1) = Literal(key);
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<global::_003C_003Ey__InlineArray4<object>, object>(ref buffer, 2) = 256;
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<global::_003C_003Ey__InlineArray4<object>, object>(ref buffer, 3) = id;
			await coreWebView.ExecuteScriptAsync(string.Format(format, global::_003CPrivateImplementationDetails_003E.InlineArrayAsReadOnlySpan<global::_003C_003Ey__InlineArray4<object>, object>(in buffer, 4)));
			using CancellationTokenSource timeout = new CancellationTokenSource(RenderTimeout);
			if (await Task.WhenAny(result.Task, Task.Delay(-1, timeout.Token)) != result.Task)
			{
				return null;
			}
			string result2 = result.Task.Result;
			object result3;
			if (!result2.StartsWith("data:image/png;base64,", StringComparison.Ordinal))
			{
				result3 = null;
			}
			else
			{
				string text = result2;
				int length = "data:image/png;base64,".Length;
				result3 = Convert.FromBase64String(text.Substring(length, text.Length - length));
			}
			return (byte[]?)result3;
		}
		catch (InvalidOperationException)
		{
			broken = true;
			return null;
		}
		catch (FormatException)
		{
			return null;
		}
		finally
		{
			awaiting.Remove(id);
		}
	}

	private void OnWebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
	{
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(e.TryGetWebMessageAsString());
			if (jsonDocument.RootElement.TryGetProperty("id", out var value) && jsonDocument.RootElement.TryGetProperty("url", out var value2) && awaiting.TryGetValue(value.GetInt32(), out TaskCompletionSource<string> value3))
			{
				value3.TrySetResult(value2.GetString() ?? string.Empty);
			}
		}
		catch (Exception ex) when (((ex is JsonException || ex is ArgumentException || ex is InvalidOperationException) ? 1 : 0) != 0)
		{
		}
	}

	private async Task<bool> ReadyAsync()
	{
		if (broken)
		{
			return false;
		}
		if (controller != null)
		{
			return true;
		}
		string folder = Path.Combine(AppContext.BaseDirectory, "assets", "viewer");
		if (!Directory.Exists(folder))
		{
			broken = true;
			return false;
		}
		try
		{
			CoreWebView2Controller created = await (await WebViewHost.EnvironmentAsync()).CreateCoreWebView2ControllerAsync(_003Cowner_003EP);
			created.IsVisible = false;
			created.Bounds = OffscreenBounds;
			CoreWebView2 coreWebView = created.CoreWebView2;
			coreWebView.SetVirtualHostNameToFolderMapping("evo.viewer", folder, CoreWebView2HostResourceAccessKind.Allow);
			coreWebView.Settings.AreDevToolsEnabled = false;
			coreWebView.Settings.AreDefaultContextMenusEnabled = false;
			navigation = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
			coreWebView.NavigationCompleted += OnNavigationCompleted;
			coreWebView.WebMessageReceived += OnWebMessageReceived;
			coreWebView.Navigate("https://evo.viewer/thumbs.html");
			if (!(await NavigatedAsync()))
			{
				created.Close();
				broken = true;
				return false;
			}
			controller = created;
			await ReadSlotsAsync();
			return slots.Count > 0;
		}
		catch (Exception ex) when (WebViewHost.IsMissingRuntime(ex) || ex is InvalidOperationException)
		{
			broken = true;
			return false;
		}
	}

	private async Task<bool> NavigatedAsync()
	{
		using CancellationTokenSource timeout = new CancellationTokenSource(NavigationTimeout);
		return await Task.WhenAny(navigation.Task, Task.Delay(-1, timeout.Token)) == navigation.Task && navigation.Task.Result;
	}

	private async Task ReadSlotsAsync()
	{
		try
		{
			string[] array = JsonSerializer.Deserialize<string[]>(await controller.CoreWebView2.ExecuteScriptAsync("evoThumbSlots()"));
			if (array != null)
			{
				string[] array2 = array;
				foreach (string item in array2)
				{
					slots.Add(item);
				}
			}
		}
		catch (Exception ex) when (((ex is InvalidOperationException || ex is JsonException) ? 1 : 0) != 0)
		{
			broken = true;
		}
	}

	private void OnNavigationCompleted(object? sender, CoreWebView2NavigationCompletedEventArgs e)
	{
		navigation?.TrySetResult(e.IsSuccess);
	}

	private static string? CachePath(string slot, string key)
	{
		if (!Storable(slot) || !Storable(key))
		{
			return null;
		}
		try
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ShadeVis", "thumbs", Version());
			Directory.CreateDirectory(text);
			return Path.Combine(text, string.Format("{0}_{1}.png", slot, key));
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
			return null;
		}
	}

	private static string Version()
	{
		return typeof(CosmeticThumbnails).Assembly.GetName().Version?.ToString() ?? "0";
	}

	private static bool Storable(string value)
	{
		foreach (char c in value)
		{
			if (!char.IsAsciiLetterOrDigit(c) && c != '_' && c != '-')
			{
				return false;
			}
		}
		return value.Length > 0;
	}

	private static BitmapSource? FromCache(string? path)
	{
		if (path == null || !File.Exists(path))
		{
			return null;
		}
		try
		{
			return Decode(File.ReadAllBytes(path));
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
			return null;
		}
	}

	private static void Store(string? path, byte[] png)
	{
		if (path == null)
		{
			return;
		}
		try
		{
			File.WriteAllBytes(path, png);
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException) ? 1 : 0) != 0)
		{
		}
	}

	private static BitmapSource? Decode(byte[] png)
	{
		try
		{
			BitmapImage bitmapImage = new BitmapImage();
			using MemoryStream streamSource = new MemoryStream(png);
			bitmapImage.BeginInit();
			bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
			bitmapImage.StreamSource = streamSource;
			bitmapImage.EndInit();
			bitmapImage.Freeze();
			return bitmapImage;
		}
		catch (Exception ex) when (((ex is NotSupportedException || ex is ArgumentException || ex is IOException) ? 1 : 0) != 0)
		{
			return null;
		}
	}

	private static string Literal(string value)
	{
		return JsonSerializer.Serialize(value);
	}

	public ValueTask DisposeAsync()
	{
		controller?.Close();
		controller = null;
		broken = true;
		return ValueTask.CompletedTask;
	}
}
