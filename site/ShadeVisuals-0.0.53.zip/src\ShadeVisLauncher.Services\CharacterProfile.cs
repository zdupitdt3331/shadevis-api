using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Services;

public sealed record CharacterProfile(bool Linked, string? Name, string? SkinUrl, bool Slim, IReadOnlyDictionary<string, string> Cosmetics, IReadOnlyList<SkinEntry> Skins)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("CharacterProfile");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Linked = ");
		builder.Append(Linked.ToString());
		builder.Append(", Name = ");
		builder.Append((object?)Name);
		builder.Append(", SkinUrl = ");
		builder.Append((object?)SkinUrl);
		builder.Append(", Slim = ");
		builder.Append(Slim.ToString());
		builder.Append(", Cosmetics = ");
		builder.Append(Cosmetics);
		builder.Append(", Skins = ");
		builder.Append(Skins);
		return true;
	}
}
