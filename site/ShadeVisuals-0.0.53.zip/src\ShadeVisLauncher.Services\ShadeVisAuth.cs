using System;
using System.Threading;
using System.Threading.Tasks;

namespace ShadeVisLauncher.Services;

/// <summary>Серверный вход не используется: аккаунты локальные, см. <see cref="AccountStore"/>.</summary>
public sealed class ShadeVisAuth
{
	public string Code => string.Empty;

	public string SignInUrl(string hwid) => string.Empty;

	public bool OpenBrowser(string hwid) => false;

	public Task<ShadeVisUser> LoginAsync(string hwid, string login, string password, CancellationToken cancel)
	{
		throw new NotSupportedException("Server sign-in is not available. Use the local account form.");
	}

	public Task<ShadeVisUser> WaitForLoginAsync(string hwid, IProgress<string> status, CancellationToken cancel)
	{
		throw new NotSupportedException("Server sign-in is not available. Use the local account form.");
	}

	public static Task<ShadeVisUser?> RefreshAsync(string token, CancellationToken cancel)
	{
		cancel.ThrowIfCancellationRequested();
		return Task.FromResult<ShadeVisUser?>(null);
	}
}
