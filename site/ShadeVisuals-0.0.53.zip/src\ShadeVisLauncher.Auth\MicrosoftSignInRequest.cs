using System;
using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Auth;

public sealed record MicrosoftSignInRequest(Uri AuthorizeUri, string RedirectBase, string State)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("MicrosoftSignInRequest");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("AuthorizeUri = ");
		builder.Append(AuthorizeUri);
		builder.Append(", RedirectBase = ");
		builder.Append((object?)RedirectBase);
		builder.Append(", State = ");
		builder.Append((object?)State);
		return true;
	}
}
