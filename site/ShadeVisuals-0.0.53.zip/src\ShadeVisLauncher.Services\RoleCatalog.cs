using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace ShadeVisLauncher.Services;

/// <summary>Роли аккаунтов: Admin, Media, User. Хранятся в %APPDATA%\ShadeVis\roles.json.</summary>
public static class RoleCatalog
{
	public const string Admin = "Admin";

	public const string Media = "Media";

	public const string User = "User";

	private const string DefaultAdminNick = "Art1x";

	private static readonly JsonSerializerOptions Format = new JsonSerializerOptions
	{
		WriteIndented = true
	};

	internal static string? RootOverride;

	public static string FilePath => System.IO.Path.Combine(RootOverride ?? System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ShadeVis"), "roles.json");

	public static IReadOnlyDictionary<string, string> All
	{
		get
		{
			Dictionary<string, string> result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
			foreach (KeyValuePair<string, string> item in ReadRaw())
			{
				string? normalized = Normalize(item.Value);
				if (normalized != null && !string.IsNullOrWhiteSpace(item.Key))
				{
					result[item.Key.Trim()] = normalized;
				}
			}
			return result;
		}
	}

	public static string? Normalize(string? role)
	{
		if (string.IsNullOrWhiteSpace(role))
		{
			return null;
		}
		string text = role.Trim();
		if (text.Equals(Admin, StringComparison.OrdinalIgnoreCase))
		{
			return Admin;
		}
		if (text.Equals(Media, StringComparison.OrdinalIgnoreCase))
		{
			return Media;
		}
		if (text.Equals(User, StringComparison.OrdinalIgnoreCase))
		{
			return User;
		}
		return null;
	}

	public static string Resolve(string? nick)
	{
		if (string.IsNullOrWhiteSpace(nick))
		{
			return User;
		}
		string key = nick.Trim();
		foreach (KeyValuePair<string, string> item in ReadRaw())
		{
			if (string.Equals(item.Key.Trim(), key, StringComparison.OrdinalIgnoreCase))
			{
				return Normalize(item.Value) ?? User;
			}
		}
		return User;
	}

	public static void EnsureFile()
	{
		if (File.Exists(FilePath))
		{
			return;
		}
		Save(ReadRaw(), out _);
	}

	public static bool SetRole(string nick, string? role, out string error)
	{
		error = string.Empty;
		string key = (nick ?? string.Empty).Trim();
		if (key.Length == 0)
		{
			error = "Enter a nickname.";
			return false;
		}
		Dictionary<string, string> map = new Dictionary<string, string>(ReadRaw(), StringComparer.OrdinalIgnoreCase);
		string? normalized = Normalize(role);
		if (normalized == null)
		{
			if (role != null && role.Trim().Equals("none", StringComparison.OrdinalIgnoreCase))
			{
				map.Remove(key);
			}
			else
			{
				error = "Unknown role. Use Admin, Media or User.";
				return false;
			}
		}
		else
		{
			map[key] = normalized;
		}
		return Save(map, out error);
	}

	private static Dictionary<string, string> ReadRaw()
	{
		try
		{
			if (!File.Exists(FilePath))
			{
				return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) { [DefaultAdminNick] = Admin };
			}
			Dictionary<string, string>? parsed = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(FilePath));
			return parsed != null ? new Dictionary<string, string>(parsed, StringComparer.OrdinalIgnoreCase) : new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is JsonException || ex is System.Security.SecurityException)
		{
			return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		}
	}

	private static bool Save(Dictionary<string, string> map, out string error)
	{
		error = string.Empty;
		try
		{
			string folder = System.IO.Path.GetDirectoryName(FilePath)!;
			Directory.CreateDirectory(folder);
			File.WriteAllText(FilePath, JsonSerializer.Serialize(map, Format));
			return true;
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is System.Security.SecurityException)
		{
			error = "Could not save roles: " + ex.Message;
			return false;
		}
	}
}
