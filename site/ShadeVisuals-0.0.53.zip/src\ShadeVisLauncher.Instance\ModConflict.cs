using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public sealed record ModConflict(string Kept, string Disabled, string DisabledFile)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("ModConflict");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Kept = ");
		builder.Append((object?)Kept);
		builder.Append(", Disabled = ");
		builder.Append((object?)Disabled);
		builder.Append(", DisabledFile = ");
		builder.Append((object?)DisabledFile);
		return true;
	}
}
