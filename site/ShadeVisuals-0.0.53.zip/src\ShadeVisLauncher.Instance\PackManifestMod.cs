using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public sealed record PackManifestMod(string ProjectId, string Slug, string Title, string File, string Version, string? Icon)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("PackManifestMod");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("ProjectId = ");
		builder.Append((object?)ProjectId);
		builder.Append(", Slug = ");
		builder.Append((object?)Slug);
		builder.Append(", Title = ");
		builder.Append((object?)Title);
		builder.Append(", File = ");
		builder.Append((object?)File);
		builder.Append(", Version = ");
		builder.Append((object?)Version);
		builder.Append(", Icon = ");
		builder.Append((object?)Icon);
		return true;
	}
}
