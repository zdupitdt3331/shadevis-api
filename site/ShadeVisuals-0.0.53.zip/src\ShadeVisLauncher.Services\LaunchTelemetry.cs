using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Services;

public sealed record LaunchTelemetry(string Event, string Name, string ModVersion, string McVersion, string Java, string Gpu, string Gl, bool SoftwareRenderer, int Mods, bool Ready, bool Entitled, long ElapsedMs, string? Stage, string? Error, bool Mirror)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("LaunchTelemetry");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Event = ");
		builder.Append((object?)Event);
		builder.Append(", Name = ");
		builder.Append((object?)Name);
		builder.Append(", ModVersion = ");
		builder.Append((object?)ModVersion);
		builder.Append(", McVersion = ");
		builder.Append((object?)McVersion);
		builder.Append(", Java = ");
		builder.Append((object?)Java);
		builder.Append(", Gpu = ");
		builder.Append((object?)Gpu);
		builder.Append(", Gl = ");
		builder.Append((object?)Gl);
		builder.Append(", SoftwareRenderer = ");
		builder.Append(SoftwareRenderer.ToString());
		builder.Append(", Mods = ");
		builder.Append(Mods.ToString());
		builder.Append(", Ready = ");
		builder.Append(Ready.ToString());
		builder.Append(", Entitled = ");
		builder.Append(Entitled.ToString());
		builder.Append(", ElapsedMs = ");
		builder.Append(ElapsedMs.ToString());
		builder.Append(", Stage = ");
		builder.Append((object?)Stage);
		builder.Append(", Error = ");
		builder.Append((object?)Error);
		builder.Append(", Mirror = ");
		builder.Append(Mirror.ToString());
		return true;
	}
}
