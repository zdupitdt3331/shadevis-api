using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Media.Imaging;
namespace ShadeVisLauncher.Ui;

public sealed record PlayerSkin(BitmapSource Texture, bool Slim, bool Legacy)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("PlayerSkin");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Texture = ");
		builder.Append(Texture);
		builder.Append(", Slim = ");
		builder.Append(Slim.ToString());
		builder.Append(", Legacy = ");
		builder.Append(Legacy.ToString());
		return true;
	}
}
