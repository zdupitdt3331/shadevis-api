using System.Collections.Generic;

namespace ShadeVisLauncher.Instance;

public sealed class ModPack
{
	public string Id { get; set; } = string.Empty;


	public string Name { get; set; } = string.Empty;


	public List<string> Files { get; set; } = new List<string>();

}
