using System;
using System.Collections.Generic;
using System.IO;

namespace ShadeVisLauncher.Instance;

/// <summary>Моды, которые остаются в папке mods, но не показываются в лаунчере.</summary>
public static class HiddenMods
{
	private static readonly HashSet<string> Defaults = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
	{
		"shadevisuals"
	};

	internal static string? RootOverride;

	private static string FilePath => Path.Combine(RootOverride ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ShadeVis"), "hidden-mods.txt");

	public static void EnsureFile()
	{
		try
		{
			string path = FilePath;
			if (File.Exists(path))
			{
				return;
			}
			string? folder = Path.GetDirectoryName(path);
			if (!string.IsNullOrEmpty(folder))
			{
				Directory.CreateDirectory(folder);
			}
			File.WriteAllText(path, "# Моды, скрытые из списка лаунчера (id или имя jar), по одному в строке.\nshadevisuals\n");
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is System.Security.SecurityException)
		{
		}
	}


	public static bool Contains(string? id, string? fileName)
	{
		IReadOnlyList<string>? entries = ReadEntries();
		if (entries == null)
		{
			return !string.IsNullOrWhiteSpace(id) && Defaults.Contains(id.Trim());
		}
		foreach (string entry in entries)
		{
			if (string.IsNullOrWhiteSpace(entry))
			{
				continue;
			}
			string value = entry.Trim();
			if (!string.IsNullOrEmpty(id) && string.Equals(value, id.Trim(), StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
			if (!string.IsNullOrEmpty(fileName) && string.Equals(value, fileName.Trim(), StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
		}
		return false;
	}

	private static IReadOnlyList<string>? ReadEntries()
	{
		try
		{
			if (!File.Exists(FilePath))
			{
				return null;
			}
			List<string> list = new List<string>();
			foreach (string line in File.ReadAllLines(FilePath))
			{
				if (!line.TrimStart().StartsWith("#", StringComparison.Ordinal))
				{
					list.Add(line);
				}
			}
			return list;
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is System.Security.SecurityException)
		{
			return null;
		}
	}
}
