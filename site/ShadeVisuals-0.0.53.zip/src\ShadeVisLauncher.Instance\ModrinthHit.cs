using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public sealed record ModrinthHit(string ProjectId, string Slug, string Title, string Summary, string Author, long Downloads, string? IconUrl, string Categories)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("ModrinthHit");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("ProjectId = ");
		builder.Append((object?)ProjectId);
		builder.Append(", Slug = ");
		builder.Append((object?)Slug);
		builder.Append(", Title = ");
		builder.Append((object?)Title);
		builder.Append(", Summary = ");
		builder.Append((object?)Summary);
		builder.Append(", Author = ");
		builder.Append((object?)Author);
		builder.Append(", Downloads = ");
		builder.Append(Downloads.ToString());
		builder.Append(", IconUrl = ");
		builder.Append((object?)IconUrl);
		builder.Append(", Categories = ");
		builder.Append((object?)Categories);
		return true;
	}
}
