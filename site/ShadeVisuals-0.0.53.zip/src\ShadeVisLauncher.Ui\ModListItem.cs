using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using ShadeVisLauncher.Instance;

namespace ShadeVisLauncher.Ui;

public sealed class ModListItem : INotifyPropertyChanged
{
	private const string InstallText = "Install";

	private const string InstallingText = "Installing";

	private const string InstalledText = "Installed";

	private const string RemoveText = "Remove";

	private const string ManagedText = "Managed";

	private const string MetaSeparator = "  ·  ";

	private const string MillionFormat = "{0:0.#}M";

	private const string ThousandFormat = "{0:0.#}K";

	private const string DownloadsSuffix = " downloads";

	private const string VectorIconExtension = ".svg";

	private const double Million = 1000000.0;

	private const double Thousand = 1000.0;

	private ModAction action;

	public string? ProjectId { get; }

	public string Title { get; }

	public string Summary { get; }

	public string Meta { get; }

	public string? IconUrl { get; }

	public InstalledMod? Installed { get; }

	public bool IsManaged { get; }

	public ModAction Action
	{
		get
		{
			return action;
		}
		set
		{
			if (action != value)
			{
				action = value;
				Raise("Action");
				Raise("ActionText");
				Raise("ActionEnabled");
			}
		}
	}

	public string ActionText => action switch
	{
		ModAction.Install => "Install", 
		ModAction.Installing => "Installing", 
		ModAction.Installed => "Installed", 
		ModAction.Remove => "Remove", 
		_ => "Managed", 
	};

	public bool ActionEnabled
	{
		get
		{
			ModAction modAction = action;
			if (modAction == ModAction.Install || modAction == ModAction.Remove)
			{
				return true;
			}
			return false;
		}
	}

	public event PropertyChangedEventHandler? PropertyChanged;

	private ModListItem(string? projectId, string title, string summary, string meta, string? iconUrl, ModAction action, InstalledMod? installed)
	{
		IsManaged = action == ModAction.Managed;
		ProjectId = projectId;
		Title = title;
		Summary = summary;
		Meta = meta;
		IconUrl = Displayable(iconUrl);
		this.action = action;
		Installed = installed;
	}

	public static ModListItem FromHit(ModrinthHit hit, IReadOnlySet<string> installedProjects)
	{
		ModAction modAction = (ManagedMods.Contains(hit.Slug) ? ModAction.Managed : (installedProjects.Contains(hit.ProjectId) ? ModAction.Installed : ModAction.Install));
		return new ModListItem(hit.ProjectId, hit.Title, hit.Summary, Describe(hit), hit.IconUrl, modAction, null);
	}

	public static ModListItem FromInstalled(InstalledMod mod)
	{
		return new ModListItem(mod.ProjectId, mod.Title, mod.Detail, string.Empty, mod.IconUrl, mod.Managed ? ModAction.Managed : ModAction.Remove, mod);
	}

	private static string Describe(ModrinthHit hit)
	{
		List<string> list = new List<string>(3)
		{
			hit.Author,
			Downloads(hit.Downloads) + " downloads"
		};
		if (hit.Categories.Length > 0)
		{
			list.Add(hit.Categories);
		}
		return string.Join("  ·  ", list);
	}

	private static string Downloads(long downloads)
	{
		if ((double)downloads >= 1000000.0)
		{
			return string.Format(CultureInfo.CurrentCulture, "{0:0.#}M", (double)downloads / 1000000.0);
		}
		if (!((double)downloads >= 1000.0))
		{
			return downloads.ToString(CultureInfo.CurrentCulture);
		}
		return string.Format(CultureInfo.CurrentCulture, "{0:0.#}K", (double)downloads / 1000.0);
	}

	private static string? Displayable(string? iconUrl)
	{
		if (!string.IsNullOrWhiteSpace(iconUrl) && !iconUrl.EndsWith(".svg", StringComparison.OrdinalIgnoreCase))
		{
			return iconUrl;
		}
		return null;
	}

	private void Raise(string property)
	{
		this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
	}
}
