﻿$ErrorActionPreference = 'Stop'
$projectPath = Split-Path $PSScriptRoot -Parent
$writer = [System.Resources.ResourceWriter]::new((Join-Path $projectPath 'ShadeVisLauncher.g.resources'))
try {
  foreach ($name in @('app.baml','mainwindow.baml')) {
    $stream = [IO.MemoryStream]::new([IO.File]::ReadAllBytes((Join-Path $projectPath $name)))
    $writer.AddResource($name, $stream, $true)
  }
  Get-ChildItem -LiteralPath (Join-Path $projectPath 'assets') -Recurse -File | ForEach-Object {
    $relative = $_.FullName.Substring($projectPath.Length+1).Replace('\','/').ToLowerInvariant()
    $stream = [IO.MemoryStream]::new([IO.File]::ReadAllBytes($_.FullName))
    $writer.AddResource($relative, $stream, $true)
  }
  $writer.Generate()
} finally { $writer.Dispose() }
