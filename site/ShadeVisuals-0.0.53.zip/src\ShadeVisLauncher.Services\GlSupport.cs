using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Services;

public sealed record GlSupport(int Major, int Minor, string Renderer, string Vendor, string Failure)
{
	public bool MeetsMinimum
	{
		get
		{
			if (Failure.Length == 0)
			{
				if (Major <= 3)
				{
					if (Major == 3)
					{
						return Minor >= 3;
					}
					return false;
				}
				return true;
			}
			return false;
		}
	}

	public string Description
	{
		get
		{
			if (Failure.Length <= 0)
			{
				DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(2, 3);
				defaultInterpolatedStringHandler.AppendFormatted(Major);
				defaultInterpolatedStringHandler.AppendLiteral(".");
				defaultInterpolatedStringHandler.AppendFormatted(Minor);
				defaultInterpolatedStringHandler.AppendLiteral(" ");
				defaultInterpolatedStringHandler.AppendFormatted(Renderer);
				return defaultInterpolatedStringHandler.ToStringAndClear().Trim();
			}
			return Failure;
		}
	}

	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("GlSupport");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Major = ");
		builder.Append(Major.ToString());
		builder.Append(", Minor = ");
		builder.Append(Minor.ToString());
		builder.Append(", Renderer = ");
		builder.Append((object?)Renderer);
		builder.Append(", Vendor = ");
		builder.Append((object?)Vendor);
		builder.Append(", Failure = ");
		builder.Append((object?)Failure);
		builder.Append(", MeetsMinimum = ");
		builder.Append(MeetsMinimum.ToString());
		builder.Append(", Description = ");
		builder.Append((object?)Description);
		return true;
	}
}
