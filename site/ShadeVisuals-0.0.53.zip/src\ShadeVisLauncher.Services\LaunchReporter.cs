using System.Reflection;
namespace ShadeVisLauncher.Services;

/// <summary>Launch telemetry is disabled in this distribution.</summary>
public static class LaunchReporter
{
    public const string StartEvent = "start";
    public const string FailedEvent = "failed";
    public static string LauncherVersion => Assembly.GetExecutingAssembly().GetName().Version?.ToString() ?? "unknown";
    public static void Report(ShadeVisUser user, LaunchTelemetry telemetry) { }
}
