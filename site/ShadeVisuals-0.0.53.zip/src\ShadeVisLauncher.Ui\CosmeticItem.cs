using System;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using ShadeVisLauncher.Services;

namespace ShadeVisLauncher.Ui;

public sealed class CosmeticItem : INotifyPropertyChanged
{
	private const string NoneName = "None";

	private const int CapeCropX = 1;

	private const int CapeCropY = 1;

	private const int CapeCropWidth = 10;

	private const int CapeCropHeight = 16;

	private const int CapeTextureWidth = 64;

	private const double TileSaturation = 0.56;

	private const double TileLightness = 0.44;

	private const double TileSecondLightness = 0.28;

	private const int TileHueStep = 42;

	private const int HueRange = 360;

	private const int HueSeed = 31;

	private const int MaxInitials = 2;

	private static readonly Thickness CapePreviewMargin = new Thickness(10.0, 12.0, 10.0, 12.0);

	private static readonly Thickness ModelPreviewMargin = new Thickness(0.0);

	private bool equipped;

	private bool locked;

	private ImageSource? preview;

	public string Slot { get; }

	public string? Key { get; }

	public string Name { get; }

	public ImageSource? Preview => preview;

	public Brush Tint { get; }

	public string Initials { get; }

	public bool IsNametag { get; }

	public bool IsNone { get; }

	public Thickness PreviewMargin
	{
		get
		{
			if (!(Slot == "cape"))
			{
				return ModelPreviewMargin;
			}
			return CapePreviewMargin;
		}
	}

	public BitmapScalingMode Scaling { get; private set; }

	public bool HasPreview => preview != null;

	public bool IsTile
	{
		get
		{
			if (preview == null && !IsNametag)
			{
				return !IsNone;
			}
			return false;
		}
	}

	public bool Equipped
	{
		get
		{
			return equipped;
		}
		set
		{
			if (equipped != value)
			{
				equipped = value;
				Raise("Equipped");
			}
		}
	}

	public bool Locked
	{
		get
		{
			return locked;
		}
		set
		{
			if (locked != value)
			{
				locked = value;
				Raise("Locked");
			}
		}
	}

	public event PropertyChangedEventHandler? PropertyChanged;

	private CosmeticItem(string slot, string? key, string name, ImageSource? preview, Brush tint, string initials, bool nametag)
	{
		IsNone = key == null;
		Slot = slot;
		Key = key;
		Name = name;
		this.preview = preview;
		Tint = tint;
		Initials = initials;
		IsNametag = nametag;
		Scaling = BitmapScalingMode.NearestNeighbor;
	}

	public void ApplyThumbnail(ImageSource image)
	{
		preview = image;
		Scaling = BitmapScalingMode.HighQuality;
		Raise("Preview");
		Raise("Scaling");
		Raise("HasPreview");
		Raise("IsTile");
	}

	public static CosmeticItem None(string slot)
	{
		return new CosmeticItem(slot, null, "None", null, Frozen(new SolidColorBrush(Color.FromArgb(51, byte.MaxValue, byte.MaxValue, byte.MaxValue))), "—", nametag: false);
	}

	public static CosmeticItem Create(string slot, CosmeticEntry entry)
	{
		if (slot == "nametag")
		{
			return new CosmeticItem(slot, entry.Key, entry.Name, null, NametagBrush(entry.Key), Initial(entry.Name), nametag: true);
		}
		ImageSource imageSource = ((slot == "cape") ? CapePreview(entry.Key) : ((!(slot == "melee")) ? null : IconPreview(CosmeticCatalog.MeleeIcon(entry.Key))));
		ImageSource imageSource2 = imageSource;
		CosmeticItem cosmeticItem = new CosmeticItem(slot, entry.Key, entry.Name, imageSource2, TileBrush(entry.Key), Initial(entry.Name), nametag: false);
		if (slot == "melee" && imageSource2 != null)
		{
			cosmeticItem.Scaling = BitmapScalingMode.HighQuality;
		}
		return cosmeticItem;
	}

	private static ImageSource? IconPreview(byte[]? png)
	{
		if (png == null)
		{
			return null;
		}
		try
		{
			BitmapImage bitmapImage = new BitmapImage();
			using MemoryStream streamSource = new MemoryStream(png);
			bitmapImage.BeginInit();
			bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
			bitmapImage.StreamSource = streamSource;
			bitmapImage.EndInit();
			bitmapImage.Freeze();
			return bitmapImage;
		}
		catch (Exception ex) when (((ex is NotSupportedException || ex is ArgumentException || ex is IOException) ? 1 : 0) != 0)
		{
			return null;
		}
	}

	private static ImageSource? CapePreview(string key)
	{
		byte[] array = CosmeticCatalog.CapeTexture(key);
		if (array == null)
		{
			return null;
		}
		try
		{
			BitmapImage bitmapImage = new BitmapImage();
			using MemoryStream streamSource = new MemoryStream(array);
			bitmapImage.BeginInit();
			bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
			bitmapImage.StreamSource = streamSource;
			bitmapImage.EndInit();
			int num = bitmapImage.PixelWidth / 64;
			if (num < 1)
			{
				return null;
			}
			CroppedBitmap croppedBitmap = new CroppedBitmap(bitmapImage, new Int32Rect(num, num, 10 * num, 16 * num));
			croppedBitmap.Freeze();
			return croppedBitmap;
		}
		catch (Exception ex) when (((ex is NotSupportedException || ex is ArgumentException || ex is IOException) ? 1 : 0) != 0)
		{
			return null;
		}
	}

	private static Brush NametagBrush(string key)
	{
		string[] array = CosmeticCatalog.Gradient(key);
		if (array == null)
		{
			return TileBrush(key);
		}
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush
		{
			StartPoint = new Point(0.0, 0.5),
			EndPoint = new Point(1.0, 0.5)
		};
		for (int i = 0; i < array.Length; i++)
		{
			linearGradientBrush.GradientStops.Add(new GradientStop(Parse(array[i]), (array.Length == 1) ? 0.0 : ((double)i / (double)(array.Length - 1))));
		}
		return Frozen(linearGradientBrush);
	}

	private static Brush TileBrush(string key)
	{
		int num = Hue(key);
		return Frozen(new LinearGradientBrush
		{
			StartPoint = new Point(0.1, 0.0),
			EndPoint = new Point(0.9, 1.0),
			GradientStops = 
			{
				new GradientStop(FromHsl(num, 0.56, 0.44), 0.0),
				new GradientStop(FromHsl((num + 42) % 360, 0.56, 0.28), 1.0)
			}
		});
	}

	private static int Hue(string key)
	{
		int num = 0;
		foreach (char c in key)
		{
			num = (num * 31 + c) % 360;
		}
		return num;
	}

	private static Color FromHsl(double hue, double saturation, double lightness)
	{
		double num = (1.0 - Math.Abs(2.0 * lightness - 1.0)) * saturation;
		double num2 = hue / 60.0;
		double num3 = num * (1.0 - Math.Abs(num2 % 2.0 - 1.0));
		double num4 = lightness - num / 2.0;
		var (num5, num6, num7) = ((num2 < 1.0) ? (num, num3, 0.0) : ((num2 < 2.0) ? (num3, num, 0.0) : ((num2 < 3.0) ? (0.0, num, num3) : ((num2 < 4.0) ? (0.0, num3, num) : ((!(num2 < 5.0)) ? (num, 0.0, num3) : (num3, 0.0, num))))));
		return Color.FromRgb(Channel(num5 + num4), Channel(num6 + num4), Channel(num7 + num4));
	}

	private static byte Channel(double value)
	{
		return (byte)Math.Clamp(Math.Round(value * 255.0), 0.0, 255.0);
	}

	private static Color Parse(string value)
	{
		return (Color)ColorConverter.ConvertFromString(value);
	}

	private static string Initial(string name)
	{
		string text = name.Trim();
		if (text.Length != 0)
		{
			return text.Substring(0, Math.Min(2, text.Length)).ToUpper(CultureInfo.CurrentCulture);
		}
		return "None".Substring(0, 1);
	}

	private void Raise(string property)
	{
		this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
	}

	private static Brush Frozen(Brush brush)
	{
		brush.Freeze();
		return brush;
	}
}
