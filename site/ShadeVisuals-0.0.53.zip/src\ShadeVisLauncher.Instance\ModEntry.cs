using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Instance;

public sealed record ModEntry(string ProjectId, string Slug, string Title, string File, string VersionNumber, string? IconUrl)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("ModEntry");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("ProjectId = ");
		builder.Append((object?)ProjectId);
		builder.Append(", Slug = ");
		builder.Append((object?)Slug);
		builder.Append(", Title = ");
		builder.Append((object?)Title);
		builder.Append(", File = ");
		builder.Append((object?)File);
		builder.Append(", VersionNumber = ");
		builder.Append((object?)VersionNumber);
		builder.Append(", IconUrl = ");
		builder.Append((object?)IconUrl);
		return true;
	}
}
