using System;
using System.IO;
using System.IO.Compression;

namespace ShadeVisLauncher.Instance;

/// <summary>Распаковывает нативные DLL из libraries в папку natives.</summary>
public static class NativesProvisioner
{
	public static void Ensure(InstancePaths paths)
	{
		try
		{
			Directory.CreateDirectory(paths.Natives);
			string libraries = Path.Combine(paths.Minecraft, "libraries");
			if (!Directory.Exists(libraries))
			{
				return;
			}
			foreach (string jar in Directory.EnumerateFiles(libraries, "*-natives-windows.jar", SearchOption.AllDirectories))
			{
				string name = Path.GetFileName(jar);
				if (name.Contains("arm64", StringComparison.OrdinalIgnoreCase) || name.Contains("-x86", StringComparison.OrdinalIgnoreCase))
				{
					continue;
				}
				try
				{
					using ZipArchive archive = ZipFile.OpenRead(jar);
					foreach (ZipArchiveEntry entry in archive.Entries)
					{
						if (!entry.Name.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
						{
							continue;
						}
						string target = Path.Combine(paths.Natives, entry.Name);
						if (!File.Exists(target))
						{
							entry.ExtractToFile(target, overwrite: true);
						}
					}
				}
				catch (Exception ex) when (ex is IOException || ex is InvalidDataException || ex is UnauthorizedAccessException)
				{
				}
			}
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is System.Security.SecurityException)
		{
		}
	}
}
