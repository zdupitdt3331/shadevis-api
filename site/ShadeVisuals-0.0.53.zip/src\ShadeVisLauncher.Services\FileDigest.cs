using System;
using System.IO;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;

namespace ShadeVisLauncher.Services;

public static class FileDigest
{
	public static async Task<bool> MatchesSha256Async(string path, string digest, CancellationToken cancel)
	{
		if (!File.Exists(path))
		{
			return false;
		}
		FileStream stream = File.OpenRead(path);
		bool result;
		try
		{
			result = string.Equals(Convert.ToHexStringLower(await SHA256.HashDataAsync(stream, cancel)), digest, StringComparison.OrdinalIgnoreCase);
		}
		finally
		{
			if (stream != null)
			{
				await stream.DisposeAsync();
			}
		}
		return result;
	}
}
