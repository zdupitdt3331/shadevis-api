using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Services;

public sealed record MachineSnapshot(string Os, string Arch, string Cpu, int Cores, string Ram)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("MachineSnapshot");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Os = ");
		builder.Append((object?)Os);
		builder.Append(", Arch = ");
		builder.Append((object?)Arch);
		builder.Append(", Cpu = ");
		builder.Append((object?)Cpu);
		builder.Append(", Cores = ");
		builder.Append(Cores.ToString());
		builder.Append(", Ram = ");
		builder.Append((object?)Ram);
		return true;
	}
}
