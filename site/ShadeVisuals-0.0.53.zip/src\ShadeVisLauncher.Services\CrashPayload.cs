using System.Runtime.CompilerServices;
using System.Text;
namespace ShadeVisLauncher.Services;

public sealed record CrashPayload(string Kind, bool Fatal, string Source, string Summary, string Log, string LogName, int? ExitCode, long Uptime, string Launcher, string? Mod, string Os, string Arch, string Cpu, string Ram, string Path, string OccurredAt, string? Hwid = null, string? Token = null)
{
	[CompilerGenerated]
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("CrashPayload");
		stringBuilder.Append(" { ");
		if (PrintMembers(stringBuilder))
		{
			stringBuilder.Append(' ');
		}
		stringBuilder.Append('}');
		return stringBuilder.ToString();
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("Kind = ");
		builder.Append((object?)Kind);
		builder.Append(", Fatal = ");
		builder.Append(Fatal.ToString());
		builder.Append(", Source = ");
		builder.Append((object?)Source);
		builder.Append(", Summary = ");
		builder.Append((object?)Summary);
		builder.Append(", Log = ");
		builder.Append((object?)Log);
		builder.Append(", LogName = ");
		builder.Append((object?)LogName);
		builder.Append(", ExitCode = ");
		builder.Append(ExitCode.ToString());
		builder.Append(", Uptime = ");
		builder.Append(Uptime.ToString());
		builder.Append(", Launcher = ");
		builder.Append((object?)Launcher);
		builder.Append(", Mod = ");
		builder.Append((object?)Mod);
		builder.Append(", Os = ");
		builder.Append((object?)Os);
		builder.Append(", Arch = ");
		builder.Append((object?)Arch);
		builder.Append(", Cpu = ");
		builder.Append((object?)Cpu);
		builder.Append(", Ram = ");
		builder.Append((object?)Ram);
		builder.Append(", Path = ");
		builder.Append((object?)Path);
		builder.Append(", OccurredAt = ");
		builder.Append((object?)OccurredAt);
		builder.Append(", Hwid = ");
		builder.Append((object?)Hwid);
		builder.Append(", Token = ");
		builder.Append((object?)Token);
		return true;
	}
}
